package com.wk.bean;

import java.util.ArrayList;
import java.util.List;

import msg.BackMessage.BattleBackSm;

import com.google.protobuf.InvalidProtocolBufferException;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.Pai;

/**
 * 战斗回放
 * 
 * @author ems
 *
 */
public class BattlebackBean {
	private int id;
	private List<Pai> genNoFengPais;
	private byte[] data = SystemConstantsAbs.empltyBytes;

	public BattlebackBean() {
	}

	public BattlebackBean(int id, List<Pai> genNoFengPais, byte[] data) {
		super();
		this.id = id;
		this.genNoFengPais = genNoFengPais;
		this.data = data;
	}

	public int getId() {
		return id;
	}

	public String getPais() {
		StringBuilder pais = new StringBuilder();
		for (Pai pai : genNoFengPais)
			pais.append(pai.getId()).append(SystemConstantsAbs.Double_SHARP_SEP);
		return pais.toString();
	}

	public void setPais(String pais) {
		this.genNoFengPais = new ArrayList<Pai>();
		for (String split : pais.split(SystemConstantsAbs.Double_SHARP_SEP)) {
			Pai pai = Pai.getPai(Integer.parseInt(split));
			if (pai != null)
				this.genNoFengPais.add(pai);
		}
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		if (data == null) {
			return;
		}
		this.data = data;
	}

	public BattleBackSm getBattleBackSm() {
		try {
			return BattleBackSm.newBuilder().mergeFrom(this.data).build();
		} catch (InvalidProtocolBufferException e) {
			LoggerService.getPlatformLog().error(e.getMessage(), e);
			return null;
		}
	}
}
