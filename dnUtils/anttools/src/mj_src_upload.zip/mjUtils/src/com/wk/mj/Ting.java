package com.wk.mj;

import java.util.ArrayList;

import msg.MjMessage;
import msg.MjMessage.Mj;

import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.MjType;
import com.wk.play.PlayTypeSet;

/**
 * 抓满14个牌后判断听牌
 * 
 * @author ems
 *
 */
public class Ting extends MjCompose {

	private static final long serialVersionUID = 1L;
	/** 出牌下标 **/
	private final int xiabiao;
	private final ListMjAbs listMjAbs;
	/*****/
	private transient final MjMessage.Ting.Builder tingBuilder = MjMessage.Ting
			.newBuilder();
	private transient final MjMessage.TingHuPai.Builder tingHuPaiBuilder = MjMessage.TingHuPai
			.newBuilder();

	public Ting(int xiabiao, ListMjAbs listMjAbs) {
		this.xiabiao = xiabiao;
		this.listMjAbs = listMjAbs;
	}

	/**
	 * 初始化
	 */
	public void init() {
		super.init();
	}

	/**
	 * 计算打这个牌后听牌情况
	 */
	public void calc() {
		if (this.xiabiao >= this.listMjAbs.getArrayListSize()) {
			this.setNumber(0);
			return;
		}
		int count = this.listMjAbs.getCount(this.xiabiao);
		if (count == 0) {
			this.setNumber(0);
			return;
		}
		super.resetArrayList(this.listMjAbs.getArrayList());
		super.resetZiList(this.listMjAbs.getZiList());
		Pai pai = this.listMjAbs.getZiList().get(this.xiabiao);
		this.remove(this.xiabiao, 1);
		super.calcTing(String.format("如果出%s", pai));
	}

	/**
	 * 打哪个牌
	 * 
	 * @return
	 */
	public Mj getDaNaGe() {
		return this.listMjAbs.getPai(this.xiabiao).getMj();
	}

	public msg.MjMessage.Ting genTing() {
		tingBuilder.setMj(this.getDaNaGe());
		tingBuilder.clearTingHuPai();
		for (int index = 0; index < this.getTingPais().size(); index++) {
			Pai pai = this.getTingPais().get(index);
			ArrayList<HuPaiType> types = this.getHuPaiTypesList().get(index);
			tingHuPaiBuilder.setTing(pai.getMj());
			tingHuPaiBuilder.clearHuPaiType();
			for (HuPaiType type : types) {
				tingHuPaiBuilder.addHuPaiType(type.getType());
			}
			tingHuPaiBuilder.setFanShu(this.getBaseCoinList().get(index));
			tingBuilder.addTingHuPai(tingHuPaiBuilder.build());
		}
		return tingBuilder.build();
	}

	@Override
	public boolean isCanJiangJianghu() {
		return this.listMjAbs.isCanJiangJianghu(this.xiabiao);
	}

	@Override
	public MjType getQingYiSeType() {
		return this.listMjAbs.getQingYiSeType(this.xiabiao);
	}

	@Override
	public MjType getQingYiSeType(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isYiTiaoLong() {
		return this.listMjAbs.isYiTiaoLong();
	}

	@Override
	public boolean isCanMengQing() {
		return this.listMjAbs.isCanMengQing();
	}

	@Override
	public boolean isMengQingJiangJiangJiePao() {
		return this.listMjAbs.isMengQingJiangJiangJiePao();
	}

	@Override
	public boolean isCanYiZiQiao() {
		return this.listMjAbs.isCanYiZiQiao(this.xiabiao);
	}

	@Override
	public boolean isCanYiZiQiao(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isCanDiHu() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isLai(Pai pai) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getCountLai() {
		return this.listMjAbs.getCountLai();
	}

	@Override
	public boolean isCanBaoTing() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isCanYiZiQiaoYouXi() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isPingHuJiePao() {
		return this.listMjAbs.isPingHuJiePao();
	}

	@Override
	public boolean isCanJiangJianghu(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isCanShiSanLan() {
		return this.listMjAbs.isCanShiSanLan(this.getNumber());
	}

	@Override
	public boolean isCanShiSanLan(long number) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isCanHunYiSe() {
		return this.listMjAbs.isCanHunYiSe(this.xiabiao);
	}

	@Override
	public boolean isCanHunYiSe(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isBao(Pai pai) {
		return this.listMjAbs.isBao(pai);
	}

	@Override
	public PlayTypeSet getPlayTypeSet() {
		return this.listMjAbs.getPlayTypeSet();
	}

	@Override
	public int getHandBao() {
		return this.listMjAbs.getHandBao(this.xiabiao);
	}

	@Override
	public int getHandBao(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public int getDaBao() {
		return this.listMjAbs.getDaBao(this.xiabiao);
	}

	@Override
	public int getDaBao(int index) {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isRightNowZhuaCanMingGang() {
		throw new UnsupportedOperationException();
	}

	@Override
	public boolean isJiangJiangHuJiePao() {
		return this.listMjAbs.isJiangJiangHuJiePao();
	}

	@Override
	public boolean isPinghuBaoTingJiePao() {
		return this.listMjAbs.isPinghuBaoTingJiePao();
	}

	@Override
	public boolean isAllPengOrGang() {
		return this.listMjAbs.isAllPengOrGang();
	}
}