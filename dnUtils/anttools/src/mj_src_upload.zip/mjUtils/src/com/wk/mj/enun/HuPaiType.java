package com.wk.mj.enun;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.play.PlayTypeSet;

/***
 * 胡牌类型
 * 
 * @author ems
 *
 */
public enum HuPaiType {
	/*****/
	tianHu(1, "天胡", HuPaiType.NO_MENG_QING, 1),
	/*****/
	diHu(2, "地胡", HuPaiType.NO_MENG_QING, 1),
	/*****/
	baoTing(3, "报听", HuPaiType.NO_MENG_QING, 1),
	/*****/
	jiangJiangHu(4, "将将胡", HuPaiType.CAN_MENG_QING, 1),
	/*****/
	qingYiSe(5, "清一色", HuPaiType.CAN_MENG_QING, 1),
	/** 牌型类 ***/
	yiTiaoLong(6, "一条龙", HuPaiType.CAN_MENG_QING, 1),
	/** 牌型类 ***/
	pengPengHu(7, "碰碰胡", HuPaiType.CAN_MENG_QING, 1),
	/** 牌型类 ***/
	xiaoQiDui(8, "小七对", HuPaiType.NO_MENG_QING, 1) {
		@Override
		public boolean noJiaZhang() {
			return true;
		}
	},
	/** 牌型类 ***/
	haoHuaXiaoQiDui(9, "豪华小七对", HuPaiType.NO_MENG_QING, 2) {
		@Override
		public boolean noJiaZhang() {
			return true;
		}
	},
	/** 牌型类 ***/
	doubleHaoHuaXiaoQiDui(10, "双豪华小七对", HuPaiType.NO_MENG_QING, 3) {
		@Override
		public boolean noJiaZhang() {
			return true;
		}
	},
	/** 牌型类 ***/
	threeHaoHuaXiaoQiDui(11, "三豪华小七对", HuPaiType.NO_MENG_QING, 4) {
		@Override
		public boolean noJiaZhang() {
			return true;
		}
	},
	/** ***/
	haiDi(12, "海底", HuPaiType.NO_MENG_QING, 1),
	/** ***/
	qiangGangHu(13, "抢杠", HuPaiType.NO_MENG_QING, 1),
	/** ***/
	gangBao(14, "杠上开花", HuPaiType.NO_MENG_QING, 1),
	/** 牌型类 ***/
	yiZiQiao(15, "一字撬", HuPaiType.NO_MENG_QING, 1) {
		@Override
		public boolean noJiaZhang() {
			return true;
		}
	},
	/**  ***/
	pingHu(16, "平胡", HuPaiType.NO_MENG_QING, 0),
	/**  ***/
	mengQing(17, "门清", HuPaiType.NO_MENG_QING, 1),
	/** 统计牌类 ***/
	shiSanLan(18, "十三烂", HuPaiType.NO_MENG_QING, 1),
	/** 统计牌类 ***/
	qiXingShiSanLan(19, "七星十三烂", HuPaiType.NO_MENG_QING, 1) {
		@Override
		public boolean noJiaZhang() {
			return true;
		}
	},
	/** 统计牌类 ***/
	hunYiSe(20, "混一色", HuPaiType.NO_MENG_QING, 1),
	/** 宝牌类 ***/
	baoPai1(21, "宝牌X1", HuPaiType.NO_MENG_QING, 1),
	/** 宝牌类 ***/
	baoPai2(22, "宝牌X2", HuPaiType.NO_MENG_QING, 2),
	/** 宝牌类 ***/
	baoPai3(23, "宝牌X3", HuPaiType.NO_MENG_QING, 3),
	/** 宝牌类 ***/
	baoPai4(24, "宝牌X4", HuPaiType.NO_MENG_QING, 4),
	/** 宝牌类 ***/
	douBao(25, "兜宝", HuPaiType.NO_MENG_QING, 1),
	/** 夹张 */
	jiaZhang(26, "夹张", HuPaiType.NO_MENG_QING, 1),
	/****/
	pingxiangQiXingShiSanLan(27, "萍乡七星十三烂", HuPaiType.NO_MENG_QING, 1),
	/****/
	pingxiangShiSanLan(28, "萍乡十三烂", HuPaiType.NO_MENG_QING, 1),
	/****/
	danDiao(29, "单吊", HuPaiType.NO_MENG_QING, 1),
	/****/
	quanQiuRen(30, "全球人", HuPaiType.NO_MENG_QING, 1)

	;
	/** 可以门清 */
	public static final boolean CAN_MENG_QING = true;
	/** 不算门清 */
	public static final boolean NO_MENG_QING = false;
	private final int type;
	private final String name;
	/** 算不算门清 **/
	private final boolean mQ;
	/** 大胡数 **/
	private final int times;

	private HuPaiType(int type, String name, boolean mQ, int times) {
		this.type = type;
		this.name = name;
		this.mQ = mQ;
		this.times = times;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	/** 算不算门清 **/
	public boolean ismQ() {
		return mQ;
	}

	public int getTimes() {
		return this.times;
	}

	/**
	 * 是否不能夹张胡牌
	 * 
	 * @return 默认能夹张胡牌
	 */
	public boolean noJiaZhang() {
		return false;
	}

	public static HuPaiType getBaoHuPaiType(int bao) {
		switch (bao) {
		case 1:
			return baoPai1;
		case 2:
			return baoPai2;
		case 3:
			return baoPai3;
		case 4:
			return baoPai4;
		default:
			LoggerService.getPlatformLog().error("超级错误！宝牌数超过4个！{}", bao);
			return null;
		}
	}

	// 自动生成开始
public static HuPaiType getEnum(int type){
switch(type) {
case 1:
  return tianHu;
case 2:
  return diHu;
case 3:
  return baoTing;
case 4:
  return jiangJiangHu;
case 5:
  return qingYiSe;
case 6:
  return yiTiaoLong;
case 7:
  return pengPengHu;
case 8:
  return xiaoQiDui;
case 9:
  return haoHuaXiaoQiDui;
case 10:
  return doubleHaoHuaXiaoQiDui;
case 11:
  return threeHaoHuaXiaoQiDui;
case 12:
  return haiDi;
case 13:
  return qiangGangHu;
case 14:
  return gangBao;
case 15:
  return yiZiQiao;
case 16:
  return pingHu;
case 17:
  return mengQing;
case 18:
  return shiSanLan;
case 19:
  return qiXingShiSanLan;
case 20:
  return hunYiSe;
case 21:
  return baoPai1;
case 22:
  return baoPai2;
case 23:
  return baoPai3;
case 24:
  return baoPai4;
case 25:
  return douBao;
case 26:
  return jiaZhang;
case 27:
  return pingxiangQiXingShiSanLan;
case 28:
  return pingxiangShiSanLan;
case 29:
  return danDiao;
case 30:
  return quanQiuRen;
default:
  return null;
}
}// 自动生成结束

}