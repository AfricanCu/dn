package com.wk.user.enm;

public enum ExpiresInType {
	nofeng(0),

	feng(1);

	private final int type;

	private ExpiresInType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

// 自动生成开始
public static ExpiresInType getEnum(int type){
switch(type) {
case 0:
  return nofeng;
case 1:
  return feng;
default:
  return null;
}
}// 自动生成结束
}