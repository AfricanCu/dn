package com.wk.util;

import com.jery.ngsp.server.InterfaceFactoryManager;
import com.jery.ngsp.server.scheduletask.ScheduleTaskManager;

public class TimeTaskUtil {

	private static final ScheduleTaskManager taskManager = InterfaceFactoryManager
			.getInterfaceFactory().getTimeTaskManager();

	public static ScheduleTaskManager getTaskmanager() {
		return taskManager;
	}
}
