package com.wk.enun;

/**
 * 区域类型
 * 
 * @author ems
 *
 */
public enum DistrictType {
	/***/
	yuanjiang(1, "沅江市"),
	/***/
	yingtang(2, "鹰潭市"),

	/***/

	;
	private final int type;
	private final String district;

	private DistrictType(int type, String district) {
		this.type = type;
		this.district = district;
	}

	public int getType() {
		return type;
	}

	public String getDistrict() {
		return district;
	}

}
