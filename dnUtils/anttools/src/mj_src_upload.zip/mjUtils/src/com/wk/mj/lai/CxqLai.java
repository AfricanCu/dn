package com.wk.mj.lai;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.Compose;
import com.wk.mj.MjCompose;
import com.wk.mj.MjUtils;
import com.wk.mj.Pai;
import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.MjType;
import com.wk.mj.lai.FindLaiType.FindTarget;

public class CxqLai implements Serializable {
	private static final long serialVersionUID = 1L;
	/** 胡任何牌 **/
	public static final List<Pai> AnyPai = new ArrayList<Pai>(
			MjUtils.getSortNoFengPais());
	private static final FindTarget[] emptyFindTargetArr = new FindTarget[] {};
	public static CxqLai maxListSize;
	/** 完整牌型 ***/
	private final List<Compose> fullComposeList;
	/** 移除1个的牌查找类型列表 **/
	private final List<FindTarget[]> positionFindTypeList;

	public CxqLai(int fullComposeListSize, int positionFindTypeListSize) {
		fullComposeList = new ArrayList<>(
				fullComposeListSize > 0 ? fullComposeListSize : 4);
		positionFindTypeList = new ArrayList<>(
				positionFindTypeListSize > 0 ? positionFindTypeListSize : 4);
	}

	public void add(Compose fullCompose, List<FindTarget[]> positionFindTypeList) {
		this.fullComposeList.add(fullCompose);
		this.positionFindTypeList.addAll(positionFindTypeList);
		this.positionFindTypeList.add(emptyFindTargetArr);
		if (maxListSize == null
				|| this.positionFindTypeList.size() > maxListSize.positionFindTypeList
						.size()) {
			maxListSize = this;
		}
	}

	/**
	 * 
	 * @param fullCompose
	 *            完整牌型
	 * @param positionList
	 *            哪些位置要移除1个的列表
	 * @param oldLaiList
	 *            癞子牌型原始排列（未除0）
	 * @return
	 */
	public static void CreateCxqLai(Map<Long, CxqLai> laiMap,
			Compose fullCompose, List<Integer> positionList,
			List<Integer> oldLaiList) {
		int startZeroCount = 0;
		for (int index = 0; index < oldLaiList.size(); index++) {
			if (oldLaiList.get(index) == 0) {
				startZeroCount++;
			} else {
				break;
			}
		}
		int endZeroCount = 0;
		for (int index = oldLaiList.size() - 1; index > 0; index--) {
			if (oldLaiList.get(index) == 0) {
				endZeroCount++;
			} else {
				break;
			}
		}
		/** oldLaiList的不为0的位置在laiCompose的对应位置 **/
		List<Integer> oldLaiInlaiComposePosList = new ArrayList<Integer>(
				oldLaiList);
		Collections.fill(oldLaiInlaiComposePosList, -1);
		ArrayList<Integer> arrayList = new ArrayList<Integer>();
		int zeroCount = 0;
		int endIndex = oldLaiList.size() - endZeroCount;
		for (int index = startZeroCount; index < endIndex; index++) {
			if (oldLaiList.get(index) == 0) {
				zeroCount++;
			} else {
				if (zeroCount >= 1) {
					arrayList.add(0);
				}
				zeroCount = 0;
				arrayList.add(oldLaiList.get(index));
				oldLaiInlaiComposePosList.set(index, arrayList.size() - 1);
			}
		}
		long laiCompose = Compose.calcLong(arrayList);
		if (LaiTools.print())
			LoggerService.getPlatformLog().error(
					"\n{},\n{},\n{}",
					new Object[] { oldLaiList, oldLaiInlaiComposePosList,
							laiCompose });
		List<Integer> fullArrayList = fullCompose.getArrayList();
		/** 移除1个的牌查找类型列表 **/
		List<FindTarget[]> positionFindTypeList = new ArrayList<>();
		boolean isCanAny = false;
		if (LaiTools.test())
			if (positionList.size() == 2 && positionList.get(0) == 6
					&& positionList.get(1) == 7) {
				int i = 0;
			}
		for (int position : positionList) {
			if (oldLaiInlaiComposePosList.get(position) != -1) {
				positionFindTypeList
						.add(FindLaiType.cur
								.getFindTarget(oldLaiInlaiComposePosList
										.get(position)));
				continue;
			}
			int nextIndex = -1;
			FindLaiType nextType = FindLaiType.prevOne;
			for (int index = position + 1; index < fullArrayList.size(); index++) {
				if (fullArrayList.get(index) == 0) {
					break;
				}
				if (oldLaiInlaiComposePosList.get(index) != -1) {
					nextIndex = index;
					break;
				} else {
					nextType = nextType.getPrev();
				}
			}
			int prevIndex = -1;
			FindLaiType prevType = FindLaiType.nextOne;
			for (int index = position - 1; index >= 0; index--) {
				if (fullArrayList.get(index) == 0) {
					break;
				}
				if (oldLaiInlaiComposePosList.get(index) != -1) {
					prevIndex = index;
					break;
				} else {
					prevType = prevType.getNext();
				}
			}
			if (nextIndex != -1 && prevIndex != -1) {
				positionFindTypeList.add(FindLaiType.getFindTarget(nextType,
						oldLaiInlaiComposePosList.get(nextIndex), prevType,
						oldLaiInlaiComposePosList.get(prevIndex)));
			} else if (nextIndex != -1) {
				positionFindTypeList
						.add(nextType.getFindTarget(oldLaiInlaiComposePosList
								.get(nextIndex)));
			} else if (prevIndex != -1) {
				positionFindTypeList
						.add(prevType.getFindTarget(oldLaiInlaiComposePosList
								.get(prevIndex)));
			} else {
				isCanAny = true;
				if (LaiTools.print())
					LoggerService.getPlatformLog().error(
							"找不到牌的位置了，，这个牌型已经爆炸了，，癞子够了，，直接胡任何牌！");
			}
		}
		if (isCanAny)
			positionFindTypeList.add(FindLaiType.AnyPai);
		CxqLai cxqLai = laiMap.get(laiCompose);
		if (cxqLai == null) {
			cxqLai = new CxqLai(0, 0);
			laiMap.put(laiCompose, cxqLai);
		}
		cxqLai.add(fullCompose, positionFindTypeList);
	}

	/**
	 * 获取缺失牌列表
	 * 
	 * @param mjCompose
	 *            手牌数据
	 * @param yiTiaoLong
	 *            是否打一条龙
	 * @param qiYiSeType
	 *            如果清一色，色，如果没有NULL
	 * @return 缺失种牌
	 */
	public void getLackPais(MjCompose mjCompose, boolean yiTiaoLong,
			MjType qiYiSeType) {
		ArrayList<Pai> tingPais = mjCompose.getTingPais();
		ArrayList<ArrayList<HuPaiType>> huPaiTypesList = mjCompose
				.getHuPaiTypesList();
		ArrayList<Pai> p = new ArrayList<Pai>();
		int index = 0;
		boolean isAny = false;
		ArrayList<Pai> list = p;
		for (FindTarget[] types : this.positionFindTypeList) {
			// if (this.fullComposeList.get(index).toString()
			// .equals("2 0 1 1 1 1 1 1 0 1 1 1 1 1 1 ")) {
			// int cc = 0;
			// cc++;
			// }
			if (types == emptyFindTargetArr) {
				if (list != null) {
					for (Pai mj : isAny ? AnyPai : list) {
						ArrayList<HuPaiType> huPaiTypes = null;
						int indexOf = tingPais.indexOf(mj);
						if (indexOf != -1) {
							huPaiTypes = huPaiTypesList.get(indexOf);
						}
						if (huPaiTypes == null) {
							huPaiTypes = new ArrayList<HuPaiType>();
							tingPais.add(mj);
							huPaiTypesList.add(huPaiTypes);
						}
						ArrayList<HuPaiType> paixingHuPaiTypes2 = this.fullComposeList
								.get(index).getPaixingHuPaiTypes(yiTiaoLong);
						if (!paixingHuPaiTypes2.isEmpty()) {
							for (HuPaiType type : paixingHuPaiTypes2)
								if (!huPaiTypes.contains(type))
									huPaiTypes.add(type);
						}
						if (this.fullComposeList.get(index).isCanPengpengHu()
								&& mjCompose.isAllPengOrGang()) {
							huPaiTypes.add(HuPaiType.pengPengHu);
						}
						if (qiYiSeType != null && mj.getType() == qiYiSeType
								&& !huPaiTypes.contains(HuPaiType.qingYiSe)) {
							huPaiTypes.add(HuPaiType.qingYiSe);
						}
						if (mjCompose.isBao(mj)) {
							huPaiTypes.add(HuPaiType.douBao);
						}
						if (huPaiTypes.isEmpty()) {
							huPaiTypes.add(HuPaiType.pingHu);
						}
					}
				}
				index++;
				isAny = false;
				list = p;
				list.clear();
				continue;
			}
			if (list == null) {
				continue;
			}
			if (types == FindLaiType.AnyPai) {
				isAny = true;
				continue;
			}
			Pai pai = null;
			if (types.length == 2) {
				pai = types[0].getType().find(
						mjCompose.getPai(types[0].getIndex()));
				Pai paiT = types[1].getType().find(
						mjCompose.getPai(types[1].getIndex()));
				if (pai != paiT)
					pai = Pai.emptyMj;
			} else if (types.length == 1) {
				pai = types[0].getType().find(
						mjCompose.getPai(types[0].getIndex()));
			}
			if (pai == Pai.emptyMj) {
				list = null;
			} else {
				list.add(pai);
			}
		}
	}

	public int getFullComposeListSize() {
		return fullComposeList.size();
	}

	public int getPositionFindTypeListSize() {
		return positionFindTypeList.size();
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append("fullComposeList:").append(this.fullComposeList.size())
				.append(",positionFindTypeList:")
				.append(this.positionFindTypeList.size());
		return builder.toString();
	}
}
