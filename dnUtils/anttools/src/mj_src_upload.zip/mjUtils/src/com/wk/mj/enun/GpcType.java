package com.wk.mj.enun;

/**
 * 1暗杠 2明杠 3接杠 4碰 5吃
 * 
 * @author ems
 *
 */
public enum GpcType {

	/***/
	AnGang(1),
	/***/
	MingGang(2),
	/***/
	JieGang(3),
	/***/
	Peng(4),
	/***/
	Chi(5);

	private final int type;

	private GpcType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

// 自动生成开始
public static GpcType getEnum(int type){
switch(type) {
case 1:
  return AnGang;
case 2:
  return MingGang;
case 3:
  return JieGang;
case 4:
  return Peng;
case 5:
  return Chi;
default:
  return null;
}
}// 自动生成结束
}