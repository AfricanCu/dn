package com.wk.guild.enm;

public enum JulebuState {
	/**
	 * 审核中
	 */
	apply(1),
	/**
	 * 加入的
	 */
	joined(2),
	/**
	 * 创建的
	 */
	created(3), ;
	private final int type;

	private JulebuState(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	// 自动生成开始
public static JulebuState getEnum(int type){
switch(type) {
case 1:
  return apply;
case 2:
  return joined;
case 3:
  return created;
default:
  return null;
}
}// 自动生成结束
}