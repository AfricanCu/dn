package com.wk.mj;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import msg.MjMessage.Mj;

import com.wk.mj.enun.MjType;

/**
 * 牌
 * 
 * @author ems
 *
 */
public class Pai implements Comparable<Pai> {

	private final static String[] tag = { "", "一", "二", "三", "四", "五", "六",
			"七", "八", "九" };
	private final static String[] fengTag = { "", "东", "南", "西", "北", "中", "發",
			"白" };
	/** 所有牌 */
	private static final HashMap<Integer, Pai> map = new HashMap<>();
	/** 所有牌 */
	private static final HashMap<String, Pai> nameMap = new HashMap<>();
	public static final Pai emptyMj = new Pai(0, null);
	static {
		emptyMj.setNear(emptyMj, emptyMj);
	}

	/**
	 * 获取牌
	 * 
	 * @param mj
	 * @return
	 */
	public static Pai getPai(Mj mj) {
		return MjType.getEnum(mj.getType()).getPaiByNumber(mj.getNum());
	}

	/** 牌下标 */
	private final int index;
	/** 牌号码 */
	private final int number;
	/** 牌花色 */
	private final MjType type;
	/** 前一个麻将 **/
	private Pai prev = emptyMj;
	/** 后一个麻将 */
	private Pai next = emptyMj;
	/** 麻将消息 */
	private final Mj mj;
	/** 麻将id */
	private final int id;

	public Pai(int index, MjType type) {
		super();
		this.index = index;
		this.number = index % 10;
		this.type = type;
		this.mj = Mj.newBuilder().setNum(this.number)
				.setType(this.type == null ? 0 : this.getTypeValue()).build();
		this.id = this.type == null ? 0 : this.type.getType() * 100
				+ this.index;
		map.put(this.id, this);
		if (this.type != null) {
			String format = String.format("%s%s",
					this.type == MjType.feng ? fengTag[number] : tag[number],
					this.type.toString());
			nameMap.put(format, this);
		} else {
			nameMap.put("空牌", this);
		}
	}

	/**
	 * 牌下标
	 * 
	 * @return
	 */
	public int getIndex() {
		return index;
	}

	/**
	 * 牌号码
	 * 
	 * @return
	 */
	public int getNumber() {
		return number;
	}

	public String getImages() {
		if (this == emptyMj) {
			return "com/wk/mj/images/kong.gif";
		}
		return "com/wk/mj/images/" + this.index + ".gif";
	}

	/**
	 * 牌花色
	 * 
	 * @return
	 */
	public MjType getType() {
		return type;
	}

	/**
	 * 牌花色
	 * 
	 * @return
	 */
	public int getTypeValue() {
		return type.getType();
	}

	@Override
	public int compareTo(Pai o) {
		if (this == o) {
			return 0;
		} else if (this.type.getType() > o.type.getType()) {
			return 1;
		} else if (this.type.getType() < o.type.getType()) {
			return -1;
		} else if (this.number > o.number)
			return 1;
		else
			return -1;
	}

	@Override
	public boolean equals(Object obj) {
		return super.equals(obj);
	}

	@Override
	public String toString() {
		if (this == Pai.emptyMj) {
			return "空牌";
		}
		return String.format("%s%s", this.type == MjType.feng ? fengTag[number]
				: tag[number], this.type.toString());
	}

	public boolean isTong() {
		return this.type == MjType.tong;
	}

	public boolean isSuo() {
		return this.type == MjType.suo;
	}

	public boolean isWang() {
		return this.type == MjType.wang;
	}

	/**
	 * 是否是将
	 * 
	 * @return
	 */
	public boolean isJiang() {
		return this.number == 2 || this.number == 5 || this.number == 8;
	}

	public void setNear(Pai prev, Pai next) {
		this.prev = prev;
		this.next = next;
	}

	public Pai getPrev() {
		return prev;
	}

	public Pai getNext() {
		return next;
	}

	/**
	 * 生成麻将消息
	 * 
	 * @return
	 */
	public Mj getMj() {
		return this.mj;
	}

	public int getId() {
		return id;
	}

	public static Pai getPai(int id) {
		return map.get(id);
	}

	public static Pai getPai(String name) {
		return nameMap.get(name);
	}

	public boolean isFeng() {
		return this.type == MjType.feng;
	}

	/**
	 * 两个牌必须是 147 / 258 /369
	 * 
	 * @param tmp
	 * @return
	 */
	public boolean is147258369(Pai tmp) {
		if (this.number == 1 || this.number == 4 || this.number == 7) {
			return tmp.number == 7 || tmp.number == 4 || tmp.number == 1;
		} else if (this.number == 2 || this.number == 5 || this.number == 8) {
			return tmp.number == 8 || tmp.number == 5 || tmp.number == 2;
		} else {
			return tmp.number == 9 || tmp.number == 6 || tmp.number == 3;
		}
	}

	/**
	 * 
	 * @param paiList
	 *            十三烂这个色有的牌队列
	 * @param retPaiList
	 *            返回没有的牌队列
	 */
	public static void get147258369Type(List<Pai> paiList, List<Pai> retPaiList) {
		Pai pai = paiList.get(0);
		if (pai.isFeng()) {
			for (Pai p : MjType.feng.getMjList()) {
				if (!paiList.contains(p)) {
					retPaiList.add(p);
				}
			}
		} else {
			if (pai.number == 1 || pai.number == 4 || pai.number == 7) {
				for (int index : new int[] { 0, 3, 6 }) {
					Pai p = pai.getType().getPaiByIndex(index);
					if (!paiList.contains(p)) {
						retPaiList.add(p);
					}
				}
			} else if (pai.number == 2 || pai.number == 5 || pai.number == 8) {
				for (int index : new int[] { 1, 4, 7 }) {
					Pai p = pai.getType().getPaiByIndex(index);
					if (!paiList.contains(p)) {
						retPaiList.add(p);
					}
				}
			} else {
				for (int index : new int[] { 2, 5, 8 }) {
					Pai p = pai.getType().getPaiByIndex(index);
					if (!paiList.contains(p)) {
						retPaiList.add(p);
					}
				}
			}
		}
	}

	/** 间距>2 */
	public boolean isDirectOverTwo(Pai pai) {
		return pai.number - this.number > 2;
	}

	public static void getDirectOverTwo(List<Pai> paiList, List<Pai> retPaiList) {
		int size = paiList.size();
		if (size == 3) {
			return;
		} else if (size == 2) {
			Pai paiOne = paiList.get(0);
			Pai paiTwo = paiList.get(1);
			if (paiTwo.getNumber() - paiOne.getNumber() > 5) {
				for (int beginNumber = paiOne.getNumber() + 3; beginNumber < paiTwo
						.getNumber() - 2; beginNumber++) {
					retPaiList
							.add(paiOne.getType().getPaiByNumber(beginNumber));
				}
			} else {
				for (int beginNumber = 1; beginNumber < paiOne.getNumber() - 2; beginNumber++) {
					retPaiList
							.add(paiOne.getType().getPaiByNumber(beginNumber));
				}
				for (int beginNumber = paiTwo.getNumber() + 3; beginNumber <= 9; beginNumber++) {
					retPaiList
							.add(paiTwo.getType().getPaiByNumber(beginNumber));
				}
			}
		} else if (size == 1) {
			Pai pai = paiList.get(0);
			for (int beginNumber = 1; beginNumber < pai.getNumber() - 2; beginNumber++) {
				retPaiList.add(pai.getType().getPaiByNumber(beginNumber));
			}
			for (int beginNumber = pai.getNumber() + 3; beginNumber <= 9; beginNumber++) {
				retPaiList.add(pai.getType().getPaiByNumber(beginNumber));
			}
		} else {
			System.err.println(String.format("严重错误！ - %s ,size=%s",
					new Exception().getStackTrace()[0], size));
		}
	}
}
