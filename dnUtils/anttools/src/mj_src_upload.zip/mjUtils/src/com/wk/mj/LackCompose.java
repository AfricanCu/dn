package com.wk.mj;

import com.wk.mj.enun.LackReferenceType;

/**
 * 缺失牌型
 * 
 * @author ems
 *
 */
public class LackCompose {

	/** 完整牌型 ***/
	private final Compose fullCompose;
	/** 缺失那张位置 **/
	private final int lackIndex;
	/** 缺失牌型 ***/
	private final Compose lackCompose;
	/** 通过哪种方式牌查找缺失牌 ***/
	private final LackReferenceType lackReferenceType;

	public LackCompose(Compose fullCompose, int lackIndex, Compose lackCompose,
			LackReferenceType lackReferenceType) {
		super();
		this.fullCompose = fullCompose;
		this.lackIndex = lackIndex;
		this.lackCompose = lackCompose;
		this.lackReferenceType = lackReferenceType;
	}

	public Compose getFullCompose() {
		return fullCompose;
	}

	public Compose getLackCompose() {
		return lackCompose;
	}

	public long getNumber() {
		return this.lackCompose.getNumber();
	}

	/**
	 * 获取缺失牌
	 * 
	 * @param mjCompose
	 *            手牌数据
	 * @return 缺失种牌
	 */
	public Pai getLackPai(MjCompose mjCompose) {
		if (!this.lackCompose.checkDuiJiang(mjCompose.getZiList())) {
			return Pai.emptyMj;
		}
		return this.lackReferenceType.getMj(mjCompose.getZiList(),
				this.lackIndex);
	}

	public String toString() {
		return String.format("[%s]  [%s]  [%s]", this.fullCompose.toString(),
				this.lackIndex, this.lackCompose.toString());
	}
}
