package com.wk.mj;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.wk.mj.enun.MjType;
import com.wk.util.NRandom;

public class MjUtils {
	/*** 无风子的一套牌 **/
	private static List<Pai> noFengPaiList;
	/*** 有风子的一套牌 **/
	private static List<Pai> hasFengPaiList;
	/** 无风子牌种 **/
	private static List<Pai> sortNoFengPais;
	/** 有风子牌种 **/
	private static List<Pai> sortHasFengPais;
	/** 将将胡听2,5,8 */
	private static final ArrayList<Pai> jiangjiang_tingPais = new ArrayList<>();
	static {
		for (MjType type : MjType.noFeng()) {
			jiangjiang_tingPais.add(type.getPaiByNumber(2));
			jiangjiang_tingPais.add(type.getPaiByNumber(5));
			jiangjiang_tingPais.add(type.getPaiByNumber(8));
		}
	}

	public static List<Pai> getJiangjiang_tingPais() {
		return jiangjiang_tingPais;
	}

	/** 随机生成无风子麻将 **/
	public static List<Pai> genNoFengPais() {
		return Collections.unmodifiableList(NRandom
				.genArrayListSequence(getNoFengPaiList()));
	}

	/** 随机生成有风子麻将 **/
	public static List<Pai> genHasFengPais() {
		return Collections.unmodifiableList(NRandom
				.genArrayListSequence(getHasFengPaiList()));
	}

	private static List<Pai> init(boolean hasFeng) {
		List<Pai> sortMjList = null;
		if (hasFeng) {
			sortMjList = getSortHasFengPais();
		} else {
			sortMjList = getSortNoFengPais();
		}
		ArrayList<Pai> list = new ArrayList<Pai>();
		for (Pai mj : sortMjList) {
			for (int i = 0; i < 4; i++) {
				list.add(mj);
			}
		}
		return list;
	}

	/** 无风子的麻将 ***/
	public static List<Pai> getNoFengPaiList() {
		if (noFengPaiList == null)
			noFengPaiList = init(false);
		return noFengPaiList;
	}

	/** 有风子的麻将 **/
	public static List<Pai> getHasFengPaiList() {
		if (hasFengPaiList == null)
			hasFengPaiList = init(true);
		return hasFengPaiList;
	}

	/**
	 * 无风子27个牌
	 * 
	 * @return
	 */
	public static List<Pai> getSortNoFengPais() {
		if (sortNoFengPais == null) {
			ArrayList<Pai> list = new ArrayList<Pai>();
			for (MjType type : MjType.noFeng()) {
				list.addAll(type.getMjList());
			}
			sortNoFengPais = Collections.unmodifiableList(list);
		}
		return sortNoFengPais;
	}

	/**
	 * 有风子34个牌
	 * 
	 * @return
	 */
	public static List<Pai> getSortHasFengPais() {
		if (sortHasFengPais == null) {
			ArrayList<Pai> list = new ArrayList<Pai>();
			for (MjType type : MjType.values()) {
				list.addAll(type.getMjList());
			}
			sortHasFengPais = Collections.unmodifiableList(list);
		}
		return sortHasFengPais;
	}
}
