package com.wk.bean;

/**
 * 记录
 * 
 * @author ems
 *
 */
public class GamerecordBean {
	private int id;
	private byte[] data = SystemConstantsAbs.empltyBytes;

	public GamerecordBean() {
	}

	public GamerecordBean(int id, byte[] data) {
		super();
		this.id = id;
		this.data = data;
	}

	public int getId() {
		return id;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		if (data == null) {
			return;
		}
		this.data = data;
	}

}
