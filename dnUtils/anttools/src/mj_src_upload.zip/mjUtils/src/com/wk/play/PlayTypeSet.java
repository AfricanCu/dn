package com.wk.play;

import java.util.ArrayList;
import java.util.List;

import msg.RoomMessage.PlayType;

import com.wk.mj.enun.HuPaiType;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

/**
 * 玩法设置
 * 
 * @author ems
 *
 */
public class PlayTypeSet {
	private final BankerMode bankerMode;
	private final SeveralNiaoType severalNiaoType;
	private final TimesLimitType timesLimitType;
	private final ZhaNiaoType zhaNiaoType;
	private final boolean yiZiQiaoYouXi;
	private final boolean mengQing;
	private final boolean mengQingJiangJiangJiePao;
	private final boolean baoTing;
	private final boolean diHu;
	private final AreaPlayTypeI huPaiTypeTimesI;

	public PlayTypeSet(PlayType playType, AreaPlayTypeI huPaiTypeTimesI)
			throws Exception {
		super();
		this.huPaiTypeTimesI = huPaiTypeTimesI;
		this.bankerMode = this.huPaiTypeTimesI.getBankerMode(playType);
		this.severalNiaoType = this.huPaiTypeTimesI
				.getSeveralNiaoType(playType);
		this.timesLimitType = this.huPaiTypeTimesI.getTimesLimitType(playType);
		this.zhaNiaoType = this.huPaiTypeTimesI.getZhaNiaoType(playType);
		this.yiZiQiaoYouXi = this.huPaiTypeTimesI.getYiZiQiaoYouXi(playType);
		this.mengQing = this.huPaiTypeTimesI.isMengQing(playType);
		this.mengQingJiangJiangJiePao = this.huPaiTypeTimesI
				.isMengQingJiangJiangJiePao(playType);
		this.baoTing = this.huPaiTypeTimesI.isBaoTing(playType);
		this.diHu = this.huPaiTypeTimesI.isDiHu(playType);
	}

	public BankerMode getBankerMode() {
		return bankerMode;
	}

	public SeveralNiaoType getSeveralNiaoType() {
		return severalNiaoType;
	}

	public TimesLimitType getTimesLimitType() {
		return timesLimitType;
	}

	public ZhaNiaoType getZhaNiaoType() {
		return zhaNiaoType;
	}

	public boolean isYiZiQiaoYouXi() {
		return yiZiQiaoYouXi;
	}

	public boolean isYiTiaoLong() {
		return huPaiTypeTimesI.isYiTiaoLong();
	}

	public boolean isMengQing() {
		return mengQing;
	}

	public boolean isMengQingJiangJiangJiePao() {
		return mengQingJiangJiangJiePao;
	}

	public boolean isBaoTing() {
		return baoTing;
	}

	public boolean isDiHu() {
		return diHu;
	}

	public boolean isYiZiQiao() {
		return huPaiTypeTimesI.isYiZiQiao();
	}

	public boolean isJiangJianghu() {
		return huPaiTypeTimesI.isJiangJianghu();
	}

	public boolean isFeng() {
		return huPaiTypeTimesI.isFeng();
	}

	public boolean isShiSanLan() {
		return isFeng() && huPaiTypeTimesI.isShiSanLan();
	}

	public boolean isHunYiSe() {
		return isFeng() && huPaiTypeTimesI.isHunYiSe();
	}

	public boolean isPingHuJiePao() {
		return huPaiTypeTimesI.isPingHuJiePao();
	}

	public boolean isFeiBao() {
		return huPaiTypeTimesI.isFeiBao();
	}

	public boolean isLai() {
		return huPaiTypeTimesI.isLai();
	}

	public boolean isChi() {
		return huPaiTypeTimesI.isChi();
	}

	public boolean isMingGangSuanJieGang() {
		return this.huPaiTypeTimesI.isMingGangSuanJieGang();
	}

	public int getTimes(HuPaiType huPaiType) {
		return this.huPaiTypeTimesI.getTimes(huPaiType, this);
	}

	/**
	 * 计算胡牌番数
	 * 
	 * @param arrayList
	 * @return
	 */
	public final int calcFan(ArrayList<HuPaiType> arrayList) {
		int calcFan = this.huPaiTypeTimesI.calcFan(arrayList, this);
		return calcFan > this.timesLimitType.getTimesLimit() ? this.timesLimitType
				.getTimesLimit() : calcFan;
	}

	public boolean isRightNowZhuaCanMingGang() {
		return huPaiTypeTimesI.isRightNowZhuaCanMingGang();
	}

	public boolean isJiePaoJiangNiao() {
		return this.huPaiTypeTimesI.isJiePaoJiangNiao();
	}

	public boolean isJiaZhang() {
		return this.huPaiTypeTimesI.isJiaZhang();
	}

	public boolean isRoundDoubleHu() {
		return this.huPaiTypeTimesI.isRoundDoubleHu();
	}

	public boolean isJiangJiangHuJiePao() {
		return this.isJiangJianghu()
				&& this.huPaiTypeTimesI.isJiangJiangHuJiePao();
	}

	public boolean isPinghuBaoTingJiePao() {
		return this.isBaoTing() && this.huPaiTypeTimesI.isPinghuBaoTingJiePao();
	}

	public boolean isBaoTingOverJiePaoNextNot() {
		return this.isBaoTing()
				&& this.huPaiTypeTimesI.isBaoTingOverJiePaoNextNot();
	}

	/** 如果打一字撬有喜，只是单纯的碰碰胡，最后剩下两对， 不能接炮 **/
	public boolean isKaQiao() {
		return this.isYiZiQiaoYouXi();
	}
	
	public boolean isHaiDi(){
		return this.huPaiTypeTimesI.isHaiDi();
	}

	public HuPaiType getQuanQiuRenType() {
		return this.huPaiTypeTimesI.getQuanQiuRenType();
	}
}
