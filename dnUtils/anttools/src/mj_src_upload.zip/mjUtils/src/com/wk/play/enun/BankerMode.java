package com.wk.play.enun;

import com.wk.engine.config.ServerConfigAbs;

/**
 * 开房局数模式
 * 
 * 
 * @author ems
 *
 */
public enum BankerMode {
	/**
	 * 
	 */
	FIX_8_ROUND_DOWN("8局", 1, 8, 1) {

	},
	/**
	 * 
	 */
	FIX_16_ROUND_DOWN("16局", 2, 16, 2) {

	};
	private final int type;
	private final int num;
	private final int needDiamond;
	private final String name;

	/**
	 * 
	 * @param type
	 */
	private BankerMode(String name, int type, int num, int needDiamond) {
		this.name = name;
		this.type = type;
		this.num = num;
		this.needDiamond = needDiamond;
	}

	public String getName() {
		return name;
	}

	public int getType() {
		return type;
	}

	public int getNum() {
		return this.num;
	}

	public int getNeedDiamond() {
		if(ServerConfigAbs.isCloseDiamondConsume()){
			return 0;
		}
		return needDiamond;
	}

	// 自动生成开始
public static BankerMode getEnum(int type){
switch(type) {
case 1:
  return FIX_8_ROUND_DOWN;
case 2:
  return FIX_16_ROUND_DOWN;
default:
  return null;
}
}// 自动生成结束
}