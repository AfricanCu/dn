package com.wk.mj.enun;

/**
 * 获取胡牌的方式
 * 
 * @author ems
 *
 */
public enum GetHuPaiType {
	/****/
	jiePao(1),
	/****/
	ziMo(2),
	/****/
	qiangGang(3);
	private final int type;

	private GetHuPaiType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

// 自动生成开始
public static GetHuPaiType getEnum(int type){
switch(type) {
case 1:
  return jiePao;
case 2:
  return ziMo;
case 3:
  return qiangGang;
default:
  return null;
}
}// 自动生成结束
}