package com.wk.mj;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.enun.HuPaiType;

/**
 * 牌型
 * 
 * @author ems
 *
 */
public class Compose extends ArrListAbs implements Serializable {
	private static final long serialVersionUID = 1L;

	/** 牌型类胡牌类型 **/
	private ArrayList<HuPaiType> paixingHuPaiTypes = null;
	/** 无一条龙牌型类胡牌类型 **/
	private ArrayList<HuPaiType> noYiTiaoLongPaixingHuPaiTypes = null;
	/** 如果有对将，将的位置 */
	private List<Integer> duiJiangIndexList;
	/** 是不是23..3牌型 ,可以打碰碰胡 **/
	private boolean canPengpengHu;

	/**
	 * 空数据，无对将
	 */
	public Compose() {
		this(new ArrayList<Integer>(), null);
	}

	/**
	 * 
	 * @param list
	 *            牌数列表
	 * @param duiJiangIndex
	 *            如果有对将，将的位置
	 */
	public Compose(List<Integer> list, List<Integer> duiJiangIndexList) {
		super(list);
		this.duiJiangIndexList = duiJiangIndexList;
	}

	/**
	 * 初始化按照牌型检测的胡牌类型列表
	 */
	public void initPaixingHuPai() {
		this.paixingHuPaiTypes = new ArrayList<HuPaiType>(0);
		// 一条龙
		int yiTiaoLongSize = 0;
		int ytlTmp = 0;
		for (int xx : this.getArrayList()) {
			if (xx > 0) {
				ytlTmp++;
			} else {
				if (ytlTmp > yiTiaoLongSize) {
					yiTiaoLongSize = ytlTmp;
				}
				ytlTmp = 0;
			}
		}
		if (ytlTmp > yiTiaoLongSize) {
			yiTiaoLongSize = ytlTmp;
		}
		if (yiTiaoLongSize == 9) {
			this.paixingHuPaiTypes.add(HuPaiType.yiTiaoLong);
		}
		// 小七对
		int xiaoQiDuiCount = 0;
		int haoHuangCount = 0;
		for (int xx : this.getArrayList()) {
			if (xx >= 2) {
				if (xx % 2 != 0) {
					xiaoQiDuiCount = ListMjAbs.CAN_NOT_DUI;
				} else {
					if (xiaoQiDuiCount != ListMjAbs.CAN_NOT_DUI) {
						xiaoQiDuiCount += xx / 2;
						if (xx == 4) {
							haoHuangCount++;
						}
					}
				}
			} else if (xx != 0) {
				xiaoQiDuiCount = ListMjAbs.CAN_NOT_DUI;
			}
		}
		if (xiaoQiDuiCount == 7) {
			if (MjTools.print())
				LoggerService.getPlatformLog().error(this.toString());
			switch (haoHuangCount) {
			case 0:
				this.paixingHuPaiTypes.add(HuPaiType.xiaoQiDui);
				break;
			case 1:
				this.paixingHuPaiTypes.add(HuPaiType.haoHuaXiaoQiDui);
				break;
			case 2:
				this.paixingHuPaiTypes.add(HuPaiType.doubleHaoHuaXiaoQiDui);
				break;
			case 3:
				this.paixingHuPaiTypes.add(HuPaiType.threeHaoHuaXiaoQiDui);
				break;
			default:
				break;
			}
		}
		// 碰碰胡
		boolean pengPeng = true;
		int duiCount = 0;
		for (int xx : this.getArrayList()) {
			if (xx != 0) {
				if (xx == 2) {
					duiCount++;
				} else if (xx != 3)
					pengPeng = false;
			}
		}
		if (duiCount == 1 && pengPeng) {
			this.canPengpengHu = true;
		}
		if (this.paixingHuPaiTypes.contains(HuPaiType.yiTiaoLong)) {
			this.noYiTiaoLongPaixingHuPaiTypes = new ArrayList<>(
					this.paixingHuPaiTypes);
			noYiTiaoLongPaixingHuPaiTypes.remove(HuPaiType.yiTiaoLong);
		} else {
			noYiTiaoLongPaixingHuPaiTypes = this.paixingHuPaiTypes;
		}
	}

	public boolean isCanPengpengHu() {
		return canPengpengHu;
	}

	/**
	 * 
	 * @param yiTiaoLong
	 *            是否打一条龙
	 * @return
	 */
	public ArrayList<HuPaiType> getPaixingHuPaiTypes(boolean yiTiaoLong) {
		if (yiTiaoLong) {
			return this.paixingHuPaiTypes;
		}
		return noYiTiaoLongPaixingHuPaiTypes;
	}

	public List<Integer> getDuiJiangIndexList() {
		return duiJiangIndexList;
	}

	public void resetDuijiangIndexList(Compose other) {
		if (this.duiJiangIndexList == null || other.duiJiangIndexList == null) {
			this.duiJiangIndexList = null;
		} else {
			for (int duiJiangIndex : other.duiJiangIndexList) {
				if (!this.duiJiangIndexList.contains(duiJiangIndex))
					this.duiJiangIndexList.add(duiJiangIndex);
			}
			if (this.duiJiangIndexList.size() > 1) {
				LoggerService.getPlatformLog().error("变大了！{}",
						this.duiJiangIndexList);
			}
		}
	}

	public boolean isNeedDuiJiang() {
		return MjTools.isNeedduijiang() && this.duiJiangIndexList != null
				&& !this.duiJiangIndexList.isEmpty();
	}

	/**
	 * 要求有一对将才能胡牌
	 * 
	 * @param ziList
	 * @return
	 */
	public boolean checkDuiJiang(List<Pai> ziList) {
		if (!isNeedDuiJiang()) {
			return true;
		}
		for (int duiJiangIndex : this.duiJiangIndexList) {
			if (ziList.get(duiJiangIndex).isJiang()) {
				return true;
			}
		}
		return false;
	}

	/***
	 * 组合两种牌型 中间用0隔开
	 * 
	 * @param compose1
	 * @param compose2
	 * @return
	 */
	public static Compose combine(Compose compose1, Compose compose2) {
		List<Integer> ret = new ArrayList<Integer>(compose1.getArrayListSize()
				+ compose2.getArrayListSize() + 1);
		ret.addAll(compose1.getArrayList());
		ret.add(0);
		ret.addAll(compose2.getArrayList());
		List<Integer> duiJiangIndexList1 = compose1.getDuiJiangIndexList();
		List<Integer> duiJiangIndexList2 = compose2.getDuiJiangIndexList();
		if (duiJiangIndexList1 != null && duiJiangIndexList2 != null) {
			LoggerService.getPlatformLog().error("最多一个对将,两个对将，不正常！");
			return null;
		}
		List<Integer> duiJiangIndexListRet = null;
		if (duiJiangIndexList1 != null) {
			duiJiangIndexListRet = duiJiangIndexList1;
		} else if (duiJiangIndexList2 != null) {
			duiJiangIndexListRet = new ArrayList<>();
			for (int duiJiangIndex : duiJiangIndexList2) {
				duiJiangIndexListRet.add(compose1.getArrayListSize() + 1
						+ duiJiangIndex);
			}
		}
		return new Compose(ret, duiJiangIndexListRet);
	}

}