package com.wk.mj.lai;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.wk.mj.Pai;

/**
 * 查找癞子类型
 * 
 * @author Administrator
 *
 */
public enum FindLaiType {
	/****/
	prevFive(1) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			return ret;
		}
	},
	/****/
	prevFour(2) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			return ret;
		}
	},
	/****/
	prevThree(3) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			return ret;
		}
	},
	/****/
	prevTwo(4) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getPrev();
			if (ret != Pai.emptyMj)
				ret = ret.getPrev();
			return ret;
		}
	},
	/****/
	prevOne(5) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getPrev();
			return ret;
		}
	},
	/****/
	cur(6) {
		@Override
		public Pai find(Pai pai) {
			return pai;
		}
	},
	/****/
	nextOne(7) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getNext();
			return ret;
		}
	},
	/****/
	nextTwo(8) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			return ret;
		}
	},
	/****/
	nextThree(9) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			return ret;
		}
	},
	/****/
	nextFour(10) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			return ret;
		}
	},
	/****/
	nextFive(11) {
		@Override
		public Pai find(Pai pai) {
			Pai ret = pai.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			if (ret != Pai.emptyMj)
				ret = ret.getNext();
			return ret;
		}
	},
	/****/
	;
	private static final int listSize = 18;
	private final int type;
	private final List<FindTarget[]> list = new ArrayList<>(listSize);
	private FindLaiType next;
	private FindLaiType prev;

	private FindLaiType(int type) {
		this.type = type;
		for (int index = 0; index < listSize; index++) {
			list.add(new FindTarget[] { new FindTarget(index, this) });
		}
	}

	public int getType() {
		return type;
	}

	public abstract Pai find(Pai pai);

	public FindLaiType getNext() {
		if (next == null)
			next = FindLaiType.getEnum(this.type + 1);
		return next;
	}

	public FindLaiType getPrev() {
		if (prev == null)
			prev = FindLaiType.getEnum(this.type - 1);
		return prev;
	}

	public FindTarget[] getFindTarget(int index) {
		return list.get(index);
	}

	/**
	 * 缓存查找对象Map，避免内存消耗
	 */
	private static final HashMap<Integer, FindTarget[]> map = new HashMap<>();

	public static FindTarget[] getFindTarget(FindLaiType nextType,
			int nextIndex, FindLaiType prevType, int prevIndex) {
		Integer key = nextType.getType() << 24 | nextIndex << 16
				| prevType.getType() << 8 | prevIndex;
		FindTarget[] findTargets = map.get(key);
		if (findTargets == null) {
			findTargets = new FindTarget[] { nextType.list.get(nextIndex)[0],
					prevType.list.get(prevIndex)[0] };
			map.put(key, findTargets);
		}
		return findTargets;
	}

	/**
	 * 这是一个自由位置，，可以指示任何牌
	 */
	public static final FindTarget[] AnyPai = new FindTarget[] {};

	public static class FindTarget implements Serializable {
		private static final long serialVersionUID = 1L;
		private final int index;
		private final FindLaiType type;

		/**
		 * 
		 * @param index
		 *            癞子牌型位置
		 * @param type
		 *            查找癞子类型
		 */
		private FindTarget(int index, FindLaiType type) {
			this.index = index;
			this.type = type;
		}

		public int getIndex() {
			return index;
		}

		public FindLaiType getType() {
			return type;
		}
	}

	// 自动生成开始
public static FindLaiType getEnum(int type){
switch(type) {
case 1:
  return prevFive;
case 2:
  return prevFour;
case 3:
  return prevThree;
case 4:
  return prevTwo;
case 5:
  return prevOne;
case 6:
  return cur;
case 7:
  return nextOne;
case 8:
  return nextTwo;
case 9:
  return nextThree;
case 10:
  return nextFour;
case 11:
  return nextFive;
default:
  return null;
}
}// 自动生成结束
}