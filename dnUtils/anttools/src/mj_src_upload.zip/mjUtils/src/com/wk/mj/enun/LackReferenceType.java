package com.wk.mj.enun;

import java.util.List;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.Pai;

/**
 * 查找缺牌方式
 * 
 * @author ems
 *
 */
public enum LackReferenceType {
	/**
	 * <pre>
	 * 通过前面的牌查找后一个
	 * 
	 * X__
	 * </pre>
	 */
	prev {
		@Override
		public Pai getMj(List<Pai> list, int lackIndex) {
			Pai pai = lackIndex - 1 >= 0 ? list.get(lackIndex - 1).getNext()
					: Pai.emptyMj;
			if (pai != Pai.emptyMj) {
				Pai nextPai = lackIndex + 1 < list.size() ? list
						.get(lackIndex + 1) : Pai.emptyMj;
				if (nextPai != Pai.emptyMj && pai.getNext() == nextPai) {
					LoggerService.getPlatformLog().error("cut!");
					pai = Pai.emptyMj;
				}
			}
			return pai;
		}
	},
	/**
	 * <pre>
	 * 通过后面的牌查找前一个
	 * 
	 * __X
	 * </pre>
	 */
	next {
		@Override
		public Pai getMj(List<Pai> list, int lackIndex) {
			Pai pai = lackIndex + 1 < list.size() ? list.get(lackIndex + 1)
					.getPrev() : Pai.emptyMj;
			if (pai != Pai.emptyMj) {
				Pai prevPai = lackIndex - 1 >= 0 ? list.get(lackIndex - 1)
						: Pai.emptyMj;
				if (prevPai != Pai.emptyMj && pai.getPrev() == prevPai) {
					LoggerService.getPlatformLog().error("cut!");
					pai = Pai.emptyMj;
				}
			}
			return pai;
		}
	},
	/**
	 * <pre>
	 * 当前位置就是
	 * 
	 * 
	 * </pre>
	 */
	current {
		@Override
		public Pai getMj(List<Pai> list, int lackIndex) {
			return list.get(lackIndex);
		}
	},
	/**
	 * <pre>
	 * 通过前后查找中间一个
	 * 
	 * X_X
	 * </pre>
	 */
	betwwen {
		@Override
		public Pai getMj(List<Pai> list, int lackIndex) {
			Pai prevMj = lackIndex - 1 >= 0 ? list.get(lackIndex - 1).getNext()
					: Pai.emptyMj;
			Pai nextMj = lackIndex + 1 < list.size() ? list.get(lackIndex + 1)
					.getPrev() : Pai.emptyMj;
			return prevMj == nextMj ? prevMj : Pai.emptyMj;
		}
	};

	public abstract Pai getMj(List<Pai> list, int lackIndex);
}
