package com.wk.mj;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.MjType;

public class ShiSanLanUtils {
	/**
	 * 十三烂牌型，包括有癞子的
	 */
	public static final List<Map.Entry<Long, String>> shiSanLanNumber = new ArrayList<>();
	static {
		long a = 0b10010010010010010010010010010010010010l;
		shiSanLanNumber.add(new EntryImpl(a));
		for (int i = 1; i <= 8; i++) {
			shiSanLanNumber.add(new EntryImpl(a >>= 3l));
		}
	}

	public static class EntryImpl implements Map.Entry<Long, String> {
		private final long key;
		private final String value;

		private EntryImpl(long key) {
			this.key = key;
			this.value = Long.toBinaryString(this.key);
		}

		@Override
		public Long getKey() {
			return key;
		}

		@Override
		public String getValue() {
			return value;
		}

		@Override
		public String setValue(String value) {
			// TODO Auto-generated method stub
			return null;
		}

		@Override
		public String toString() {
			return "[key=" + key + ", value=" + value + "]";
		}
	}

	public static Long getShiSanLanNumber(int laiNum) {
		return shiSanLanNumber.get(laiNum).getKey();
	}

	/**
	 * 加入十三烂的判断
	 * 
	 * 非字牌间距大于2
	 * 
	 * @param mjCompose
	 */
	public static void shiSanLan(MjCompose mjCompose) {
		ArrayList<Pai> ziList = mjCompose.getZiList();
		ArrayList<Pai> tingPais = mjCompose.getTingPais();
		ArrayList<ArrayList<HuPaiType>> huPaiTypesList = mjCompose
				.getHuPaiTypesList();
		int tmp = 0;
		Pai lastOne = ziList.get(0);
		for (int index = 1; index < ziList.size(); index++) {
			Pai pai = ziList.get(index);
			if (pai == Pai.emptyMj)
				continue;
			if (pai.isFeng()) {
				break;
			}
			if (pai.getType() == ziList.get(tmp).getType()) {
				if (!lastOne.isDirectOverTwo(pai)) {
					return;
				}
			} else {
				tmp = index;
			}
			lastOne = pai;
		}
		List<Pai> list = new ArrayList<>();
		int countFeng = 0;
		for (Pai pai : ziList) {
			if (pai.getType() == MjType.feng) {
				countFeng++;
			}
		}
		int tmpIndex = 0;
		List<Pai> paiList = new ArrayList<Pai>(3);
		paiList.add(ziList.get(tmpIndex));
		for (int index = 1; index < ziList.size(); index++) {
			Pai pai = ziList.get(index);
			if (pai == Pai.emptyMj)
				continue;
			if (pai.getType() != ziList.get(tmpIndex).getType()) {
				Pai.getDirectOverTwo(paiList, list);
				paiList.clear();
				paiList.add(pai);
				tmpIndex = index;
			} else {
				paiList.add(pai);
			}
			if (pai.getType() == MjType.feng) {
				List<Pai> subList = ziList.subList(tmpIndex, ziList.size());
				for (Pai p : MjType.feng.getMjList()) {
					if (!subList.contains(p)) {
						list.add(p);
					}
				}
				break;
			}
		}
		tingPais.addAll(list);
		for (int index = 0; index < list.size(); index++) {
			ArrayList<HuPaiType> huPaiTypes = new ArrayList<HuPaiType>();
			if (list.get(index).isFeng() ? countFeng >= 6 : countFeng >= 7) {
				huPaiTypes.add(HuPaiType.qiXingShiSanLan);
			} else
				huPaiTypes.add(HuPaiType.shiSanLan);
			huPaiTypesList.add(huPaiTypes);
		}
	}

	/**
	 * 萍乡十三烂
	 * 
	 * @param mjCompose
	 */
	public static void pingxiangShiSanLan(MjCompose mjCompose) {
		ArrayList<Pai> ziList = mjCompose.getZiList();
		ArrayList<Pai> tingPais = mjCompose.getTingPais();
		ArrayList<ArrayList<HuPaiType>> huPaiTypesList = mjCompose
				.getHuPaiTypesList();
		Pai tmp = ziList.get(0);
		for (int index = 1; index < ziList.size(); index++) {
			Pai pai = ziList.get(index);
			if (pai == Pai.emptyMj)
				continue;
			if (pai.isFeng()) {
				break;
			}
			if (tmp.getType() == pai.getType()) {
				if (!tmp.is147258369(pai)) {
					return;
				}
			} else {
				tmp = pai;
			}
		}
		int tmpIndex = 0;
		List<Pai> list = new ArrayList<>();
		int countFeng = mjCompose.getCountLai();
		for (Pai pai : ziList) {
			if (pai.getType() == MjType.feng) {
				countFeng++;
			}
		}
		for (int index = 1; index < ziList.size(); index++) {
			Pai pai = ziList.get(index);
			if (pai == Pai.emptyMj)
				continue;
			if (pai.getType() != ziList.get(tmpIndex).getType()) {
				Pai.get147258369Type(ziList.subList(tmpIndex, index), list);
				tmpIndex = index;
			}
			if (pai.getType() == MjType.feng) {
				Pai.get147258369Type(ziList.subList(tmpIndex, ziList.size()),
						list);
				break;
			}
		}
		tingPais.addAll(list);
		for (int index = 0; index < list.size(); index++) {
			ArrayList<HuPaiType> huPaiTypes = new ArrayList<HuPaiType>();
			if (list.get(index).isFeng() ? countFeng >= 6 : countFeng >= 7) {
				huPaiTypes.add(HuPaiType.pingxiangQiXingShiSanLan);
			} else
				huPaiTypes.add(HuPaiType.pingxiangShiSanLan);
			huPaiTypesList.add(huPaiTypes);
		}
	}

}
