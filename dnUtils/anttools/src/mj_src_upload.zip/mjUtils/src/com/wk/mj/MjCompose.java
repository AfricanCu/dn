package com.wk.mj;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.enun.GetHuPaiType;
import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.MjType;
import com.wk.mj.lai.CxqLai;
import com.wk.mj.lai.LaiTools;

/**
 * 手牌数据
 * 
 * <pre>
 * 听特定牌胡牌
 * |
 * 将将胡，胡所有将
 * 
 * 如果打癞子牌，手牌去掉癞子
 * </pre>
 * 
 * @author ems
 *
 */
public abstract class MjCompose extends ArrListAbs implements TingPaiCondiTionI {
	/** 有的种牌 **/
	private final ArrayList<Pai> ziList = new ArrayList<>();
	/** 听哪几个牌 ***/
	private final ArrayList<Pai> tingPais = new ArrayList<>();
	/** 胡类型数组列表 有多少个听牌，，对应多少个胡牌列表 ****/
	private final ArrayList<ArrayList<HuPaiType>> huPaiTypesList = new ArrayList<>();
	/** 基础分(番数) **/
	private final ArrayList<Integer> baseCoinList = new ArrayList<>();

	public MjCompose() {
		super();
	}

	public void init() {
		super.init();
		ziList.clear();
		tingPais.clear();
		huPaiTypesList.clear();
		baseCoinList.clear();
	}

	/**
	 * 加入一个牌
	 * 
	 * @param pai
	 * @return
	 */
	protected boolean add(Pai pai) {
		for (int index = 0; index < this.ziList.size(); index++) {
			Pai co = this.ziList.get(index);
			if (co == Pai.emptyMj)
				continue;
			if (co == pai) {
				int count = super.getCount(index);
				++count;
				if (count > 4) {
					LoggerService.getPlatformLog().error(
							"严重错误！出现4个以上相同的牌！index:{},{}", index, toString());
					return false;
				}
				super.setCount(index, count);
				return true;
			} else if (co.getIndex() > pai.getIndex()) {
				addPai(index, pai, 1);
				if (co.getPrev() != pai) {
					addPai(index + 1, Pai.emptyMj, 0);
				}
				int startIndex = index - 1;
				Pai pMj = Pai.emptyMj;
				for (; startIndex >= 0; startIndex--) {
					pMj = this.ziList.get(startIndex);
					if (pMj != Pai.emptyMj)
						break;
				}
				if (pMj != Pai.emptyMj) {
					if (pMj.getNext() == pai) {
						for (++startIndex; startIndex < index; startIndex++) {
							removePai(startIndex);
						}
					} else if (index - startIndex > 2) {
						for (++startIndex; startIndex < index; startIndex++) {
							removePai(startIndex);
						}
					}
				}
				return true;
			}
		}
		addPai(pai, 1);
		int prevIndex = this.ziList.size() - 2;
		Pai pMj = prevIndex >= 0 ? this.ziList.get(prevIndex) : Pai.emptyMj;
		if (pMj != Pai.emptyMj && pMj.getNext() != pai) {
			addPai(prevIndex + 1, Pai.emptyMj, 0);
		}
		return true;
	}

	private void addPai(int index, Pai pai, int count) {
		this.ziList.add(index, pai);
		super.addCount(index, count);
	}

	private void addPai(Pai pai, int count) {
		this.ziList.add(pai);
		super.addCount(count);
	}

	private void removePai(int index) {
		this.ziList.remove(index);
		super.removeCount(index);
	}

	/**
	 * 移除num个牌
	 * 
	 * @param index
	 *            移除牌位置
	 * @param num
	 *            牌数目
	 */
	protected boolean remove(int index, int num) {
		int count = super.getCount(index);
		count -= num;
		if (count > 0) {
			super.setCount(index, count);
		} else {
			this.removePai(index);
			int startIndex = index - 1;
			Pai pMj = Pai.emptyMj;
			for (; startIndex >= 0; startIndex--) {
				pMj = this.ziList.get(startIndex);
				if (pMj != Pai.emptyMj) {
					break;
				}
			}
			int nextIndex = index;
			Pai nMj = Pai.emptyMj;
			for (; nextIndex < this.ziList.size(); nextIndex++) {
				nMj = this.ziList.get(nextIndex);
				if (nMj != Pai.emptyMj) {
					break;
				}
			}
			if (pMj != Pai.emptyMj && nMj != Pai.emptyMj) {
				--nextIndex;
				if (nextIndex - startIndex > 1) {
					for (++startIndex; startIndex < nextIndex; startIndex++) {
						removePai(startIndex);
					}
				} else if (nextIndex == startIndex) {
					addPai(index, Pai.emptyMj, 0);
				}
			} else if (pMj != Pai.emptyMj && nMj == Pai.emptyMj) {
				for (++startIndex; startIndex < nextIndex; startIndex++) {
					removePai(startIndex);
				}
			} else if (pMj == Pai.emptyMj && nMj != Pai.emptyMj) {
				startIndex = startIndex >= 0 ? startIndex : 0;
				for (; startIndex < nextIndex; startIndex++) {
					removePai(startIndex);
				}
			}
		}
		return true;
	}

	/**
	 * 种牌列表
	 * 
	 * @return
	 */
	public ArrayList<Pai> getZiList() {
		return ziList;
	}

	/**
	 * <pre>
	 * 计算听牌
	 * 要求（max-牌数目）%3 == 0
	 * </pre>
	 * 
	 * @param tag
	 */
	protected void calcTing(String tag) {
		this.clearTingCache();
		if (this.getPlayTypeSet().isFeiBao() && this.getHandBao() > 0) {// 手上有宝牌不能听牌
			return;
		}
		boolean isCanJiangJianghuTingPai = this.isCanJiangJianghu();
		MjType qiYiSeType = this.getQingYiSeType();
		boolean yiTiaoLong = this.isYiTiaoLong();
		boolean isCanMengQing = this.isCanMengQing();
		boolean isCanYiZiQiao = this.isCanYiZiQiao();
		boolean isCanHunYiSe = this.isCanHunYiSe();
		super.setNumber(calcLong(this.getArrayList()));
		if (isCanJiangJianghuTingPai) {
			this.tingPais.addAll(MjUtils.getJiangjiang_tingPais());
			for (int index = 0; index < MjUtils.getJiangjiang_tingPais().size(); index++) {
				ArrayList<HuPaiType> huPaiTypes = new ArrayList<HuPaiType>();
				huPaiTypes.add(HuPaiType.jiangJiangHu);
				this.huPaiTypesList.add(huPaiTypes);
			}
		}
		if (isCanShiSanLan()) {
			ShiSanLanUtils.shiSanLan(this);
		}
		// 这个是针对无赖子和有癞子的
		CxqLai cxqLai = LaiTools.getTingpaiZuhe(super.getNumber(),
				getCountLai());
		if (cxqLai != null) {
			cxqLai.getLackPais(this, yiTiaoLong, qiYiSeType);
		}
		if (!this.huPaiTypesList.isEmpty()) {// 有胡再判断门清全球人
			for (ArrayList<HuPaiType> types : this.huPaiTypesList) {
				if (isCanMengQing && suanMengQing(types)) {
					types.add(HuPaiType.mengQing);
				}
				if (isCanYiZiQiao) {
					types.remove(HuPaiType.pingHu);
					types.add(this.getPlayTypeSet().getQuanQiuRenType());
				}
				if (isCanHunYiSe) {
					types.remove(HuPaiType.pingHu);
					types.add(HuPaiType.hunYiSe);
				}
			}
		}
		if (this.getPlayTypeSet().isJiaZhang()) {
			if (this.tingPais.size() == 1) {
				ArrayList<HuPaiType> types = this.huPaiTypesList.get(0);
				boolean jiaZhang = true;
				for (HuPaiType huPaiType : types) {
					if (huPaiType.noJiaZhang()) {
						jiaZhang = false;
						break;
					}
				}
				if (jiaZhang) {
					types.remove(HuPaiType.pingHu);
					types.add(HuPaiType.jiaZhang);
				}
			}
		} else if (this.getPlayTypeSet().isFeiBao() && this.getDaBao() > 0) {
			for (ArrayList<HuPaiType> types : this.huPaiTypesList) {
				HuPaiType baoHuPaiType = HuPaiType.getBaoHuPaiType(this
						.getDaBao());
				if (baoHuPaiType != null) {
					types.remove(HuPaiType.pingHu);
					types.add(baoHuPaiType);
				} else {
					LoggerService.getPlatformLog().error("超级错误！宝牌数超过4个！{}",
							this.getDaBao());
				}
			}
		}
		for (int index = 0; index < this.tingPais.size(); index++) {
			ArrayList<HuPaiType> arrayList = this.huPaiTypesList.get(index);
			int fan = this.getPlayTypeSet().calcFan(arrayList);
			this.baseCoinList.add(fan);
			if (MjTools.print())
				LoggerService.getPlatformLog().error(
						"{},听{},胡牌类型：{},番数：{} ",
						new Object[] { tag, this.tingPais.get(index),
								this.huPaiTypesList.get(index),
								this.baseCoinList.get(index) });
		}
	}

	/** 清理听牌缓存 **/
	public void clearTingCache() {
		this.tingPais.clear();
		this.huPaiTypesList.clear();
		this.baseCoinList.clear();
	}

	/** 胡牌类型队列算不算门清 */
	private boolean suanMengQing(ArrayList<HuPaiType> types) {
		for (HuPaiType type : types) {
			if (!type.ismQ()) {
				return false;
			}
		}
		return true;
	}

	/**
	 * 麻将的位置
	 * 
	 * @param pai
	 * @return 找不到 返回-1
	 */
	public int getPaiIndex(Pai pai) {
		return this.ziList.indexOf(pai);
	}

	public Pai getPai(int index) {
		return this.ziList.get(index);
	}

	/**
	 * 麻将的数目
	 * 
	 * @param pai
	 * @return 没有为0
	 */
	public int getPaiCount(Pai pai) {
		int indexOf = getPaiIndex(pai);
		if (indexOf != -1)
			return super.getCount(indexOf);
		return 0;
	}

	public String toString() {
		StringBuilder builder = new StringBuilder(Long.toBinaryString(this
				.getNumber()));
		for (int index = 0; index < this.ziList.size(); index++) {
			Pai zi = this.ziList.get(index);
			if (zi != Pai.emptyMj)
				builder.append(zi.toString()).append(" ").append("X")
						.append(this.getCount(index)).append(" ");
			else {
				builder.append("_").append(" ");
			}
		}
		return builder.toString();
	}

	public void resetZiList(ArrayList<Pai> ziList) {
		this.ziList.clear();
		this.ziList.addAll(ziList);
	}

	/**
	 * 是否听牌
	 * 
	 * @return
	 */
	public boolean isTing() {
		return this.getNumber() != 0 && !tingPais.isEmpty();
	}

	/**
	 * 尝试听这个牌
	 * 
	 * @param pai
	 * @param qianggang
	 * @return 胡牌类型
	 */
	public ArrayList<HuPaiType> tryTing(Pai pai, GetHuPaiType getHuPaiType) {
		if (isTing()) {
			return tryTingTargetPai(pai, getHuPaiType);
		} else
			return null;
	}

	private ArrayList<HuPaiType> tryTingTargetPai(Pai pai,
			GetHuPaiType getHuPaiType) {
		int index = this.tingPais.indexOf(pai);
		if (index == -1)
			return null;
		ArrayList<HuPaiType> arrayList = this.huPaiTypesList.get(index);
		switch (getHuPaiType) {
		case ziMo:
			return arrayList;
		case jiePao:
			return isCanJiePao(arrayList) ? arrayList : null;
		case qiangGang:
			return arrayList;
		default:
			return null;
		}
	}

	/**
	 * 能否能接炮
	 * 
	 * @param arrayList
	 * @return
	 */
	public boolean isCanJiePao(ArrayList<HuPaiType> arrayList) {
		if (arrayList.isEmpty()) {
			LoggerService.getPlatformLog().error("判断能否能接炮,胡牌类型为空！");
			return false;
		}
		if (this.isCanDiHu()) {
			return true;
		}
		if (arrayList.size() == 1) {
			HuPaiType huPaiType = arrayList.get(0);
			if (huPaiType == HuPaiType.pingHu)
				return this.isPingHuJiePao();
			if (huPaiType == HuPaiType.jiangJiangHu)
				return this.isJiangJiangHuJiePao();
			if (huPaiType == HuPaiType.baoTing)
				return this.isPinghuBaoTingJiePao();
		}
		if (arrayList.size() == 2 && arrayList.contains(HuPaiType.mengQing)
				&& arrayList.contains(HuPaiType.jiangJiangHu)) {// 只是门清将将胡
			return this.isMengQingJiangJiangJiePao();
		}
		return true;
	}

	public ArrayList<Pai> getTingPais() {
		return tingPais;
	}

	public ArrayList<ArrayList<HuPaiType>> getHuPaiTypesList() {
		return huPaiTypesList;
	}

	public ArrayList<Integer> getBaseCoinList() {
		return baseCoinList;
	}

	/** 所有听胡牌列表加入大胡类型 **/
	public void allAddDaHuPaiType(HuPaiType daHu) {
		for (ArrayList<HuPaiType> huPaiTypes : this.huPaiTypesList) {
			huPaiTypes.remove(HuPaiType.pingHu);
			if (!daHu.ismQ())
				huPaiTypes.remove(HuPaiType.mengQing);
			huPaiTypes.add(daHu);
		}
	}
}
