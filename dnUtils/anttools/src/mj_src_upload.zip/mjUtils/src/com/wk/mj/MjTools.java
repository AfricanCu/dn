package com.wk.mj;

import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.engine.config.ServerConfigAbs;
import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.LackReferenceType;
import com.wk.mj.enun.MjType;
import com.wk.util.ReadUtil;

/**
 * 麻将工具类
 * 
 * @author ems
 *
 */
public class MjTools {

	private static int guildCreateRoomMax;
	private static boolean testHuPai;

	public static void main(String[] args) {
		LoggerService.initDef();
		init();
		Compose compose = new Compose(Arrays.asList(4, 4, 2, 2, 2), null);
		Compose compose2 = hupaiZuheMap.get(compose.getNumber());
		System.err.println(compose2);
		compose.initPaixingHuPai();
		LoggerService.getPlatformLog().error("{}",
				compose.getPaixingHuPaiTypes(true));
	}

	public static void main1(String[] args) throws Exception {
		ListMjAbs listMjAbs = new ListMjAbs(1) {

			@Override
			public boolean isCanDiHu() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isLai(Pai pai) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isBao(Pai pai) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isBanker() {
				// TODO Auto-generated method stub
				return false;
			}

		};
		List<Pai> asList = Arrays.asList(MjType.wang.getPaiByNumber(1),
				MjType.wang.getPaiByNumber(1), MjType.wang.getPaiByNumber(1),
				MjType.wang.getPaiByNumber(1), MjType.wang.getPaiByNumber(2),
				MjType.wang.getPaiByNumber(2), MjType.wang.getPaiByNumber(3),

				MjType.suo.getPaiByNumber(5), MjType.suo.getPaiByNumber(5),
				MjType.suo.getPaiByNumber(6), MjType.suo.getPaiByNumber(7),
				MjType.suo.getPaiByNumber(8),

				MjType.tong.getPaiByNumber(8)

		);
		// listMjAbs.init(new int[] {
		// // wang
		// 0, 0, 0, 0, 0, 0, 1, 1, 0,
		// // suo
		// 0, 0, 0, 1, 0, 2, 0, 0, 0,
		// // tong
		// // 胡九张
		// // 3, 1, 1, 1, 1, 1, 1, 1, 3,
		// // 胡八张
		// // 0, 3, 1, 1, 1, 2, 4, 1, 0,
		// // 0, 3, 1, 1, 1, 1, 4, 1, 1,
		// // 0, 1, 4, 2, 1, 1, 1, 3, 0,
		// // 1, 1, 4, 1, 1, 1, 1, 3, 0,
		// // 0, 1, 1, 4, 1, 1, 1, 1, 3,
		// // 3, 1, 1, 1, 1, 4, 1, 1, 0,
		// // 胡七张
		// 0, 0, 0, 1, 2, 2, 2, 1, 0,
		// // feng
		// 0, 0, 0, 0,
		// });
		listMjAbs.faPai(asList);

		listMjAbs.zhuaPai(MjType.tong.getPaiByNumber(9), false, false);
		listMjAbs.daPai(MjType.wang.getPaiByNumber(1));
		listMjAbs.zhuaPai(MjType.tong.getPaiByNumber(9), false, false);
		listMjAbs.daPai(MjType.wang.getPaiByNumber(1));
		listMjAbs.zhuaPai(MjType.tong.getPaiByNumber(9), false, false);
		listMjAbs.daPai(MjType.wang.getPaiByNumber(1));
		listMjAbs.jieGang(MjType.tong.getPaiByNumber(9), 1);
		LoggerService.getPlatformLog().error("{}", listMjAbs.isCanZiMo());
		LoggerService.getPlatformLog().error(listMjAbs.toString());
		LoggerService.getPlatformLog().error(
				"二进制：{},长度:{},number：{}",
				new Object[] { listMjAbs.getNumberBinary(),
						listMjAbs.getNumberBinary().length(),
						listMjAbs.getNumber() });
	}

	static void zhuaPai(ListMjAbs listMjAbs, Pai pai) {
		listMjAbs.zhuaPai(MjType.wang.getPaiByNumber(5), true, false);
	}

	/** 是否打印小七对的牌型 */
	private static final boolean printXiaoqiDui = false;
	/** 初始多少张牌 **/
	private static final int numberMax;
	private static final int numberMaxMinus;
	/** 需要2,5,8一对将 */
	private static final boolean needDuiJiang;
	/** 暗杠算门清 */
	private static final boolean anGangSuanMengQing;

	static {
		URL configURL = LoggerService.class.getClassLoader().getResource(
				"mj.properties");
		Properties systemProperties = ReadUtil.loadFromURL(configURL);
		numberMax = Integer.parseInt(systemProperties.getProperty("numberMax"));
		numberMaxMinus = numberMax - 1;
		needDuiJiang = Boolean.parseBoolean(systemProperties
				.getProperty("needDuiJiang"));
		anGangSuanMengQing = Boolean.parseBoolean(systemProperties
				.getProperty("anGangSuanMengQing"));
		guildCreateRoomMax = Integer.parseInt(systemProperties
				.getProperty("guildCreateRoomMax"));
		testHuPai = Boolean.parseBoolean(systemProperties
				.getProperty("testHuPai"));
	}
	/** 所有数字拼接 */
	private static final List<List<Integer>> zuheList = new ArrayList<>();
	private static long maxKey = 0;
	/** 所有胡牌牌型 **/
	private static final HashMap<Long, Compose> hupaiZuheMap = new HashMap<Long, Compose>() {
		private static final long serialVersionUID = 1L;

		public Compose put(Long key, Compose value) {
			value.initPaixingHuPai();
			Compose compose = super.put(key, value);
			if (key > maxKey) {
				maxKey = key;
			}
			if (compose != null) {
				value.resetDuijiangIndexList(compose);
				if (print())
					LoggerService.getPlatformLog().error("重复的加入胡牌牌型:{}",
							compose);
			}
			return compose;
		};

		public void putAll(java.util.Map<? extends Long, ? extends Compose> m) {
			super.putAll(m);
		};
	};
	/** 所有听牌牌型 **/
	private static final HashMap<Long, List<LackCompose>> tingpaiZuheMap = new HashMap<Long, List<LackCompose>>();

	public static int getGuildCreateRoomMax() {
		return guildCreateRoomMax;
	}

	/** 是否测试牌型 */
	public static boolean isTestHuPai() {
		return testHuPai;
	}

	/** 能有多少牌 **/
	public static int getNumbermax() {
		return numberMax;
	}

	/** 能有多少牌 **/
	public static int getNumbermaxMinus() {
		return numberMaxMinus;
	}

	public static boolean isNeedduijiang() {
		return needDuiJiang;
	}

	public static int getNumbermaxminus() {
		return numberMaxMinus;
	}

	public static boolean isAnGangSuanMengQing() {
		return anGangSuanMengQing;
	}

	public static List<List<Integer>> getZuhelist() {
		return zuheList;
	}

	public static boolean debug() {
		return true;
	}

	public static void init() {
		LoggerService.getPlatformLog().error("{}", MjType.wang);
		/** 有对子完整牌型 */
		LinkedHashMap<Integer, HashMap<Long, Compose>> duiMap = new LinkedHashMap<Integer, HashMap<Long, Compose>>();
		/** 无对子完整牌型 */
		LinkedHashMap<Integer, HashMap<Long, Compose>> noDuiMap = new LinkedHashMap<Integer, HashMap<Long, Compose>>();
		HashMap<Long, Compose> two = new HashMap<>();
		HashMap<Long, Compose> five = new HashMap<>();
		HashMap<Long, Compose> eight = new HashMap<>();
		HashMap<Long, Compose> eleven = new HashMap<>();
		HashMap<Long, Compose> fourteen = new HashMap<>();
		HashMap<Long, Compose> seventeen = new HashMap<>();
		//
		HashMap<Long, Compose> three = new HashMap<>();
		HashMap<Long, Compose> six = new HashMap<>();
		HashMap<Long, Compose> nine = new HashMap<>();
		HashMap<Long, Compose> tweelve = new HashMap<>();
		HashMap<Long, Compose> fifteen = new HashMap<>();
		Compose compose = new Compose(Arrays.asList(new Integer[] { 2 }),
				Arrays.asList(0));
		two.put(compose.getNumber(), compose);
		Compose compose1 = new Compose(
				Arrays.asList(new Integer[] { 1, 1, 1 }), null);
		Compose compose2 = new Compose(Arrays.asList(new Integer[] { 3 }), null);
		three.put(compose1.getNumber(), compose1);
		three.put(compose2.getNumber(), compose2);
		// 无对子完整牌型
		// 3+3=6
		paiXingDieJia(three, three, six);
		// 3+6=9
		paiXingDieJia(three, six, nine);
		// 3+9=12
		paiXingDieJia(three, nine, tweelve);
		if (getNumbermax() == 17) {
			// 3+12=15
			paiXingDieJia(three, tweelve, fifteen);
		}
		// 有对子完整牌型
		// 3+2=5
		paiXingDieJia(three, two, five);
		// 3+5=8
		paiXingDieJia(three, five, eight);
		// 3+8=11
		paiXingDieJia(three, eight, eleven);
		// 3+11=14
		paiXingDieJia(three, eleven, fourteen);
		if (getNumbermax() == 17) {
			// 3+14=17
			paiXingDieJia(three, fourteen, seventeen);
		}
		noDuiMap.put(3, three);
		noDuiMap.put(6, six);
		noDuiMap.put(9, nine);
		noDuiMap.put(12, tweelve);
		duiMap.put(2, two);
		duiMap.put(5, five);
		duiMap.put(8, eight);
		duiMap.put(11, eleven);
		duiMap.put(14, fourteen);
		/** 所有完整牌型 <牌数目， 牌型Map> */
		LinkedHashMap<Integer, HashMap<Long, Compose>> allMap = new LinkedHashMap<Integer, HashMap<Long, Compose>>();
		allMap.putAll(noDuiMap);
		allMap.putAll(duiMap);
		/** 没有对子的数字拼接 */
		List<Integer> noDui = Arrays.asList(noDuiMap.keySet().toArray(
				new Integer[noDuiMap.size()]));
		/** 有对子的数字拼接 */
		List<Integer> dui = Arrays.asList(duiMap.keySet().toArray(
				new Integer[duiMap.size()]));
		for (int aa : dui) {
			get(Arrays.asList(aa), noDui);
		}
		for (List<Integer> zuhe : zuheList) {
			if (print())
				LoggerService.getPlatformLog().error("{}", zuhe);
			ArrayList<Integer> arrayList = new ArrayList<>(zuhe);
			HashMap<Long, Compose> hashMap = allMap.get(arrayList.remove(0));
			if (arrayList.isEmpty()) {// 组合队列长度为1,则直接加入
				hupaiZuheMap.putAll(hashMap);
				continue;
			}
			loop(hashMap, arrayList, allMap);
		}

		xiaoqidui();
		if (print()) {
			LoggerService.getPlatformLog().error("胡牌牌型组合数：{}", zuheList.size());
			LoggerService.getPlatformLog().error("胡牌牌型数：{}",
					hupaiZuheMap.size());
			LoggerService.getPlatformLog().error("胡牌牌型maxKey:{},longMax{}",
					Long.toBinaryString(maxKey),
					Long.toBinaryString(Long.MAX_VALUE));
		}
	}

	/**
	 * 初始化听牌牌型
	 */
	public void initTing() {
		/*** 最多可能听牌牌型数 **/
		int maxTingPaiSize = 0;
		for (Compose fullCompose : hupaiZuheMap.values()) {
			try {
				for (LackCompose lackCompose : getLackComposeList(fullCompose)) {
					List<LackCompose> list = tingpaiZuheMap.get(lackCompose
							.getNumber());
					if (list == null) {
						list = new ArrayList<>();
						tingpaiZuheMap.put(lackCompose.getNumber(), list);
					}
					list.add(lackCompose);
					if (list.size() > maxTingPaiSize) {
						maxTingPaiSize = list.size();
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		if (print())
			LoggerService.getPlatformLog().error("听牌牌型数：{},最大可能听牌队列:{}",
					tingpaiZuheMap.size(), maxTingPaiSize);
	}

	/**
	 * 缺1张的所有牌型
	 * 
	 * @return
	 * @throws Exception
	 */
	public static List<LackCompose> getLackComposeList(Compose compose)
			throws Exception {
		ArrayList<LackCompose> arrayListRt = new ArrayList<>();
		List<Integer> arrayList = compose.getArrayList();
		Compose.check(arrayList);
		List<Integer> duiJiangIndexList = compose.getDuiJiangIndexList();
		for (int lackIndex = 0; lackIndex < arrayList.size(); lackIndex++) {
			if (arrayList.get(lackIndex) > 0) {
				ArrayList<Integer> copyArr = compose.getCopyList();
				copyArr.set(lackIndex, copyArr.get(lackIndex) - 1);
				LackReferenceType lackReferenceType;
				/** 是否缺失位置往前移动一格 */
				boolean mustMinus = false;
				int removeIndex = -1;
				if (copyArr.get(lackIndex) == 0) {
					int prevLackIndex = lackIndex - 1;
					int nextLackIndex = lackIndex + 1;
					/** 是否缺失位置前面有牌 */
					boolean prevOk = prevLackIndex >= 0
							&& copyArr.get(prevLackIndex) > 0;
					/** 是否缺失位置后面有牌 */
					boolean nextOk = copyArr.size() > nextLackIndex
							&& copyArr.get(nextLackIndex) > 0;
					if (prevOk && nextOk) {
						lackReferenceType = LackReferenceType.betwwen;
					} else if (prevOk && !nextOk) {
						lackReferenceType = LackReferenceType.prev;
						if (copyArr.size() > nextLackIndex
								&& copyArr.get(nextLackIndex) == 0) {
							copyArr.remove(nextLackIndex);
							removeIndex = nextLackIndex;
						} else if (copyArr.size() == nextLackIndex) {
							copyArr.remove(copyArr.size() - 1);
							removeIndex = copyArr.size() - 1;
						}
					} else if (!prevOk && nextOk) {
						lackReferenceType = LackReferenceType.next;
						if (prevLackIndex >= 0
								&& copyArr.get(prevLackIndex) == 0) {
							copyArr.remove(prevLackIndex);
							mustMinus = true;
							removeIndex = prevLackIndex;
						} else if (prevLackIndex < 0) {// 头部为0
							copyArr.remove(0);
							mustMinus = true;
							removeIndex = 0;
						}
					} else {
						LoggerService.getPlatformLog().error("前后都缺失牌，无法定位缺失牌！");
						throw new Exception();
					}
				} else {
					lackReferenceType = LackReferenceType.current;
				}
				if (copyArr.get(0) == 0) {
					LoggerService.getPlatformLog().error("需要去头！");
				} else if (copyArr.get(copyArr.size() - 1) == 0) {
					LoggerService.getPlatformLog().error("需要去尾！");
				}
				int nlackIndex = mustMinus ? lackIndex - 1 : lackIndex;
				List<Integer> nDuiJiangIndexList = null;
				if (duiJiangIndexList != null) {
					nDuiJiangIndexList = new ArrayList<>();
					for (int duiJiangIndex : duiJiangIndexList) {
						int nDuiJiangIndex = removeIndex != -1
								&& duiJiangIndex >= removeIndex ? duiJiangIndex - 1
								: duiJiangIndex;
						nDuiJiangIndexList.add(nDuiJiangIndex);
					}
				}
				arrayListRt.add(new LackCompose(compose, nlackIndex,
						new Compose(copyArr, nDuiJiangIndexList),
						lackReferenceType));
			}
		}
		return arrayListRt;
	}

	/***
	 * 
	 * @param arr
	 *            包含对子的队列
	 * @param noDui
	 *            不包含对子的队列
	 */
	private static void get(List<Integer> arr, List<Integer> noDui) {
		int aa = 0;
		for (int tmp : arr) {
			aa += tmp;
		}
		zuheAdd(arr);
		for (int bb : noDui) {
			int cc = aa + bb;
			if (cc <= getNumbermax()) {
				ArrayList<Integer> arrayList = new ArrayList<>(arr);
				arrayList.add(bb);
				if (cc != getNumbermax()) {
					get(arrayList, noDui);
				} else {
					zuheAdd(arrayList);
				}
			} else {
				break;
			}
		}
	}

	/** 小七对胡牌牌型 错误 可以4个的 **/
	private static void xiaoqidui() {
		if (getNumbermax() != 14) {
			return;
		}
		{//
			List<Integer> asList = Arrays.asList(2, 0, 2, 0, 2, 0, 2, 0, 2, 0,
					2, 0, 2);// 13
			for (int start = 0; start <= asList.size() / 2; start++) {
				qi(0, start, new ArrayList<>(asList));
			}
		}
		{// 1个4
			List<Integer> siList = Arrays.asList(2, 0, 2, 0, 2, 0, 2, 0, 2, 0,
					2);
			for (int index = 0; index < siList.size(); index++) {
				if (siList.get(index) == 2) {
					ArrayList<Integer> arrayList = new ArrayList<>(siList);
					arrayList.set(index, 4);
					for (int start = 0; start <= arrayList.size() / 2; start++) {
						qi(0, start, new ArrayList<>(arrayList));
					}
				}
			}
		}
		{// 2个4
			List<Integer> siList = Arrays.asList(2, 0, 2, 0, 2, 0, 2, 0, 2);
			for (int index = 0; index < siList.size(); index++) {
				if (siList.get(index) == 2) {
					for (int xx = index + 1; xx < siList.size(); xx++) {
						if (siList.get(xx) == 2) {
							ArrayList<Integer> arrayList = new ArrayList<>(
									siList);
							arrayList.set(index, 4);
							arrayList.set(xx, 4);
							for (int start = 0; start <= arrayList.size() / 2; start++) {
								qi(0, start, new ArrayList<>(arrayList));
							}
						}
					}
				}
			}
		}
		{// 3个4
			List<Integer> siList = Arrays.asList(2, 0, 2, 0, 2, 0, 2);
			for (int index = 0; index < siList.size(); index++) {
				if (siList.get(index) == 2) {
					for (int xx = index + 1; xx < siList.size(); xx++) {
						if (siList.get(xx) == 2) {
							for (int yy = xx + 1; yy < siList.size(); yy++) {
								if (siList.get(yy) == 2) {
									ArrayList<Integer> arrayList = new ArrayList<>(
											siList);
									arrayList.set(index, 4);
									arrayList.set(xx, 4);
									arrayList.set(yy, 4);
									for (int start = 0; start <= arrayList
											.size() / 2; start++) {
										qi(0, start, new ArrayList<>(arrayList));
									}
								}
							}
						}
					}
				}
			}
		}
	}

	/**
	 * 
	 * @param start
	 * @param removeZeroNum
	 *            移除几个零
	 * @param asList
	 */
	private static void qi(int start, int removeZeroNum, List<Integer> asList) {
		if (removeZeroNum == 0) {
			Compose compose3 = new Compose(asList, null);
			hupaiZuheMap.put(compose3.getNumber(), compose3);
			if (printXiaoqiDui)
				LoggerService.getPlatformLog().error(compose3.toString());
			return;
		}
		for (int index = start; index < asList.size(); index++) {
			if (asList.get(index) != 0)
				continue;
			ArrayList<Integer> arrayList = new ArrayList<>(asList);
			arrayList.remove(index);
			qi(index, removeZeroNum - 1, arrayList);
		}
	}

	/** 是否打印 **/
	static boolean print() {
		return ServerConfigAbs.isMonitorMj();
	}

	/**
	 * <pre>
	 * ----------------
	 * 0...      0
	 *  1|2|...|E
	 * ----------------
	 * 
	 * <pre>
	 * @param arr
	 */
	private static void zuheAdd(List<Integer> arr) {
		if (arr.size() > 1) {
			zuheList.add(arr);
			for (int index = 1; index < arr.size(); index++) {
				List<Integer> subList = new ArrayList<>(arr.subList(1,
						arr.size()));
				subList.add(index, arr.get(0));
				zuheList.add(subList);
			}
		} else
			zuheList.add(arr);
	}

	/**
	 * 
	 * @param hashMap
	 * @param zuhe
	 * @param allMap
	 *            所有完整牌型
	 */
	private static void loop(HashMap<Long, Compose> hashMap,
			List<Integer> zuhe,
			LinkedHashMap<Integer, HashMap<Long, Compose>> allMap) {
		if (zuhe.isEmpty()) {
			return;
		}
		HashMap<Long, Compose> hashMap2 = allMap.get(zuhe.remove(0));
		HashMap<Long, Compose> tmpMap = null;
		if (zuhe.isEmpty()) {
			tmpMap = hupaiZuheMap;
		} else {
			tmpMap = new HashMap<>();
		}
		for (Compose compose : hashMap.values()) {
			for (Compose compose2 : hashMap2.values()) {
				Compose combine = Compose.combine(compose, compose2);
				tmpMap.put(combine.getNumber(), combine);
			}
		}
		if (tmpMap != hupaiZuheMap)
			loop(tmpMap, zuhe, allMap);
	}

	private static class ListIndex {
		private final List<Integer> list;
		/** 对将的位置 */
		private final List<Integer> index;

		public ListIndex(List<Integer> list, List<Integer> index) {
			super();
			this.list = list;
			this.index = index;
		}

		public List<Integer> getList() {
			return list;
		}

		public List<Integer> getIndex() {
			return index;
		}
	}

	/**
	 * 两种牌型叠加
	 * 
	 * @param oneAddMap
	 *            第一种牌型
	 * @param twoAddMap
	 *            第二种牌型
	 * @param packageMap
	 *            牌型map
	 */
	public static void paiXingDieJia(HashMap<Long, Compose> oneAddMap,
			HashMap<Long, Compose> twoAddMap, HashMap<Long, Compose> packageMap) {
		ArrayList<ListIndex> initList = new ArrayList<>();
		for (Compose tt : oneAddMap.values()) {
			for (Compose tt2 : twoAddMap.values()) {
				initList.addAll(fuck(tt, tt2));
			}
		}
		for (ListIndex list : initList) {
			Compose compose = new Compose(list.getList(), list.getIndex());
			Compose old = packageMap.put(compose.getNumber(), compose);
			if (old == null) {
				// compose.print();
				// LoggerService.getPlatformLog().error("加入牌型：{},{}",
				// compose.getNumberBinary(), compose.getNumber());
			}
		}
	}

	/***
	 * <pre>
	 * 两种牌型叠加，，计算新的牌型
	 * 
	 * ----------------------------
	 * upmoveList...     upmoveList
	 *           downList
	 * downList可能有对将
	 * ----------------------------
	 * </pre>
	 * 
	 * @param tt
	 *            无需对将
	 * @param tt2
	 *            可能有对将
	 * @return
	 */
	private static ArrayList<ListIndex> fuck(Compose tt, Compose tt2) {
		if (tt.getDuiJiangIndexList() != null) {
			LoggerService.getPlatformLog().error("错误！tt无需对将");
			return null;
		}
		List<Integer> upmoveList = tt.getCopyList();
		List<Integer> downList = tt2.getCopyList();
		ArrayList<ListIndex> retList = new ArrayList<>();
		int bblength = upmoveList.size() + downList.size() + upmoveList.size();
		for (int i = 0; i <= upmoveList.size() + downList.size(); i++) {
			int bb[] = new int[bblength];
			int j = i;
			int jend = i + upmoveList.size();
			for (; j < jend; j++) {
				bb[j] = upmoveList.get(j - i);
			}
			int k = upmoveList.size();
			int kend = upmoveList.size() + downList.size();
			for (; k < kend; k++) {
				bb[k] = (bb[k] + downList.get(k - upmoveList.size()));
			}
			if (k != kend) {
				continue;
			}
			int xx = 0;
			for (; xx < bb.length; xx++) {
				if (bb[xx] != 0) {
					break;
				}
			}
			List<Integer> duiJiangIndexList = null;
			if (tt2.getDuiJiangIndexList() != null) {
				duiJiangIndexList = new ArrayList<Integer>();
				for (int duiJiangIndex : tt2.getDuiJiangIndexList())
					duiJiangIndexList.add(duiJiangIndex + upmoveList.size()
							- xx);
			}
			ListIndex wap = wap(bb, duiJiangIndexList);
			if (wap != null) {
				retList.add(wap);
			}
		}
		return retList;
	}

	private static ListIndex wap(int[] bb, List<Integer> duiJiangIndexList) {
		ArrayList<Integer> list = new ArrayList<>();
		for (int b : bb) {
			if (b != 0) {
				list.add(b);
			}
			if (b > 4) {
				return null;
			}
			if (list.size() > 9) {
				return null;
			}
		}
		return new ListIndex(list, duiJiangIndexList);
	}

	public static HashMap<Long, Compose> getHupaizuhemap() {
		return hupaiZuheMap;
	}

	/**
	 * 获取听牌列表
	 * 
	 * @param number
	 *            牌型数字
	 * @return
	 */
	public static List<LackCompose> getTingpaiZuhe(long number) {
		return tingpaiZuheMap.get(number);
	}

	public static HashMap<Long, List<LackCompose>> getTingpaizuhemap() {
		return tingpaiZuheMap;
	}

	public static void getLackPais(List<LackCompose> lackComposeList,
			MjCompose mjCompose, boolean isCanYiTiaoLong, MjType qiYiSeType) {
		ArrayList<Pai> tingPais = mjCompose.getTingPais();
		ArrayList<ArrayList<HuPaiType>> huPaiTypesList = mjCompose
				.getHuPaiTypesList();
		for (LackCompose lackCompose : lackComposeList) {
			Pai pai = lackCompose.getLackPai(mjCompose);
			if (pai == Pai.emptyMj) {
				continue;
			}
			if (pai == null) {
				LoggerService.getPlatformLog().error("牌为NULL!");
				continue;
			}
			ArrayList<HuPaiType> huPaiTypes = null;
			if (!huPaiTypesList.isEmpty()) {
				int indexOf = tingPais.indexOf(pai);
				if (indexOf != -1)
					huPaiTypes = huPaiTypesList.get(indexOf);
			}
			if (huPaiTypes == null) {
				huPaiTypes = new ArrayList<HuPaiType>();
				tingPais.add(pai);
				huPaiTypesList.add(huPaiTypes);
			}
			ArrayList<HuPaiType> paixingHuPaiTypes2 = lackCompose
					.getFullCompose().getPaixingHuPaiTypes(isCanYiTiaoLong);
			if (!paixingHuPaiTypes2.isEmpty()) {
				for (HuPaiType type : paixingHuPaiTypes2)
					if (!huPaiTypes.contains(type))
						huPaiTypes.add(type);
			}
			if (qiYiSeType != null && pai.getType() == qiYiSeType
					&& !huPaiTypes.contains(HuPaiType.qingYiSe)) {
				huPaiTypes.add(HuPaiType.qingYiSe);
			}
			if (huPaiTypes.isEmpty()) {
				huPaiTypes.add(HuPaiType.pingHu);
			}
		}
	}

}
