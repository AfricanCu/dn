package com.wk.util;

import com.jery.ngsp.server.log.LoggerService;

public class LogUtil {

	public static final org.slf4j.Logger msgLog = LoggerService.getLogicLog();

}
