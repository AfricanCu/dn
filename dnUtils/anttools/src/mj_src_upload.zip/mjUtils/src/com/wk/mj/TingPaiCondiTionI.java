package com.wk.mj;

import com.wk.mj.enun.MjType;
import com.wk.play.PlayTypeSet;

/**
 * 听牌接口
 * 
 * 听牌缓存接口 ，传打牌的参数
 * 
 * @author ems
 *
 */
public interface TingPaiCondiTionI {

	/**
	 * 返回清一色的色
	 * 
	 * @return
	 */
	public MjType getQingYiSeType();

	/**
	 * 打掉这个牌是否能清一色
	 * 
	 * @param index
	 * @return 不能返回null 能返回色
	 */
	public MjType getQingYiSeType(int index);

	/**
	 * 是否能够将将胡听牌
	 * 
	 * @return
	 */
	public boolean isCanJiangJianghu();

	/**
	 * 打掉这个牌是否能将将胡
	 * 
	 * @param index
	 * @return
	 */
	public boolean isCanJiangJianghu(int index);

	/**
	 * 是否打一条龙
	 * 
	 * @return
	 */
	public boolean isYiTiaoLong();

	/**
	 * 是否能门清胡牌
	 * 
	 * 检测手上牌没有碰杠过
	 * 
	 * 注：暗杠算门清？
	 * 
	 * @return
	 */
	public boolean isCanMengQing();

	/**
	 * 是否平胡可接炮
	 * 
	 * @return
	 */
	public boolean isPingHuJiePao();

	/**
	 * 平胡报听能否接炮
	 * 
	 * @return
	 */
	public boolean isPinghuBaoTingJiePao();

	/**
	 * 是否单纯将将胡可接炮
	 * 
	 * @return
	 */
	public boolean isJiangJiangHuJiePao();

	/**
	 * 是否门清将将胡可接炮
	 * 
	 * @return
	 */
	public boolean isMengQingJiangJiangJiePao();

	/**
	 * 是否能地胡
	 * 
	 * @return
	 */
	public boolean isCanDiHu();

	/**
	 * 是否能够报听
	 * 
	 * @return
	 */
	public boolean isCanBaoTing();

	/**
	 * 是否能够一字撬
	 * 
	 * @return
	 */
	public boolean isCanYiZiQiao();

	/**
	 * 打掉这张牌是否能够一字撬
	 * 
	 * @param index
	 * @return
	 */
	public boolean isCanYiZiQiao(int index);

	/**
	 * 是否能够奖励一字撬没胡牌
	 * 
	 * @return
	 */
	public boolean isCanYiZiQiaoYouXi();

	/**
	 * 是否能够十三烂
	 * 
	 * @return
	 */
	public boolean isCanShiSanLan();

	/**
	 * 听牌打掉这张牌是否能够十三烂
	 * 
	 * @param number
	 *            牌型long值，，听牌要传
	 * @return
	 */
	public boolean isCanShiSanLan(long number);

	/**
	 * 是否能够混一色
	 * 
	 * @return
	 */
	public boolean isCanHunYiSe();

	/**
	 * 打掉这个牌是否能够混一色
	 * 
	 * @return
	 */
	public boolean isCanHunYiSe(int index);

	/**
	 * 是不是癞子
	 */
	public boolean isLai(Pai pai);

	/**
	 * 癞子数
	 */
	public int getCountLai();

	/**
	 * 是不是宝牌
	 */
	public boolean isBao(Pai pai);

	/**
	 * 获取玩法设置
	 */
	public PlayTypeSet getPlayTypeSet();

	/**
	 * 手上的宝牌数
	 * 
	 * @return
	 */
	public int getHandBao();

	/**
	 * 打掉这个牌手上的宝牌数
	 * 
	 * @return
	 */
	public int getHandBao(int index);

	/**
	 * 打的宝牌数
	 * 
	 * @return
	 */
	public int getDaBao();

	/**
	 * 打掉这个牌打的宝牌数
	 * 
	 * @return
	 */
	public int getDaBao(int index);

	/** 是否马上抓的牌才能明杠 */
	public boolean isRightNowZhuaCanMingGang();

	/**
	 * 吃碰杠的牌能够满足碰碰胡条件？
	 * 
	 * @return
	 */
	public abstract boolean isAllPengOrGang();
}
