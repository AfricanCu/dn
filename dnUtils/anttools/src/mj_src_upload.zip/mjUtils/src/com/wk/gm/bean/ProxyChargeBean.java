package com.wk.gm.bean;

import java.util.Date;

import com.wk.enun.ChargeStatus;

public class ProxyChargeBean {
	private String orderId;// 订单号
	/** 代理id */
	private String uid;
	private int invitation;
	private ChargeStatus chargeStatus;// 状态0待处理1处理
	private int platId;
	/** 最终获得多少钻石 **/
	private int diamond;
	/** 花费多少钱 **/
	private String money;
	private Date chargeTime;// 充值时间
	private Date orderTime;

	public ProxyChargeBean() {
		super();
	}

	public ProxyChargeBean(String orderId, String uid,
			ChargeStatus chargeStatus, int platId, int diamond, String money,
			Date chargeTime, Date orderTime) {
		super();
		this.orderId = orderId;
		this.uid = uid;
		this.chargeStatus = chargeStatus;
		this.platId = platId;
		this.diamond = diamond;
		this.money = money;
		this.chargeTime = chargeTime;
		this.orderTime = orderTime;
	}

	public void setStatus(int status) {
		this.chargeStatus = ChargeStatus.getEnum(status);
	}

	public int getStatus() {
		return chargeStatus.getType();
	}

	public ChargeStatus getChargeStatus() {
		return chargeStatus;
	}

	public void setChargeStatus(ChargeStatus chargeStatus) {
		this.chargeStatus = chargeStatus;
	}

	public String getOrderId() {
		return orderId;
	}

	public String getUid() {
		return uid;
	}
	
	public int getInvitation() {
		return invitation;
	}

	public int getPlatId() {
		return platId;
	}

	public int getDiamond() {
		return diamond;
	}

	public String getMoney() {
		return money;
	}

	public Date getChargeTime() {
		return chargeTime;
	}

	public Date getOrderTime() {
		return orderTime;
	}

}
