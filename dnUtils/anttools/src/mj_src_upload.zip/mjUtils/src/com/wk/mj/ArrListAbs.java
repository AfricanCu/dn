package com.wk.mj;

import java.util.ArrayList;
import java.util.List;

import com.jery.ngsp.server.log.LoggerService;

/**
 * 二进制数组列表
 * 
 * @author ems
 *
 */
public abstract class ArrListAbs {
	/** 牌型数组 */
	private final List<Integer> arrayList;
	/** 二进制表示牌型转long */
	private long number;

	public ArrListAbs() {
		this(new ArrayList<Integer>());
	}

	public ArrListAbs(List<Integer> list) {
		super();
		this.arrayList = list;
		this.number = calcLong(this.arrayList);
	}

	/**
	 * 初始化
	 */
	public void init() {
		arrayList.clear();
		number = 0;
	}

	/** 二进制表示牌型返回long **/
	public static long calcLong(List<Integer> arrayList) {
		check(arrayList);
		long ret = 0;
		for (int index = 0; index < arrayList.size(); index++) {
			int aa = arrayList.get(index);
			if (aa == 0) {
				continue;
			}
			int nextIndex = index + 1;
			boolean islack = nextIndex != arrayList.size()
					&& arrayList.get(nextIndex) == 0;// 后面无连续牌
			switch (aa) {
			case 1:
				if (islack) {
					ret = (ret << 3l) | 0b100l;
				} else
					ret = (ret << 2l) | 0b10l;
				break;
			case 2:
				if (islack) {
					ret = (ret << 4l) | 0b1100l;
				} else
					ret = (ret << 3l) | 0b110l;
				break;
			case 3:
				if (islack) {
					ret = (ret << 5l) | 0b11100l;
				} else
					ret = (ret << 4l) | 0b1110l;
				break;
			case 4:
				if (islack) {
					ret = (ret << 6l) | 0b111100l;
				} else
					ret = (ret << 5l) | 0b11110l;
				break;
			default:
				break;
			}

		}
		return ret;
	}

	public long getNumber() {
		return number;
	}

	public void setNumber(long number) {
		this.number = number;
	}

	/***
	 * 牌型long转二进制表示
	 * 
	 * @return
	 */
	public String getNumberBinary() {
		return Long.toBinaryString(number);
	}

	public List<Integer> getArrayList() {
		return arrayList;
	}

	public int getArrayListSize() {
		return arrayList.size();
	}

	/**
	 * 获取拷贝牌型队列
	 * 
	 * @return
	 */
	public ArrayList<Integer> getCopyList() {
		return new ArrayList<Integer>(arrayList);
	}

	/**
	 * 检测一下牌型是否合法
	 * 
	 * 不能连续出现0
	 * 
	 */
	public static void check(List<Integer> arrayList) {
		int zeroCount = 0;
		for (int lackIndex = 0; lackIndex < arrayList.size(); lackIndex++) {
			if (arrayList.get(lackIndex) == 0) {
				zeroCount++;
				if (zeroCount > 1) {
					LoggerService.getPlatformLog().error("牌型不合法！ ");
				}
			} else {
				zeroCount = 0;
			}
		}
	}

	/**
	 * 多少个
	 * 
	 * @param index
	 *            位置
	 * @return
	 */
	public int getCount(int index) {
		return this.arrayList.get(index);
	}

	/**
	 * 设置牌型某个位置的数目
	 * 
	 * @param index
	 * @param count
	 */
	public void setCount(int index, int count) {
		this.arrayList.set(index, count);
	}

	public void removeCount(int index) {
		this.arrayList.remove(index);
	}

	public void addCount(int count) {
		this.arrayList.add(count);
	}

	public void addCount(int index, int count) {
		this.arrayList.add(index, count);
	}

	public void resetArrayList(List<Integer> list) {
		this.arrayList.clear();
		this.arrayList.addAll(list);
	}

	/***
	 * 计算牌型多少张牌
	 * 
	 * @return
	 */
	public int calcListNum() {
		int sum = 0;
		for (int xx : this.arrayList) {
			if (xx != 0)
				sum += xx;
		}
		return sum;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		for (int b : this.arrayList) {
			builder.append(b).append(" ");
		}
		return builder.toString();
	}
}
