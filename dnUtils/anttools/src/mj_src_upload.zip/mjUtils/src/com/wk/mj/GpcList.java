package com.wk.mj;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.enun.GpcType;

/**
 * 杠碰吃队列
 * 
 * @author ems
 *
 */
public class GpcList extends ArrayList<GpcCache> implements Serializable {
	private static final long serialVersionUID = 1L;
	/** 暗杠的牌 **/
	private final ArrayList<GpcCache> anGangList = new ArrayList<>(3);
	/** 明杠的牌 **/
	private final ArrayList<GpcCache> mingGangList = new ArrayList<>(3);
	/** 接杠的牌 */
	private final ArrayList<GpcCache> jieGangList = new ArrayList<>(3);
	/** 碰 **/
	private final ArrayList<GpcCache> pengList = new ArrayList<>(4);
	/** 吃 */
	private final ArrayList<GpcCache> chiList = new ArrayList<>(4);

	@Override
	public void clear() {
		super.clear();
		this.anGangList.clear();
		this.mingGangList.clear();
		this.jieGangList.clear();
		this.pengList.clear();
		this.chiList.clear();
	}

	@Override
	public boolean add(GpcCache e) {
		boolean add = super.add(e);
		switch (e.getType()) {
		case AnGang:
			this.anGangList.add(e);
			break;
		case MingGang:
			this.mingGangList.add(e);
			break;
		case JieGang:
			this.jieGangList.add(e);
			break;
		case Peng:
			this.pengList.add(e);
			break;
		case Chi:
			this.chiList.add(e);
			break;
		default:
			LoggerService.getPlatformLog().error("未实现！加入错误");
			break;
		}
		return add;
	}

	public GpcCache mingGang(Pai pai, boolean mingGangSuanJieGang) {
		for (Iterator<GpcCache> iter = this.pengList.iterator(); iter.hasNext();) {
			GpcCache gpc = iter.next();
			if (gpc.getPai() == pai) {
				iter.remove();
				if (mingGangSuanJieGang) {
					gpc.setType(GpcType.JieGang);
					this.jieGangList.add(gpc);
				} else {
					gpc.setType(GpcType.MingGang);
					this.mingGangList.add(gpc);
				}
				return gpc;
			}
		}
		return null;
	}

	public boolean anGangEmpty() {
		return this.anGangList.isEmpty();
	}

	/**
	 * 是否能够门清？
	 * 
	 * 注：可能暗杠也算门清
	 * 
	 * @return
	 */
	public boolean isCanMengQing() {
		return (MjTools.isAnGangSuanMengQing() || this.anGangList.isEmpty())
				&& this.mingGangList.isEmpty() && this.jieGangList.isEmpty()
				&& this.pengList.isEmpty() && this.chiList.isEmpty();
	}

	/**
	 * 没有杠碰吃
	 * 
	 * @return
	 */
	public boolean notHasGpc() {
		return this.anGangList.isEmpty() && this.mingGangList.isEmpty()
				&& this.jieGangList.isEmpty() && this.pengList.isEmpty()
				&& this.chiList.isEmpty();
	}

	public ArrayList<GpcCache> getAnGangList() {
		return anGangList;
	}

	public ArrayList<GpcCache> getMingGangList() {
		return mingGangList;
	}

	public ArrayList<GpcCache> getJieGangList() {
		return jieGangList;
	}

	public ArrayList<GpcCache> getPengList() {
		return this.pengList;
	}

	public ArrayList<GpcCache> getChiList() {
		return chiList;
	}

	public boolean isPeng(Pai pai) {
		return getPeng(pai) != null;
	}

	public GpcCache getPeng(Pai pai) {
		for (GpcCache cache : this.pengList) {
			if (cache.getPai() == pai) {
				return cache;
			}
		}
		return null;
	}

	public boolean isAllPengOrGang() {
		return this.chiList.isEmpty();
	}

}