package com.wk.mj;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.GetHuPaiType;
import com.wk.mj.enun.GpcType;
import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.MjType;
import com.wk.play.PlayTypeSet;

/**
 * 牌队列
 * 
 * @author ems
 *
 */
public abstract class ListMjAbs extends MjCompose implements TingPaiCondiTionI {

	private static final long serialVersionUID = 1L;
	/** 接杠手上要几张 */
	public static final int JIE_GANG_PAI_NUM = 3;
	/** 暗杠手上要几张 */
	public static final int AN_GANG_PAI_NUM = 4;
	/** 明杠手上要几张 */
	public static final int MING_GANG_PAI_NUM = 1;
	/** 不能小七对 */
	public static final int CAN_NOT_DUI = -1;
	/** 听牌缓存大小 **/
	public static final int TING_CACHE_MAX = MjTools.getNumbermax() * 2 - 1;
	/** 编号 */
	private final int id;
	/** 每种牌的数目 **/
	private final int[] mjCounts = new int[MjType.values().length + 1];
	/** 听牌缓存 **/
	private final ArrayList<Ting> tingCacheList = new ArrayList<>(
			TING_CACHE_MAX);
	/** 自摸次数 */
	private int ziMoTimes;
	/** 接炮次数 */
	private int jiePaoTimes;
	/** 自摸次数 */
	private int anGangTimes;
	/** 接炮次数 */
	private int mingGangTimes;
	/** 接杠次数 */
	private int jieGangTimes;
	/** 放炮次数 */
	private int fangPaoTimes;
	/** 放杠次数 */
	private int fangGangTimes;
	/** 玩法设置 */
	private PlayTypeSet playTypeSet;
	/** 总麻将数 **/
	private int mjSum;
	/*** 当前多少个将 **/
	private int jiangSum;
	/** 缓存可以暗杠的牌 **/
	private final ArrayList<Pai> anGangCacheArr = new ArrayList<>(3);
	/** 缓存可以明杠的牌 **/
	private final ArrayList<Pai> mingGangCacheArr = new ArrayList<>(3);
	/** 放炮的对象 */
	private final ArrayList<ListMjAbs> fangPaoList = new ArrayList<>(3);
	/** 放抢杠的对象 */
	private final ArrayList<ListMjAbs> fangQiangGangList = new ArrayList<>(3);
	/** 放杠的牌 */
	private final ArrayList<Pai> fangGangList = new ArrayList<>(12);
	/** 是否报听 */
	private boolean baoTing;
	/** 自摸胡牌 */
	private Pai ziMoPai;
	/** 抢杠胡牌 */
	private Pai qiangGangPai;
	/** 胡类型数组 */
	private ArrayList<HuPaiType> huPaiTypes;
	/** 打过的牌列表 */
	private final List<Pai> haveDaPaiList = new ArrayList<Pai>();
	/** 被暗杠次数 */
	private int anGangBeen;
	/** 被明杠次数 */
	private int mingGangBeen;
	/** 胡牌方式 */
	private GetHuPaiType getHuPaiType;
	/** 几个人有一字撬 */
	private int yiZiQiaoNumber;
	/** 几个人要宝罚分 */
	private int baoFanFenNumber;
	/** 抓的牌 **/
	private Pai zhuaPai;
	/** 杠碰吃缓存 **/
	private final GpcList gpcList = new GpcList();
	/** 抓的癞子的数目，癞子只能累计，不能打出 **/
	private int countLai;

	/** 手上的宝牌数 */
	private int handBao;
	/** 打的宝牌数 */
	private int daBao;
	/** 宝牌不打，要罚分？ */
	private boolean needBaoFanFen;

	/** 没有接炮时打了多少牌和胡类型数组 **/
	private int noJiePaoHaveDaPaiSize;
	private ArrayList<HuPaiType> noJiePaoHuPaiTypes;
	/** 报听不胡的牌 */
	private List<Pai> baoTingOverJiePaoPais = new ArrayList<Pai>();

	public ListMjAbs(int id) {
		super();
		this.id = id;
		for (int i = 0; i < TING_CACHE_MAX; i++) {
			this.tingCacheList.add(new Ting(i, this));
		}
	}

	/**
	 * 初始化
	 * 
	 * @param playTypeSet
	 */
	public void init(PlayTypeSet playTypeSet) {
		this.ziMoTimes = 0;
		this.jiePaoTimes = 0;
		this.anGangTimes = 0;
		this.mingGangTimes = 0;
		this.jieGangTimes = 0;
		this.fangPaoTimes = 0;
		this.fangGangTimes = 0;
		this.playTypeSet = playTypeSet;
		this.nextRound();
	}

	/**
	 * 重新一局
	 */
	public void nextRound() {
		super.init();
		Arrays.fill(mjCounts, 0);
		for (Ting ting : this.tingCacheList) {
			ting.init();
		}
		this.mjSum = 0;
		this.jiangSum = 0;
		this.anGangCacheArr.clear();
		this.mingGangCacheArr.clear();
		this.fangPaoList.clear();
		this.fangQiangGangList.clear();
		this.fangGangList.clear();
		this.baoTing = false;
		this.ziMoPai = null;
		this.qiangGangPai = null;
		this.huPaiTypes = null;
		this.haveDaPaiList.clear();
		this.anGangBeen = 0;
		this.mingGangBeen = 0;
		this.getHuPaiType = null;
		this.yiZiQiaoNumber = 0;
		this.baoFanFenNumber = 0;
		this.zhuaPai = null;
		this.gpcList.clear();
		this.countLai = 0;
		this.handBao = 0;
		this.daBao = 0;
		this.needBaoFanFen = false;
		this.noJiePaoHaveDaPaiSize = 0;
		this.noJiePaoHuPaiTypes = null;
		this.baoTingOverJiePaoPais.clear();
	}

	/** 初始化牌 **/
	public void init(int[] pais) {
		List<Pai> list = new ArrayList<>();
		for (int index = 0; index < pais.length; index++) {
			for (int i = 0; i < pais[index]; i++)
				list.add(MjUtils.getSortHasFengPais().get(index));
		}
		faPai(list);
	}

	public int getId() {
		return id;
	}

	/**
	 * 发13张牌
	 * 
	 * @param pais
	 *            牌队列 牌种34张
	 * @throws Exception
	 */
	public void faPai(List<Pai> list) {
		if (list.size() != MjTools.getNumbermaxMinus()) {
			LoggerService.getPlatformLog().error("必须发{}张牌,mjSum:{}",
					MjTools.getNumbermaxMinus(), list.size());
		}
		for (Pai mj : list) {
			if (!getPai(mj)) {
				LoggerService.getPlatformLog().error("加入牌错误！{}", mj);
			}
		}
		this.calcTing("起手发牌");
	}

	/**
	 * 是否是庄家
	 * 
	 * @return
	 */
	public abstract boolean isBanker();

	/**
	 * 抓牌
	 * 
	 * @param pai
	 * @param isBu
	 *            是否是补牌
	 * @return
	 */
	public boolean zhuaPai(Pai pai, boolean isBu, boolean isHaiDi) {
		if (this.mjSum != MjTools.getNumbermaxMinus()) {
			LoggerService.getPlatformLog().error("抓牌错误！牌总数不为{}张，mjSum:{}",
					MjTools.getNumbermaxMinus(), this.mjSum);
			return false;
		}
		if (pai == null) {
			LoggerService.getPlatformLog().error("牌数据为NULL！！！");
			return false;
		}
		if (this.isBaoTing()) {
			this.cacheZhuaPai(pai, isBu, isHaiDi);
			return true;
		}
		boolean rs = getPai(pai);
		if (rs) {
			this.cacheZhuaPai(pai, isBu, isHaiDi);
			this.calcPaixing(pai);
		}
		return rs;
	}

	private void cacheZhuaPai(Pai pai, boolean isBu, boolean isHaiDi) {
		this.zhuaPai = pai;
		this.cacheZiMo(pai);
		if (!this.isCanZiMo()) {
			return;
		}
		if (this.isBanker() && this.getHaveDaPaiList().isEmpty()
				&& this.gpcList.anGangEmpty()) {
			this.addDaHuInPaiType(HuPaiType.tianHu);
		}
		if (isBu) {
			this.addDaHuInPaiType(HuPaiType.gangBao);
		}
		if (isHaiDi) {
			this.addDaHuInPaiType(HuPaiType.haiDi);
		}
	}

	public Pai getZhuaPai() {
		return zhuaPai;
	}

	/** 加入大胡类型,,huPaiTypes是从列表中引用的，，这里需要copy一份,怕选择过 **/
	public void addDaHuInPaiType(HuPaiType daHu) {
		huPaiTypes = new ArrayList<>(huPaiTypes);// 这里怕选择过，，那就copy一份,,傻逼才会过
		huPaiTypes.remove(HuPaiType.pingHu);
		if (!daHu.ismQ()) {
			huPaiTypes.remove(HuPaiType.mengQing);
		}
		huPaiTypes.add(daHu);
	}

	/** 获得牌 ：发牌、抓牌 */
	private boolean getPai(Pai pai) {
		if (pai == null) {
			LoggerService.getPlatformLog().error("牌数据为NULL！！！");
			return false;
		}
		if (this.mjSum >= MjTools.getNumbermax()) {
			LoggerService.getPlatformLog()
					.error("已经满牌了！！！mjSum:{}", this.mjSum);
			return false;
		}
		boolean add;
		if (isLai(pai)) {
			addCountLai();
			add = true;
		} else {
			add = add(pai);
		}
		if (add) {
			if (isBao(pai)) {
				this.handBao++;
			}
			addStatastic(pai);
		}
		return add;
	}

	/**
	 * <pre>
	 *  统计牌
	 * 获得一个, 吃一个，碰一个 ，都要统计：
	 * 总牌数、每种牌的总数（不包括癞子）、将的数目
	 * 
	 * </pre>
	 * 
	 * @param pai
	 */
	private void addStatastic(Pai pai) {
		this.mjSum++;
		if (!isLai(pai)) {
			this.mjCounts[pai.getType().getType()]++;
			if (pai.isJiang()) {
				this.jiangSum++;
			}
		}
	}

	/**
	 * <pre>
	 * 统计牌
	 * 打一个，暗杠，明杠， 都要统计
	 * </pre>
	 * 
	 * @param pai
	 */
	private void minusStatastic(Pai pai) {
		this.mjSum--;
		this.mjCounts[pai.getType().getType()]--;
		if (pai.isJiang())
			this.jiangSum--;
	}

	/** 缓存自摸 */
	private boolean cacheZiMo(Pai pai) {
		if (isBao(pai)) {
			return false;
		}
		this.huPaiTypes = super.tryTing(pai, GetHuPaiType.ziMo);
		if (this.huPaiTypes == null) {
			return false;
		}
		this.ziMoPai = pai;
		if (MjTools.print())
			LoggerService.getPlatformLog().error("可以自摸！{}", this.huPaiTypes);
		return true;
	}

	/**
	 * 是否自摸
	 * 
	 * @return
	 */
	public boolean isCanZiMo() {
		return this.ziMoPai != null && this.huPaiTypes != null;
	}

	public void ziMo() {
		getHuPaiType = GetHuPaiType.ziMo;
		this.ziMoTimes++;
		if (MjTools.print())
			LoggerService.getPlatformLog().error("自摸！{}", this.getHuPaiTypes());
	}

	/** 生成暗杠列表 */
	private void genAnGangCacheArr() {
		anGangCacheArr.clear();
		for (int index = 0; index < super.getArrayListSize(); index++) {
			int count = super.getCount(index);
			if (count == AN_GANG_PAI_NUM) {
				Pai pai = super.getPai(index);
				if (!isBao(pai)) {
					anGangCacheArr.add(pai);
				}
			}
		}
	}

	private boolean isCanAnGang(Pai pai) {
		if (pai == null) {
			return false;
		}
		return this.anGangCacheArr.contains(pai);
	}

	/**
	 * 暗杠
	 * 
	 * @param pai
	 * @return
	 */
	public boolean anGang(Pai pai) {
		if (!isCanAnGang(pai)) {
			return false;
		}
		boolean removePai = this.removePai(pai, AN_GANG_PAI_NUM);
		if (removePai) {
			this.minusStatastic(pai);
			this.anGangCacheArr.remove(pai);
			this.gpcList.add(new GpcCache(GpcType.AnGang, this.getId(), pai,
					null));
			calcTing(String.format("暗杠%s", pai));
			this.anGangTimes++;
		}
		return removePai;
	}

	/**
	 * 生成明杠列表
	 * 
	 * 只有抓的牌才能明杠
	 * 
	 * @param zhuaPai
	 */
	private void genMingGangCacheArr(Pai zhuaPai) {
		mingGangCacheArr.clear();
		if (this.isRightNowZhuaCanMingGang()) {
			if (zhuaPai == null) {
				return;
			}
			if (this.gpcList.isPeng(zhuaPai)
					&& this.getPaiCount(zhuaPai) == MING_GANG_PAI_NUM) {
				if (!isBao(zhuaPai))
					mingGangCacheArr.add(zhuaPai);
			}
		} else {
			for (GpcCache cache : this.gpcList.getPengList()) {
				Pai pai = cache.getPai();
				if (this.getZiList().contains(pai)
						&& this.getPaiCount(pai) == MING_GANG_PAI_NUM) {
					if (!isBao(pai))
						mingGangCacheArr.add(pai);
				}
			}
		}
	}

	private boolean isCanMingGang(Pai pai) {
		if (pai == null) {
			return false;
		}
		return this.mingGangCacheArr.contains(pai);
	}

	/**
	 * 明杠预处理
	 * 
	 * @param pai
	 * @return
	 */
	public boolean mingGangPrev(Pai pai) {
		if (!isCanMingGang(pai)) {
			LoggerService.getPlatformLog().error("不能明杠！");
			return false;
		}
		boolean removePai = this.removePai(pai, MING_GANG_PAI_NUM);
		if (removePai) {
			this.minusStatastic(pai);
		}
		return removePai;
	}

	/**
	 * 明杠成功，无人抢杠
	 * 
	 * @param pai
	 * @return
	 */
	public GpcCache mingGangSuccess(Pai pai, boolean mingGangSuanJieGang) {
		this.mingGangCacheArr.remove(pai);
		GpcCache mingGang = this.gpcList.mingGang(pai, mingGangSuanJieGang);
		calcTing(String.format("明杠%s", pai));

		this.mingGangTimes++;
		return mingGang;
	}

	/** 之前碰的牌被明杠了也做放杠 */
	public void mingGangFangGang(Pai pai) {
		this.fangGangList.add(pai);
		this.fangGangTimes++;
	}

	public boolean daPai(Pai pai) {
		if (isLai(pai)) {
			LoggerService.getPlatformLog().error("癞子不能打！lai:{}", pai);
			return false;
		}
		if (this.isBaoTing()) {
			if (pai != this.zhuaPai) {
				LoggerService.getPlatformLog().error(
						"报听必须打抓的牌！zhuaPai：{}，pai:{}", zhuaPai, pai);
				return false;
			}
			this.cacheDaPai(pai);
			return true;
		}
		int index = this.getPaiIndex(pai);
		if (index == -1) {
			String format = String.format("%s,打牌，找不到牌！%s %s",
					new Exception().getStackTrace()[0], pai, this.getZiList());
			System.err.println(format);
			LoggerService.getPlatformLog().error(format);
			return false;
		}
		boolean removePai = this.removePai(pai, 1);
		if (removePai) {
			if (this.getPlayTypeSet().isFeiBao()) {
				if (getHandBao() == 1 && !isBao(pai)) {
					needBaoFanFen = true;
				} else {
					needBaoFanFen = false;
				}
				if (isBao(pai)) {
					this.handBao--;
					this.daBao++;
				}
			}
			this.cacheDaPai(pai);
			this.minusStatastic(pai);
			Ting ting = this.tingCacheList.get(index);
			if (ting.isTing()) {
				this.calcTing(String.format("打%s", pai));
			} else {
				this.clearTingCache();
			}
		}
		return removePai;
	}

	public void cacheDaPai(Pai pai) {
		this.haveDaPaiList.add(pai);
	}

	/** 刚打过的牌 **/
	public Pai getHaveDaPai() {
		if (haveDaPaiList.isEmpty()) {
			return null;
		}
		return haveDaPaiList.get(haveDaPaiList.size() - 1);
	}

	public List<Pai> getHaveDaPaiList() {
		return haveDaPaiList;
	}

	/**
	 * 碰
	 * 
	 * @param haveDaPai
	 *            打过的牌
	 * @param seetIndex
	 *            谁打的牌
	 * @return
	 */
	public boolean peng(Pai haveDaPai, int seetIndex) {
		if (!isCanPeng(haveDaPai)) {
			return false;
		}
		boolean removePai = this.removePai(haveDaPai, 2);
		if (removePai) {
			this.zhuaPai = null;
			this.gpcList.add(new GpcCache(GpcType.Peng, seetIndex, haveDaPai,
					null));
			if (isBao(haveDaPai)) {
				this.handBao -= 2;
				this.daBao += 3;
			}
			addStatastic(haveDaPai);
			calcPaixing(null);
		}
		return removePai;
	}

	/**
	 * 吃
	 * 
	 * @param chi
	 * @param haveDaPai
	 *            打过的牌
	 * @param seetIndex
	 *            谁打的牌
	 * @return
	 */
	public boolean chi(ChiType chi, Pai haveDaPai, int seetIndex) {
		Pai[] pais = isCanChi(chi, haveDaPai);
		boolean removePai = this.removePai(pais[0], 1)
				&& this.removePai(pais[1], 1);
		if (removePai) {
			this.zhuaPai = null;
			this.gpcList.add(new GpcCache(GpcType.Chi, seetIndex, haveDaPai,
					chi));
			addStatastic(haveDaPai);
			calcPaixing(null);
		}
		return removePai;
	}

	public Pai[] isCanChi(ChiType chi, Pai haveDaPai) {
		if (this.isBaoTing()) {
			return null;
		}
		if (this.isBao(haveDaPai)) {
			return null;
		}
		Pai[] pais = ChiType.getPais(chi, haveDaPai);
		if (!isCanChi(pais)) {
			return null;
		}
		return pais;
	}

	private boolean isCanChi(Pai[] pais) {
		if (isBao(pais[0]) || isBao(pais[1])) {
			return false;
		}
		if (this.isBaoTing()) {
			return false;
		}
		return this.getPaiCount(pais[0]) >= 1 && this.getPaiCount(pais[1]) >= 1;
	}

	/**
	 * 抓牌，吃，碰，计算暗杠，明杠，听牌牌型
	 * 
	 * @param pai
	 *            如果是抓牌传抓的牌否则传NULL
	 */
	private void calcPaixing(Pai pai) {
		this.genAnGangCacheArr();
		this.genMingGangCacheArr(pai);
		this.cacheTingPai();
	}

	/**
	 * 能否抢杠胡
	 * 
	 * @param pai
	 * @return
	 */
	public boolean isCanQiangGangHu() {
		return this.huPaiTypes != null && this.qiangGangPai != null;
	}

	/**
	 * 缓存抢杠胡
	 * 
	 * @param pai
	 * @return
	 */
	public boolean cacheQiangGangHu(Pai pai) {
		if (this.mjSum != MjTools.getNumbermaxMinus()) {
			this.huPaiTypes = null;
			this.qiangGangPai = null;
			if (MjTools.print())
				LoggerService.getPlatformLog().error("海底了！不用计算抢杠");
			return false;
		}
		this.huPaiTypes = super.tryTing(pai, GetHuPaiType.qiangGang);
		if (this.huPaiTypes == null) {
			this.qiangGangPai = null;
			return false;
		}
		this.qiangGangPai = pai;
		this.addDaHuInPaiType(HuPaiType.qiangGangHu);
		return true;
	}

	/**
	 * 能否明杠
	 * 
	 * @param mj
	 * @return
	 */
	public boolean isMingGang(Pai mj) {
		return this.getPaiCount(mj) == 3;
	}

	/**
	 * 检测听牌
	 */
	protected void cacheTingPai() {
		for (Ting ting : this.tingCacheList) {
			ting.calc();
		}
	}

	public MjType getQingYiSeType(int index) {
		MjType daType = this.getPai(index).getType();
		if (mjCountIncludeLai(daType) == MjTools.getNumbermax()) {
			return daType;
		} else if (this.mjCount(daType) == 1) {
			for (MjType type : MjType.values()) {
				if (mjCountIncludeLai(type) == MjTools.getNumbermaxMinus()) {
					return type;
				}
			}
			return null;
		} else
			return null;
	}

	public final MjType getQingYiSeType() {
		for (MjType type : MjType.values()) {
			if (mjCountIncludeLai(type) == MjTools.getNumbermaxMinus()) {
				return type;
			} else if (this.mjCount(type) > 0) {
				return null;
			}
		}
		return null;
	}

	/** 某个色的数目，包括癞子 */
	private int mjCountIncludeLai(MjType type) {
		return mjCount(type) + this.getCountLai();
	}

	private int mjCount(MjType type) {
		return this.mjCounts[type.getType()];
	}

	/**
	 * 移除牌
	 * 
	 * @param pai
	 * @param num
	 *            移除1张是打牌或明杠;移除2是碰,3张是接杠,4张是暗杠
	 * @return
	 */
	private boolean removePai(Pai pai, int num) {
		if (pai == null) {
			LoggerService.getPlatformLog().error("麻将为空！");
			return false;
		}
		int index = this.getPaiIndex(pai);
		if (index == -1) {
			LoggerService.getPlatformLog().error("找不到麻将！mj:{}", pai);
			return false;
		}
		Integer count = this.getCount(index);
		if (count < num) {
			LoggerService.getPlatformLog().error("移除麻将数量错误！count:{},num:{}",
					count, num);
			return false;
		}
		this.remove(index, num);
		return true;
	}

	public final int getCountLai() {
		return countLai;
	}

	public void addCountLai() {
		this.countLai++;
	}

	/**
	 * 是否报听
	 * 
	 * @return
	 */
	public boolean isBaoTing() {
		return baoTing;
	}

	/**
	 * 是否报听请求
	 * 
	 * @param baoTing
	 */
	public void setBaoTing(boolean baoTing) {
		this.baoTing = baoTing;
		if (this.baoTing) {
			this.anGangCacheArr.clear();
			this.mingGangCacheArr.clear();
			this.allAddDaHuPaiType(HuPaiType.baoTing);
		}
	}

	public ArrayList<Pai> getMingGangCacheArr() {
		return mingGangCacheArr;
	}

	public ArrayList<Pai> getAnGangCacheArr() {
		return anGangCacheArr;
	}

	public int getAnGangNumber() {
		return gpcList.getAnGangList().size();
	}

	public int getMingGangNumber() {
		return gpcList.getMingGangList().size();
	}

	public int getJieGangNumber() {
		return gpcList.getJieGangList().size();
	}

	public GpcList getGpcList() {
		return gpcList;
	}

	public Pai getZiMoPai() {
		return ziMoPai;
	}

	public Pai getQiangGangPai() {
		return qiangGangPai;
	}

	public ArrayList<Ting> getTingCacheList() {
		return tingCacheList;
	}

	public ArrayList<HuPaiType> getHuPaiTypes() {
		return huPaiTypes;
	}

	public int getHuPaiFan() {
		return this.getPlayTypeSet().calcFan(this.huPaiTypes);
	}

	/**
	 * 缓存接炮
	 * 
	 * @param daPai
	 *            打的牌
	 * @return
	 */
	public boolean cacheJiePao(Pai daPai) {
		this.huPaiTypes = super.tryTing(daPai, GetHuPaiType.jiePao);
		if (this.huPaiTypes == null) {
			return false;
		}
		if (this.isCanDiHu()) {
			this.addDaHuInPaiType(HuPaiType.diHu);
		}
		if (this.getPlayTypeSet().isRoundDoubleHu()
				&& this.noJiePaoHaveDaPaiSize != 0
				&& this.noJiePaoHaveDaPaiSize == this.haveDaPaiList.size()
				&& this.getPlayTypeSet().calcFan(this.noJiePaoHuPaiTypes) >= this
						.getPlayTypeSet().calcFan(this.huPaiTypes)) {
			this.huPaiTypes = null;
			return false;
		}
		if (!this.baoTingOverJiePaoPais.isEmpty()
				&& this.baoTingOverJiePaoPais.contains(daPai)) {
			this.huPaiTypes = null;
			return false;
		}
		if (this.getPlayTypeSet().isKaQiao() && this.getZiList().size() == 4
				&& this.huPaiTypes.size() == 1
				&& this.huPaiTypes.get(0) == HuPaiType.pengPengHu) {
			this.huPaiTypes = null;
			return false;
		}
		if (MjTools.print())
			LoggerService.getPlatformLog().error("可以接炮！{}", this.huPaiTypes);
		return true;
	}

	public boolean isCanJiePao() {
		return this.huPaiTypes != null;
	}

	/**
	 * 接炮
	 */
	public void jiePao() {
		this.getHuPaiType = GetHuPaiType.jiePao;
		this.jiePaoTimes++;
		if (MjTools.print())
			LoggerService.getPlatformLog().error("接炮！{}", this.huPaiTypes);
	}

	/**
	 * 接杠
	 * 
	 * @param haveDaPai
	 *            打过的牌
	 * @param
	 * @return
	 */
	public boolean jieGang(Pai haveDaPai, int seetIndex) {
		if (!isCanJieGang(haveDaPai)) {
			return false;
		}
		boolean removePai = this.removePai(haveDaPai, JIE_GANG_PAI_NUM);
		if (removePai) {
			this.gpcList.add(new GpcCache(GpcType.JieGang, seetIndex,
					haveDaPai, null));
			calcTing(String.format("接杠%s", haveDaPai));
			this.jieGangTimes++;
		}
		return removePai;
	}

	/** 放炮 */
	public void fangPao(ListMjAbs listMjAbs) {
		this.fangPaoList.add(listMjAbs);
		this.fangPaoTimes++;
	}

	public int getFangPaoNumber() {
		return this.fangPaoList.size();
	}

	/** 放抢杠 */
	public void fangQiangGang(ListMjAbs listMjAbs) {
		this.fangQiangGangList.add(listMjAbs);
	}

	public int getFangQiangGangNumber() {
		return this.fangQiangGangList.size();
	}

	/** 放杠 */
	public void fangGang() {
		this.fangGangList.add(this.getHaveDaPai());
		removeCurHaveDaPai();
		this.fangGangTimes++;
	}

	private void removeCurHaveDaPai() {
		this.haveDaPaiList.remove(this.haveDaPaiList.size() - 1);
	}

	public int getFangGangNumber() {
		return this.fangGangList.size();
	}

	/** 放碰 */
	public void fangPeng() {
		removeCurHaveDaPai();
	}

	/** 放吃 */
	public void fangChi() {
		removeCurHaveDaPai();
	}

	/**
	 * 是否同一个色
	 * 
	 * @param index
	 * @return
	 */
	public boolean isSameSe(int index, MjType type) {
		return type != null && type == this.getPai(index).getType();
	}

	public boolean isCanPeng(Pai haveDaPai) {
		if (this.isBaoTing()) {
			return false;
		}
		int paiCount = this.getPaiCount(haveDaPai);
		return paiCount > 1;
	}

	public boolean isCanJieGang(Pai haveDaPai) {
		if (this.isBaoTing()) {
			return false;
		}
		if (this.isBao(haveDaPai)) {
			return false;
		}
		int paiCount = this.getPaiCount(haveDaPai);
		return paiCount == JIE_GANG_PAI_NUM;
	}

	public int getAnGangBeen() {
		return anGangBeen;
	}

	public void addAnGangBeen() {
		this.anGangBeen++;
	}

	public int getMingGangBeen() {
		return mingGangBeen;
	}

	public void addMingGangBeen() {
		this.mingGangBeen++;
	}

	public void qiangGang() {
		this.getHuPaiType = GetHuPaiType.qiangGang;
		LoggerService.getPlatformLog().error("抢杠胡！{}", this.getHuPaiTypes());
	}

	public GetHuPaiType getGetHuPaiType() {
		return getHuPaiType;
	}

	public void addYiZiQiaoNumber() {
		this.yiZiQiaoNumber++;
	}

	public int getYiZiQiaoNumber() {
		return yiZiQiaoNumber;
	}

	public void addBaoFanFenNumber() {
		this.baoFanFenNumber++;
	}

	public int getBaoFaFenNumber() {
		return baoFanFenNumber;
	}

	/**
	 * 是否4个宝中碰了一个
	 * 
	 * @return
	 */
	public GpcCache isPengBao4() {
		return this.getDaBao() == 4 ? getPengBao() : null;
	}

	/**
	 * 是否4个宝牌都是抓的
	 * 
	 * @return
	 */
	public boolean isZhuaBao4() {
		return this.getDaBao() == 4 && getPengBao() == null;
	}

	private GpcCache getPengBao() {
		for (GpcCache gpc : this.gpcList.getPengList()) {
			if (isBao(gpc.getPai())) {
				return gpc;
			}
		}
		return null;
	}

	public int[] getMjCounts() {
		return mjCounts;
	}

	public int getZiMoTimes() {
		return ziMoTimes;
	}

	public int getJiePaoTimes() {
		return jiePaoTimes;
	}

	public int getAnGangTimes() {
		return anGangTimes;
	}

	public int getMingGangTimes() {
		return mingGangTimes;
	}

	public int getJieGangTimes() {
		return jieGangTimes;
	}

	public int getFangPaoTimes() {
		return fangPaoTimes;
	}

	public int getFangGangTimes() {
		return fangGangTimes;
	}

	public int getMjSum() {
		return mjSum;
	}

	public int getJiangSum() {
		return this.playTypeSet.isLai() ? jiangSum + this.getCountLai()
				: jiangSum;
	}

	public ArrayList<ListMjAbs> getFangPaoList() {
		return fangPaoList;
	}

	public ArrayList<ListMjAbs> getFangQiangGangList() {
		return fangQiangGangList;
	}

	public ArrayList<Pai> getFangGangList() {
		return fangGangList;
	}

	/***
	 * 检测能否门清
	 * 
	 * @return
	 */
	public boolean checkCanMengQing() {
		return this.gpcList.isCanMengQing();
	}

	/**
	 * 检测是否杠碰吃过
	 */
	public boolean checkNotHasGpc() {
		return this.gpcList.notHasGpc();
	}

	@Override
	public boolean isAllPengOrGang() {
		return this.gpcList.isAllPengOrGang();
	}

	/**
	 * 检测能否一字撬
	 * 
	 * @return
	 */
	public boolean checkCanYiZiQiao() {
		return this.getHuPaiType == null
				&& (!this.getHuPaiTypesList().isEmpty() && this
						.getHuPaiTypesList().get(0)
						.contains(this.playTypeSet.getQuanQiuRenType()));
	}

	@Override
	public boolean isYiTiaoLong() {
		return this.playTypeSet.isYiTiaoLong();
	}

	@Override
	public boolean isCanMengQing() {
		return this.playTypeSet.isMengQing() && this.checkCanMengQing();
	}

	@Override
	public boolean isJiangJiangHuJiePao() {
		return this.playTypeSet.isJiangJiangHuJiePao();
	}

	@Override
	public boolean isMengQingJiangJiangJiePao() {
		return this.playTypeSet.isMengQingJiangJiangJiePao();
	}

	@Override
	public boolean isCanShiSanLan() {
		return this.playTypeSet.isShiSanLan()
				&& this.checkNotHasGpc()
				&& this.getNumber() == ShiSanLanUtils.getShiSanLanNumber(this
						.getCountLai());
	}

	@Override
	public boolean isCanShiSanLan(long number) {
		return this.playTypeSet.isShiSanLan()
				&& this.checkNotHasGpc()
				&& number == ShiSanLanUtils.getShiSanLanNumber(this
						.getCountLai());
	}

	@Override
	public boolean isCanBaoTing() {
		return this.playTypeSet.isBaoTing() && !isBanker()
				&& this.getHaveDaPaiList().isEmpty() && this.isTing();
	}

	@Override
	public boolean isCanYiZiQiao() {
		return this.playTypeSet.isYiZiQiao() && this.getZiList().size() == 1
				&& getCountLai() == 0;
	}

	@Override
	public boolean isCanYiZiQiao(int index) {
		return this.playTypeSet.isYiZiQiao() && this.getZiList().size() == 2
				&& getCountLai() == 0;
	}

	@Override
	public boolean isCanYiZiQiaoYouXi() {
		return this.playTypeSet.isYiZiQiaoYouXi() && this.checkCanYiZiQiao();
	}

	@Override
	public boolean isCanJiangJianghu() {
		return this.playTypeSet.isJiangJianghu()
				&& this.getJiangSum() == MjTools.getNumbermaxMinus();
	}

	@Override
	public boolean isCanJiangJianghu(int index) {
		return this.playTypeSet.isJiangJianghu()
				&& (this.getPai(index).isJiang() ? this.getJiangSum() == MjTools
						.getNumbermax() : this.getJiangSum() == MjTools
						.getNumbermaxMinus());
	}

	@Override
	public boolean isPingHuJiePao() {
		return this.playTypeSet.isPingHuJiePao();
	}

	@Override
	public boolean isCanHunYiSe() {
		if (!this.playTypeSet.isHunYiSe() || this.mjCount(MjType.feng) == 0)
			return false;
		int countZero = 0;
		for (MjType type : MjType.noFeng()) {
			if (this.mjCount(type) == 0)
				countZero++;
		}
		return countZero == 2;
	}

	@Override
	public boolean isCanHunYiSe(int index) {
		if (!this.playTypeSet.isHunYiSe() || this.mjCount(MjType.feng) == 0)
			return false;
		if (this.getPai(index).getType() == MjType.feng
				&& this.mjCount(MjType.feng) == 1) {
			return false;
		}
		int countZero = 0;
		for (MjType type : MjType.noFeng()) {
			int mjCount = this.mjCount(type);
			if (mjCount == 0
					|| (mjCount == 1 && this.getPai(index).getType() == type))
				countZero++;
		}
		return countZero == 2;
	}

	public PlayTypeSet getPlayTypeSet() {
		return playTypeSet;
	}

	public int getHandBao() {
		return handBao;
	}

	public int getHandBao(int index) {
		if (isBao(this.getPai(index))) {
			return this.getHandBao() - 1;
		} else
			return this.getHandBao();

	}

	public int getDaBao() {
		return daBao;
	}

	@Override
	public int getDaBao(int index) {
		if (isBao(this.getPai(index))) {
			return this.getDaBao() + 1;
		} else
			return this.getDaBao();
	}

	@Override
	public boolean isRightNowZhuaCanMingGang() {
		return this.playTypeSet.isRightNowZhuaCanMingGang();
	}

	/** 有宝牌没打，罚分？ */
	public boolean isNeedBaoFaFen() {
		return needBaoFanFen;
	}

	@Override
	public boolean isPinghuBaoTingJiePao() {
		return this.playTypeSet.isPinghuBaoTingJiePao();
	}

	/***
	 * 记录有接炮时不接炮
	 * 
	 * @param pai
	 *            接炮的牌
	 */
	public void recordNoJiePao(Pai pai) {
		this.noJiePaoHaveDaPaiSize = this.haveDaPaiList.size();
		this.noJiePaoHuPaiTypes = this.huPaiTypes;
		if (this.isBaoTing()) {
			this.baoTingOverJiePaoPais.add(pai);
		}
	}

}
