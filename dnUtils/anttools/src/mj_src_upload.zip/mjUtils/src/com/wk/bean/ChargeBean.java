package com.wk.bean;

import java.sql.Timestamp;
import java.util.Date;

import com.wk.enun.ChargeStatus;

public class ChargeBean {
	private String orderId;// 订单号
	private long username;// 玩家唯一id
	private int agency;// 代理邀请码
	private int diamond;// 充值钻石数
	private String money;// 金额
	/** 苹果回执 **/
	private String apple_receipt;
	private ChargeStatus chargeStatus;// 状态0待处理1处理
	private Date chargeTime;// 充值时间
	private Timestamp updateTime;

	public ChargeBean() {
		super();
	}

	public ChargeBean(String orderId, long username, int agency, int diamond,
			String money, String apple_receipt, ChargeStatus status,
			Date chargeTime, Timestamp updateTime) {
		super();
		this.orderId = orderId;
		this.username = username;
		this.agency = agency;
		this.diamond = diamond;
		this.money = money;
		this.apple_receipt = apple_receipt;
		this.chargeStatus = status;
		this.chargeTime = chargeTime;
		this.updateTime = updateTime;
	}

	public Timestamp getUpdateTime() {
		return updateTime;
	}

	public String getOrderId() {
		return orderId;
	}

	public long getUsername() {
		return username;
	}

	public int getAgency() {
		return agency;
	}

	

	public int getDiamond() {
		return diamond;
	}

	public void setDiamond(int diamond) {
		this.diamond = diamond;
	}

	public String getApple_receipt() {
		return apple_receipt;
	}

	public void setStatus(int status) {
		this.chargeStatus = ChargeStatus.getEnum(status);
	}

	public int getStatus() {
		return chargeStatus.getType();
	}

	public ChargeStatus getChargeStatus() {
		return chargeStatus;
	}

	public Date getChargeTime() {
		return chargeTime;
	}

	public String getMoney() {
		return money;
	}
	
	public void setMoney(String money) {
		this.money = money;
	}
	
	

	@Override
	public String toString() {
		return "ChargeBean [orderId=" + orderId + ", username=" + username
				+ ", agency=" + agency + ", diamond=" + diamond + ",money="
				+ money + ", status=" + chargeStatus + ", chargeTime="
				+ chargeTime + "]";
	}

}
