package com.wk.template;

import java.io.File;
import java.util.HashMap;
import java.util.List;

import com.wk.I.EditableFile;
import com.wk.util.ReadUtil;
import com.wk.util.TemplateCheckAbs;

public class ShopDiamondTemplate implements TemplateCheckAbs {

	private static HashMap<Integer, ShopDiamondTemplate> shopMap;

	private static EditableFile edit = null;

	/**
	 * 解析静态数据
	 * 
	 * @param path
	 * @return
	 * @throws Exception
	 */
	public static EditableFile init(String csvDir) throws Exception {
		if (edit == null) {
			edit = new EditableFile(new File(csvDir)) {
				public void run() throws Exception {
					List<ShopDiamondTemplate> shopList = ReadUtil
							.explainCsvData(getPath(),
									ShopDiamondTemplate.class, true);
					HashMap<Integer, ShopDiamondTemplate> hashMap = new HashMap<Integer, ShopDiamondTemplate>();
					for (ShopDiamondTemplate shopDiamondTemplate : shopList) {
						hashMap.put(shopDiamondTemplate.iD, shopDiamondTemplate);
					}
					shopMap = hashMap;
				}
			};
		}
		return edit;
	}

	private int iD, rechargeNum, giftNum, spendNum;

	private String money;
	private String subject;
	private String body;
	private String desc;
	private String dis;
	private int totalDiamond;

	public int getiD() {
		return iD;
	}

	public String getMoney() {
		return money;
	}

	public String getSubject() {
		return subject;
	}

	public String getBody() {
		return body;
	}

	public String getDesc() {
		return desc;
	}

	public String getDis() {
		return dis;
	}

	public int getTotalDiamond() {
		return totalDiamond;
	}

	public static ShopDiamondTemplate getShopDiamondTemplate(int pay_id) {
		return shopMap.get(pay_id);
	}

	@Override
	public void check() throws Exception {
		this.totalDiamond = rechargeNum + giftNum;
		// if (ServerConfigAbs.isDebug()) {
		// this.money = String.format("%.2f", this.iD / 100.0f);
		// } else {
		this.money = String.format("%.2f", this.spendNum * 1.0f);
		// }
		this.subject = String.format("%s+%s钻石", this.rechargeNum, this.giftNum);
		this.body = String.format("花费%s元", getMoney());
		this.desc = String.format("(%s+%s)钻石&nbsp</br>&nbsp&nbsp%s元",
				rechargeNum, giftNum, getMoney());
		this.dis = String.format("获得：%s+%s颗钻石</br>总计：%s颗钻石</br>应付：%s元",
				rechargeNum, giftNum, this.totalDiamond, getMoney());
	}

}
