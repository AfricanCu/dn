package com.wk.mj.enun;

import java.util.ArrayList;
import java.util.List;

import com.wk.mj.Pai;

public enum MjType {
	/***/
	wang(1, "万"),
	/***/
	suo(2, "索"),
	/***/
	tong(3, "筒"),
	/***/
	feng(4, "风");
	/** ID **/
	private final int type;
	/** ***/
	private final String name;
	/** 开始 ***/
	private final int startIndex;
	/** 结束 ***/
	private final int endIndex;
	/** 麻将集合 **/
	private final List<Pai> mjList;

	private MjType(int type, String name) {
		this.type = type;
		this.name = name;
		this.startIndex = this.type * 10 - 9;
		this.endIndex = this.type == 4 ? this.type * 10 - 3
				: this.type * 10 - 1;
		this.mjList = new ArrayList<>();
		for (int i = startIndex; i <= endIndex; i++) {
			this.mjList.add(new Pai(i, this));
		}
		if (type != 4) {
			for (int i = 0; i < this.mjList.size(); i++) {
				Pai prev = i - 1 >= 0 ? this.mjList.get(i - 1) : Pai.emptyMj;
				Pai next = i + 1 < this.mjList.size() ? this.mjList.get(i + 1)
						: Pai.emptyMj;
				this.mjList.get(i).setNear(prev, next);
			}
		}
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	public int getStartIndex() {
		return startIndex;
	}

	public int getEndIndex() {
		return endIndex;
	}

	public List<Pai> getMjList() {
		return mjList;
	}

	/**
	 * 
	 * @param index
	 *            List下标
	 * @return
	 */
	public Pai getPaiByIndex(int index) {
		return mjList.get(index);
	}

	/**
	 * 获取宝牌
	 * 
	 * @param dieBao
	 *            跌宝牌
	 * @return
	 */
	public Pai getBaoPai(Pai dieBao) {
		if (dieBao == null) {
			return null;
		}
		if (dieBao.isFeng()) {
			if (dieBao.getNumber() == 4) {// 东南西北一圈
				return this.mjList.get(0);
			} else if (dieBao.getNumber() == 7) {// 中发白一圈
				return this.mjList.get(4);
			} else
				return this.mjList.get(dieBao.getNumber());
		} else {
			if (dieBao.getNumber() == this.mjList.size()) {
				return this.mjList.get(0);
			} else {
				return this.mjList.get(dieBao.getNumber());
			}
		}
	}

	/**
	 * 
	 * @param number
	 *            牌号码=List下标+1
	 * @return
	 */
	public Pai getPaiByNumber(int number) {
		return mjList.get(number - 1);
	}

	@Override
	public String toString() {
		return this.name;
	}

	/**
	 * 无风子
	 * 
	 * @return
	 */
	public static MjType[] noFeng() {
		return new MjType[] { wang, suo, tong };
	}

	// 自动生成开始
public static MjType getEnum(int type){
switch(type) {
case 1:
  return wang;
case 2:
  return suo;
case 3:
  return tong;
case 4:
  return feng;
default:
  return null;
}
}// 自动生成结束
}