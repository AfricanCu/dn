package com.wk.db.dao;

import java.sql.SQLException;

import com.wk.bean.GamerecordBean;
import com.wk.db.IbatisDbServer;

public class GamerecordDao {

	public static GamerecordBean queryRecord(int id) throws SQLException {
		GamerecordBean friend = (GamerecordBean) IbatisDbServer
				.getGmSqlMapper().queryForObject("gamerecord.queryGamerecord",
						id);
		return friend;
	}

	public static int insertGamerecord(GamerecordBean gamerecord)
			throws SQLException {
		return (Integer) IbatisDbServer.getGmSqlMapper().insert(
				"gamerecord.insertGamerecord", gamerecord);
	}
}
