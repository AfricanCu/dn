package com.wk.mj.enun;

import com.wk.mj.Pai;

public enum ChiType {
	XiaoBian(1), ZhongJian(2), DaBian(3);

	private final int type;

	private ChiType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	/**
	 * 要喂食的牌组合
	 * 
	 * @param chi
	 * @param haveDaPai
	 * @return
	 */
	public static Pai[] getPais(ChiType chi, Pai haveDaPai) {
		Pai[] pais = new Pai[2];
		switch (chi) {
		case XiaoBian:
			pais[0] = haveDaPai.getNext();
			pais[1] = haveDaPai.getNext().getNext();
			break;
		case DaBian:
			pais[0] = haveDaPai.getPrev();
			pais[1] = haveDaPai.getPrev().getPrev();
			break;
		case ZhongJian:
			pais[0] = haveDaPai.getPrev();
			pais[1] = haveDaPai.getNext();
			break;
		default:
			return null;
		}
		return pais;
	}

	// 自动生成开始
public static ChiType getEnum(int type){
switch(type) {
case 1:
  return XiaoBian;
case 2:
  return ZhongJian;
case 3:
  return DaBian;
default:
  return null;
}
}// 自动生成结束
}