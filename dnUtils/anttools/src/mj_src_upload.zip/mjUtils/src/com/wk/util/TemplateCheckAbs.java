package com.wk.util;

/**
 * 对配置表检测接口
 * 
 * @author ems
 *
 */
public interface TemplateCheckAbs {
	/**
	 * 检测
	 */
	public abstract void check() throws Exception;
}
