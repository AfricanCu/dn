package com.wk.bean;

import java.util.Date;

public class RoomBean {
	private long id;
	private int serverId;
	private long masterUid;
	private Date updateTime;
	private byte[] back;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public int getServerId() {
		return serverId;
	}

	public void setServerId(int serverId) {
		this.serverId = serverId;
	}

	public long getMasterUid() {
		return masterUid;
	}

	public void setMasterUid(long masterUid) {
		this.masterUid = masterUid;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public byte[] getBack() {
		return back;
	}

	public void setBack(byte[] back) {
		this.back = back;
	}

}
