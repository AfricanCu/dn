package com.wk.mj.enun;

/**
 * 过，吃，碰，接杠，接炮，
 * 
 * 其他人打牌后自己的操作
 * 
 * @author ems
 *
 */
public enum AfterOtherDaPaiType {
	nothing(0), chiPai(1), pengPai(2), jieGang(3), jiePao(4);
	private final int type;

	private AfterOtherDaPaiType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	// 自动生成开始
public static AfterOtherDaPaiType getEnum(int type){
switch(type) {
case 0:
  return nothing;
case 1:
  return chiPai;
case 2:
  return pengPai;
case 3:
  return jieGang;
case 4:
  return jiePao;
default:
  return null;
}
}// 自动生成结束
}