package com.wk.mj;

public class Gang {
	private final boolean ming;
	private final Pai mj;
	/** 杠的谁 **/
	private final int direct;

	public Gang(boolean ming, Pai mj, int direct) {
		super();
		this.ming = ming;
		this.mj = mj;
		this.direct = direct;
	}

	public boolean isMing() {
		return ming;
	}

	public Pai getMj() {
		return mj;
	}

	public int getDirect() {
		return direct;
	}
}