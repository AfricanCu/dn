package com.wk.mj;

public class CommonMjTools {

}
