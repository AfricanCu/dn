package com.wk.mj.lai;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.Compose;
import com.wk.mj.ListMjAbs;
import com.wk.mj.MjTools;
import com.wk.mj.Pai;
import com.wk.mj.enun.MjType;

public class LaiTools {
	public static void main(String[] args) throws IOException {
		long currentTimeMillis = System.currentTimeMillis();
		LoggerService.initDef();
		MjTools.init();
		LoggerService.getPlatformLog().error("{}",
				System.currentTimeMillis() - currentTimeMillis);
		init(true);
		int[] arr = new int[] {
				// wang suo tong
				1, 0, 0, 2, 0, 0, 0, 0, 0,

				0, 0, 1, 1, 1, 1, 0, 0, 0,

				0, 3, 3, 0, 0, 0, 0, 0, 0,
				// 胡九张
				// 3, 1, 1, 1, 1, 1, 1, 1, 3,
				// 胡八张
				// 0, 3, 1, 1, 1, 2, 4, 1, 0,
				// 0, 3, 1, 1, 1, 1, 4, 1, 1,
				// 0, 1, 4, 2, 1, 1, 1, 3, 0,
				// 1, 1, 4, 1, 1, 1, 1, 3, 0,
				// 0, 1, 1, 4, 1, 1, 1, 1, 3,
				// 胡七张
				// 2, 0, 0, 0, 0, 1, 1, 1, 0,
				// feng
				0, 0, 0, 0, };
		ListMjAbs listMjAbs = createListMjAbs(MjType.wang.getPaiByNumber(1));
		listMjAbs.init(arr);
		LoggerService.getPlatformLog().error("{},{}", listMjAbs.getCountLai(),
				listMjAbs);
		LoggerService.getPlatformLog().error("是否听牌：{}", listMjAbs.isTing());
		LoggerService.getPlatformLog().error("加载癞子牌型耗时：{}",
				System.currentTimeMillis() - currentTimeMillis);
		try {
			Thread.sleep(1000 * 100);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

	private static final List<Map<Long, CxqLai>> laiMapList = new ArrayList<>();
	public static final String filePath = "./resource/lai.data";

	/**
	 * 是否从文件中load数据
	 * 
	 * @return
	 */
	public static boolean loadData() {
		return false;
	}

	public static boolean print() {
		return false;
	}

	static boolean test() {
		return false;
	}

	/**
	 * 
	 * 
	 * @param isLai
	 *            是否打癞子
	 * @throws IOException
	 */
	public static void init(boolean isLai) throws IOException {
		long currentTimeMillis = System.currentTimeMillis();
		int laiziNum = isLai ? 4 : 0;
		File file = new File(filePath);
		if (loadData() && file.exists()) {
			FileInputStream fis = new FileInputStream(file);
			ObjectInputStream ois = new ObjectInputStream(fis);
			initLaiMapList(ois, laiziNum);
			ois.close();
			fis.close();
		} else {
			initLaiMapList(null, laiziNum);
		}
		int[] laiziArr = new int[laiziNum + 1];
		for (int i = 0; i < laiziArr.length; i++) {
			laiziArr[i] = i;
		}
		for (Entry<Long, Compose> entry : MjTools.getHupaizuhemap().entrySet()) {
			Compose value = entry.getValue();
			if (test()) {
				value = new Compose(Arrays.asList(2, 0, 1, 1, 1, 1, 1, 1, 0, 3,
						3), null);
			}
			genLai(value, laiziArr);
			if (test())
				break;
		}
		StringBuilder builder = new StringBuilder();
		for (int index = 0; index < laiMapList.size(); index++) {
			Map<Long, CxqLai> laimap = laiMapList.get(index);
			builder.append("\n").append(index).append("个癞子牌型数：")
					.append(laimap.size());
		}
		if (CxqLai.maxListSize != null)
			builder.append("\n最大检测牌型：").append(CxqLai.maxListSize);
		LoggerService.getPlatformLog().error(builder.toString());
		LoggerService.getPlatformLog().error("加载癞子牌型耗时：{}",
				System.currentTimeMillis() - currentTimeMillis);
	}

	public static ListMjAbs createListMjAbs(final Pai laiPai) {
		return new ListMjAbs(1) {

			@Override
			public boolean isCanDiHu() {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isLai(Pai pai) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isBao(Pai pai) {
				// TODO Auto-generated method stub
				return false;
			}

			@Override
			public boolean isBanker() {
				// TODO Auto-generated method stub
				return false;
			}

		};
	}

	/**
	 * 生成癞子牌型
	 * 
	 * @param fullCompose
	 *            完整牌型
	 * @param laiziNum
	 *            癞子数目
	 * @param laiMap
	 *            癞子牌型缓存
	 */
	private static void genLai(Compose fullCompose, int[] laiziArr) {
		for (int laiziNum : laiziArr) {
			if (laiziNum >= 0 && fullCompose.calcListNum() >= laiziNum)
				lai(null, fullCompose, laiziNum, 0, laiziNum);
		}
	}

	/**
	 * 
	 * @param indexList
	 *            移除牌排列
	 * @param fullCompose
	 *            牌型原始排列
	 * @param leftLaiziNum
	 *            剩余癞子数目
	 * @param startIndex
	 *            从哪个位置开始取癞子
	 * @param laiziNum
	 *            癞子数目
	 */
	private static void lai(List<Integer> indexList, Compose fullCompose,
			int leftLaiziNum, int startIndex, int laiziNum) {
		List<Integer> arrayList = fullCompose.getArrayList();
		if (leftLaiziNum < 0) {
			zuhe(indexList, fullCompose, laiziNum);
			return;
		}
		for (int index = startIndex; index < arrayList.size(); index++) {
			if (arrayList.get(index) == 0) {
				continue;
			}
			ArrayList<Integer> iIndex = null;
			if (indexList != null) {
				iIndex = new ArrayList<>(indexList);
			} else {
				iIndex = new ArrayList<>();
			}
			iIndex.add(index);
			lai(iIndex, fullCompose, leftLaiziNum - 1, index, laiziNum);
		}
	}

	/**
	 * 
	 * @param indexList
	 *            哪几个位置移除1个
	 * @param fullCompose
	 *            牌型原始排列
	 * @param laiNum
	 *            癞子数目
	 * @return
	 */
	private static void zuhe(List<Integer> indexList, Compose fullCompose,
			int laiziNum) {
		ArrayList<Integer> retList = fullCompose.getCopyList();
		for (int index : indexList) {
			int ret = retList.get(index) - 1;
			if (ret < 0) {
				return;
			}
			retList.set(index, ret);
		}
		if (laiziNum >= 0 && laiziNum < laiMapList.size()) {
			Map<Long, CxqLai> laiMap = laiMapList.get(laiziNum);
			CxqLai.CreateCxqLai(laiMap, fullCompose, indexList, retList);
		} else {
			LoggerService.getPlatformLog()
					.error("map找不到，laiziNum:{}", laiziNum);
		}
	}

	/***
	 * 计算牌型多少坨
	 * 
	 * @return
	 */
	public static int calcTuoNum(List<Integer> arrayList) {
		int sum = 0;
		for (int xx : arrayList) {
			if (xx == 0)
				sum++;
		}
		return sum + 1;
	}

	public static CxqLai getTingpaiZuhe(long number, int laiziNum) {
		if (laiziNum >= 0 && laiziNum < laiMapList.size()) {
			return laiMapList.get(laiziNum).get(number);
		} else
			return null;
	}

	public static List<Map<Long, CxqLai>> getLaimapList() {
		return laiMapList;
	}

	public static void initLaiMapList(ObjectInputStream ois, int laiziNum)
			throws IOException {
		laiMapList.clear();
		if (ois != null) {
			int saveLaiziNum = ois.readInt();
			for (int index = 0; index < saveLaiziNum && index < laiziNum; index++) {
				int size = ois.readInt();
				HashMap<Long, CxqLai> laimap = new HashMap<Long, CxqLai>(size);
				laiMapList.add(laimap);
				for (int count = 0; count < size; count++) {
					long key = ois.readLong();
					int fullComposeListSize = ois.readInt();
					int positionFindTypeListSize = ois.readInt();
					CxqLai cxqLai = new CxqLai(fullComposeListSize,
							positionFindTypeListSize);
					laimap.put(key, cxqLai);
				}
			}
		}
		for (int i = laiMapList.size(); i <= laiziNum; i++) {
			laiMapList.add(new HashMap<Long, CxqLai>());
		}
	}

	public static void saveLaiData() throws IOException {
		LoggerService.initDef();
		MjTools.init();
		LaiTools.init(true);
		File file = new File(LaiTools.filePath);
		file.createNewFile();
		// 对象序列化过程
		FileOutputStream fos = new FileOutputStream(file);
		ObjectOutputStream oos = new ObjectOutputStream(fos);
		oos.writeInt(LaiTools.getLaimapList().size());// 癞子列表长度
		for (int index = 0; index < LaiTools.getLaimapList().size(); index++) {
			Map<Long, CxqLai> map = LaiTools.getLaimapList().get(index);
			oos.writeInt(map.size());
			for (Entry<Long, CxqLai> value : map.entrySet()) {
				oos.writeLong(value.getKey());
				oos.writeInt(value.getValue().getFullComposeListSize());
				oos.writeInt(value.getValue().getPositionFindTypeListSize());
			}
		}
		oos.flush();
		oos.close();
		fos.close();
	}
}
