package com.wk.mj.enun;

/**
 * 1报听2抓牌3自摸4暗杠5明杠6打牌7接炮8接杠9碰牌
 * 
 * @author ems
 *
 */
public enum OperaType {
	/***/
	baoTing(1),
	/***/
	notBaoTing(2),
	/***/
	zhuaPai(3),
	/***/
	ziMo(4),
	/***/
	anGang(5),
	/***/
	mingGang(6),
	/***/
	daPai(7),
	/***/
	jiePao(8),
	/***/
	jieGang(9),
	/***/
	pengPai(10),
	/***/
	chiPai(11),
	/***/
	jiePaoJieGangPengChiGuo(12),
	/***/
	qiangGangHu(13),
	/***/
	qiangGangGuo(14),
	/***/
	jieGangCast(15),
	/***/
	pengPaiCast(16),
	/***/
	chiPaiCast(17), ;
	private final int type;

	private OperaType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	// 自动生成开始
public static OperaType getEnum(int type){
switch(type) {
case 1:
  return baoTing;
case 2:
  return notBaoTing;
case 3:
  return zhuaPai;
case 4:
  return ziMo;
case 5:
  return anGang;
case 6:
  return mingGang;
case 7:
  return daPai;
case 8:
  return jiePao;
case 9:
  return jieGang;
case 10:
  return pengPai;
case 11:
  return chiPai;
case 12:
  return jiePaoJieGangPengChiGuo;
case 13:
  return qiangGangHu;
case 14:
  return qiangGangGuo;
case 15:
  return jieGangCast;
case 16:
  return pengPaiCast;
case 17:
  return chiPaiCast;
default:
  return null;
}
}// 自动生成结束
}