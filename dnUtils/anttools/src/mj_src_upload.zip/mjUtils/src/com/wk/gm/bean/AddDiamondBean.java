package com.wk.gm.bean;

import java.util.Date;

public class AddDiamondBean {
	private String proxy;// 订单号
	private long uid;// L玩家唯一id
	private String nickname;
	private int diamond;// 充值钻石数
	private Date chargeTime;// 充值时间

	public AddDiamondBean() {
		super();
	}

	public AddDiamondBean(String proxy, long uid, String nickname, int diamond,
			Date chargeTime) {
		super();
		this.proxy = proxy;
		this.uid = uid;
		this.nickname = nickname;
		this.diamond = diamond;
		this.chargeTime = chargeTime;
	}

	public String getProxy() {
		return proxy;
	}

	public long getUid() {
		return uid;
	}

	public String getNickname() {
		return nickname;
	}

	public int getDiamond() {
		return diamond;
	}

	public Date getChargeTime() {
		return chargeTime;
	}

}
