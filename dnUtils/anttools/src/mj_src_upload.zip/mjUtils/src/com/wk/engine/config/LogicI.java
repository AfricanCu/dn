package com.wk.engine.config;

import msg.RoomMessage.PlayType;

/**
 * 游戏逻辑层实现接口
 * 
 * @author ems
 *
 */
public abstract class LogicI {
	public static LogicI instance;

	public static LogicI getInstance() {
		return instance;
	}

	/**
	 * 获取玩法的描述
	 * 
	 * @param playType
	 * @return
	 */
	public abstract String getPlayTypeDesc(PlayType playType);
}
