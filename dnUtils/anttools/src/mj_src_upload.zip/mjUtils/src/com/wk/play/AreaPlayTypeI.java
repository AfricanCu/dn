package com.wk.play;

import java.util.ArrayList;
import java.util.List;

import msg.RoomMessage.PlayType;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.mj.enun.HuPaiType;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

/**
 * 地方玩法接口
 * 
 * @author ems
 *
 */
public abstract class AreaPlayTypeI {
	/** 地方麻将名 */
	private final String name;
	/** ID */
	private final int type;
	/** 初始积分 **/
	private final int initCoin = 0;
	/** 一桌玩的人数 */
	private final int num = 4;
	/** 倍数设置 */
	private final List<TimesLimitType> timesLimitList;

	/**
	 * @param name
	 * @param type
	 * @param timesLimitList
	 * @param huPaiTypeTimesI
	 */
	public AreaPlayTypeI(String name, int type,
			List<TimesLimitType> timesLimitList) {
		this.name = name;
		this.type = type;
		this.timesLimitList = timesLimitList;
	}

	public String getName() {
		return name;
	}

	public int getType() {
		return type;
	}

	public int getInitCoin() {
		return initCoin;
	}

	public int getNum() {
		return num;
	}

	/** 一字撬是否有喜 */
	public boolean getYiZiQiaoYouXi(PlayType playType) {
		return this.isYiZiQiao() && playType.getYiZiQiao();
	}

	/** 飞鸟还是抓鸟 */
	public ZhaNiaoType getZhaNiaoType(PlayType playType) throws Exception {
		ZhaNiaoType zhaNiaoType = ZhaNiaoType.getEnum(playType.getZhaNiao());
		if (zhaNiaoType == null) {
			throw new Exception(String.format("NULL的扎鸟类型！%s",
					playType.getZhaNiao()));
		}
		return zhaNiaoType;
	}

	/** 几个鸟 */
	public SeveralNiaoType getSeveralNiaoType(PlayType playType)
			throws Exception {
		SeveralNiaoType severalNiaoType = SeveralNiaoType.getEnum(playType
				.getSeveralNiao());
		if (severalNiaoType == null) {
			throw new Exception(String.format("NULL的鸟个数！%s",
					playType.getSeveralNiao()));
		}
		return severalNiaoType;
	}

	/** 倍数限制 */
	public TimesLimitType getTimesLimitType(PlayType playType) throws Exception {
		if (timesLimitList == null || timesLimitList.isEmpty()) {
			return TimesLimitType._noLimitTimes;
		}
		TimesLimitType timesLimitType = TimesLimitType.getEnum(playType
				.getTimesLimit());
		if (timesLimitType == null) {
			throw new Exception(String.format("NULL的倍数限制！%s",
					playType.getSeveralNiao()));
		}
		if (!timesLimitList.contains(timesLimitType)) {
			throw new Exception(String.format("错误的倍数类型！%s", timesLimitType));
		}
		return timesLimitType;
	}

	/** 是否打门清 */
	public boolean isMengQing(PlayType playType) throws Exception {
		return playType.getMenQing();
	}

	/** 是否门清将将胡可接炮 */
	public boolean isMengQingJiangJiangJiePao(PlayType playType)
			throws Exception {
		return this.isMengQing(playType) && playType.getJiangJiangHu();
	}

	/** 庄家模式 **/
	public BankerMode getBankerMode(PlayType playType) throws Exception {
		BankerMode enm = BankerMode.getEnum(playType.getBankerMode());
		if (enm == null) {
			throw new Exception(String.format("NULL的庄家模式！%s",
					playType.getBankerMode()));
		}
		return enm;
	}

	/** 是否打地胡 */
	public boolean isDiHu(PlayType playType) throws Exception {
		checkBaoTingDihu(playType);
		return playType.getDiHu();
	}

	/** 是否打报听 */
	public boolean isBaoTing(PlayType playType) throws Exception {
		checkBaoTingDihu(playType);
		return playType.getBaoTing();
	}

	private void checkBaoTingDihu(PlayType playType) throws Exception {
		if (playType.getDiHu() && playType.getBaoTing()) {
			throw new Exception("不能同时选择报听和地胡！");
		}
	}

	/** 是否打一条龙（ 默认不打） */
	public boolean isYiTiaoLong() {
		return false;
	}

	/** 是否打一字撬（全球人）， 默认不打 */
	public boolean isYiZiQiao() {
		return false;
	}

	/** 是否打将将胡，默认不打 */
	public boolean isJiangJianghu() {
		return false;
	}

	/** 是否有风子 */
	public boolean isFeng() {
		return false;
	}

	/** 是否打十三烂 ，默认不打 **/
	public boolean isShiSanLan() {
		return false;
	}

	/** 是否打混一色 */
	public boolean isHunYiSe() {
		return false;
	}

	/** 平胡能否接炮 **/
	public boolean isPingHuJiePao() {
		return false;
	}

	/** 是否打飞宝大胡 */
	public boolean isFeiBao() {
		return false;
	}

	/** 是否打夹张大胡 */
	public boolean isJiaZhang() {
		return false;
	}

	/** 是否打癞子,默认不打 */
	public boolean isLai() {
		return false;
	}

	/** 能不能吃牌 ,默认不能吃 */
	public boolean isChi() {
		return false;
	}

	/***
	 * 总共多少张牌
	 * 
	 * @return
	 */
	public int getSumN() {
		if (isFeng()) {
			return 136;
		} else
			return 108;
	}

	/** 之前碰的牌明杠了算碰的人放杠自己接杠 */
	public boolean isMingGangSuanJieGang() {
		return false;
	}

	/** 是否刚抓的牌才能算明杠 默认否，留在手上也可以等下明杠 */
	public boolean isRightNowZhuaCanMingGang() {
		return false;
	}

	/**
	 * 胡牌的番数
	 * 
	 * @param huPaiType
	 *            胡牌类型
	 * @param playTypeSet
	 *            玩法设置
	 * @return
	 */
	public abstract int getTimes(HuPaiType huPaiType, PlayTypeSet playTypeSet);

	/**
	 * 计算胡牌番数
	 * 
	 * @param arrayList
	 * @return
	 */
	public abstract int calcFan(ArrayList<HuPaiType> arrayList,
			PlayTypeSet playTypeSet);

	/**
	 * 获取玩法描述
	 * 
	 * @param playType
	 * @return
	 */
	public abstract List<String> getPlayTypeDesc(PlayType playType);

	@Override
	public String toString() {
		return this.name;
	}

	/**
	 * 获取房间设置
	 * 
	 * @param playType
	 * @return
	 */
	public PlayTypeSet getPlayTypeSet(PlayType playType) {
		try {
			return new PlayTypeSet(playType, this);
		} catch (Exception e) {
			LoggerService.getPlatformLog().error(e.getMessage(), e);
			return null;
		}
	}

	/***
	 * 接炮是否奖励一个鸟
	 * 
	 * @return
	 */
	public boolean isJiePaoJiangNiao() {
		return false;
	}

	/** 同一轮中，第一次放炮没有接炮，第二次有人放炮如果胡牌番数一样，不能接炮！第一次番数<第二次番数才能接 **/
	public boolean isRoundDoubleHu() {
		return false;
	}

	/** 将将胡是否能接炮 默认不能 **/
	public boolean isJiangJiangHuJiePao() {
		return false;
	}

	/** 平胡报听能否接炮 **/
	public boolean isPinghuBaoTingJiePao() {
		return false;
	}

	/** 报听接炮过了，下一次同样的牌不能接炮 **/
	public boolean isBaoTingOverJiePaoNextNot() {
		return false;
	}

	/** 是否打海底胡 */
	public boolean isHaiDi() {
		return false;
	}

	/** 获取全球人的类型 **/
	public abstract HuPaiType getQuanQiuRenType();

}
