package com.wk.mj;

import msg.MjMessage.TargetMj;

import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.GpcType;

public class GpcCache {
	private GpcType type;
	/** 谁打的 **/
	private final int seetIndex;
	private final Pai pai;
	/** -1吃小边 0吃中间 1吃大边 */
	private final ChiType chi;

	public GpcCache(GpcType type, int seetIndex, Pai pai, ChiType chi) {
		super();
		this.type = type;
		this.seetIndex = seetIndex;
		this.pai = pai;
		this.chi = chi;
	}

	public GpcType getType() {
		return type;
	}

	public int getSeetIndex() {
		return seetIndex;
	}

	public Pai getPai() {
		return pai;
	}

	public ChiType getChi() {
		return chi;
	}

	public TargetMj genTargetMj() {
		TargetMj.Builder targetMj = TargetMj.newBuilder()
				.setType(type.getType()).setSeetIndex(seetIndex)
				.setMj(pai.getMj());
		if (this.chi != null) {
			targetMj.setChi(this.chi.getType());
		}
		return targetMj.build();
	}

	public void setType(GpcType type) {
		this.type = type;
	}

}