package com.jery.ngsp.server.worktask;

import java.util.concurrent.Future;

public abstract interface WorkTaskPoolManager {
	public abstract void start(String paramString, int paramInt1,
			int paramInt2, int paramInt3);

	public abstract Future<?> submitAndExecute(Runnable paramRunnable);

	public abstract SynchronousWorkTaskPool createSynchronousWorkTaskPool();
}

/*
 * Location: D:\Documents\workspace\GAME-SERVER-V1.0\libs\JERY-NGSP-V1.0.jar
 * Qualified Name: com.jery.ngsp.server.worktask.WorkTaskPoolManager JD-Core
 * Version: 0.6.0
 */