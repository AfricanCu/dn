package com.jery.ngsp.server.log;

public enum LogType {
	slf4j, log4j
}
