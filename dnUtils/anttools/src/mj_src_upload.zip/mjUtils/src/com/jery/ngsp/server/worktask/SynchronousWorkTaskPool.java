package com.jery.ngsp.server.worktask;

public abstract interface SynchronousWorkTaskPool {
	public abstract boolean isEmpty();

	public abstract boolean submit(Runnable paramRunnable);
}