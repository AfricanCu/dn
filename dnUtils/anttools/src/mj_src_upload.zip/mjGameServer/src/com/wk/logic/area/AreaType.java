package com.wk.logic.area;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import msg.RoomMessage.PlayType;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.play.AreaPlayTypeI;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;
import com.wk.server.logic.room.Room;
import com.wk.server.logic.room.RoomAbs;

/**
 * 麻将区域玩法类型
 * 
 * 
 * @author ems
 *
 */
public abstract class AreaType extends AreaPlayTypeI {

	private final static List<AreaType> areaList = new ArrayList<>();

	static {
		YUAN_JIANG.getInstance();
		YI_YANG.getInstance();
		YING_TANG_FEI_BAO.getInstance();
		YING_TANG_JIA_ZHANG.getInstance();
	}

	public static List<AreaType> values() {
		return areaList.subList(1, areaList.size());
	}

	public static AreaType getEnum(int type) {
		if (type < 1 || type >= areaList.size()) {
			return null;
		}
		return areaList.get(type);
	}

	/**
	 * @param name
	 * @param type
	 * @param timesLimitList
	 * @param huPaiTypeTimesI
	 */
	public AreaType(String name, int type, List<TimesLimitType> timesLimitList) {
		super(name, type, timesLimitList);
		for (int index = areaList.size(); index <= type; index++) {
			areaList.add(null);
		}
		areaList.set(type, this);
	}

	/** 创建房间 */
	public RoomAbs createRoom() {
		return new Room(this);
	}
}