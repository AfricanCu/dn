package com.wk.server.ibatis.select;

import java.sql.SQLException;
import java.util.Date;
import java.util.Map;
import java.util.Map.Entry;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import msg.GuildMessage.AddJulebuCast;
import msg.GuildMessage.DelJulebuCast;
import msg.GuildMessage.UpdateJulebuCast;
import msg.LoginMessage.GameRecord;
import msg.LoginMessage.Julebu;
import msg.LoginMessage.LoginSm;
import msg.LoginMessage.PlayerCast;
import msg.LoginMessage.PlayerRecordCast;

import org.json.JSONObject;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.SystemConstantsAbs;
import com.wk.engine.config.ServerConfig;
import com.wk.engine.event.EventType;
import com.wk.engine.net.I.CsConnectI;
import com.wk.enun.UserState;
import com.wk.guild.bean.GuildBean;
import com.wk.logic.config.TimeConfig;
import com.wk.logic.enm.MsgId;
import com.wk.server.logic.guild.enm.RemoveJoinJulebuType;
import com.wk.server.logic.item.ItemTemplate;
import com.wk.server.logic.login.LoginModule;
import com.wk.server.logic.login.UserManager;
import com.wk.server.logic.room.RoomAbs;
import com.wk.server.logic.room.Seat;
import com.wk.user.bean.UserBean;

/**
 * 玩家收益
 * 
 * @author ems
 */
public abstract class IncomeUserI extends UserBean implements CsConnectI<MsgId> {
	/** 读写锁 */
	private final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
	// tmp
	/** 个人信息消息Builder */
	private PlayerCast.Builder playerCast = null;
	/** 游戏记录推送消息Builder */
	private PlayerRecordCast.Builder gameRecordCast = null;
	/** 是否需要发送玩家信息更新 */
	private boolean isNeedSendPlayerSm = false;
	/** 玩家当前所在房间 */
	private RoomAbs room = null;
	/** 心跳从什么时候挂起 */
	private long heartPause = 0;
	/** 缓存游戏结束消息 */
	private byte[] gameOverCast;

	public IncomeUserI() {
		super(LoginModule.getInstance());
	}

	public void reset() {
		super.reset();
		this.playerCast = null;
		this.gameRecordCast = null;
		this.isNeedSendPlayerSm = false;
		this.room = null;
		this.heartPause = 0;
		this.gameOverCast = null;
	}

	/**
	 * 加入多组道具
	 * 
	 * @param items
	 * @param isCheck
	 *            是否检测发送
	 */
	public void addItems(Map<ItemTemplate, Integer> items, boolean isCheck,
			String log) {
		rwLock.writeLock().lock();
		try {
			for (Entry<ItemTemplate, Integer> entry : items.entrySet()) {
				addItem(entry.getKey(), entry.getValue(), false, false, log);
			}
		} finally {
			rwLock.writeLock().unlock();
		}
		if (isCheck) {
			this.checkSendPlayer();
		}
	}

	/**
	 * 加入道具
	 * 
	 * @param itemId
	 * @param itemNum
	 * @param isCheck
	 *            是否检测发送
	 */
	public void addItem(ItemTemplate itemId, int itemNum, boolean isCheck,
			String log) {
		this.addItem(itemId, itemNum, isCheck, true, log);
	}

	/**
	 * 加入道具
	 * 
	 * @param itemId
	 * @param itemNum
	 * @param isCheck
	 *            是否检测发送
	 * @param isWriteLock
	 *            是否写锁
	 */
	private void addItem(ItemTemplate itemId, int itemNum, boolean isCheck,
			boolean isWriteLock, String log) {
		if (itemNum == 0) {
			return;
		}
		if (isWriteLock)
			rwLock.writeLock().lock();
		try {
			switch (itemId) {
			case Diamond_ID:
				this.changeDiamond(itemNum);
				break;
			default:
				break;
			}
		} finally {
			if (isWriteLock)
				rwLock.writeLock().unlock();
		}
		LoggerService.getItemlogs().warn(
				"uid:{},nickname:{},itemId:{},itemNum:{},log:{}",
				new Object[] { this.uid, this.nickname, itemId, itemNum, log });
		if (isCheck) {
			this.checkSendPlayer();
		}
	}

	/**
	 * 玩家处理事件
	 * 
	 * @param eventType
	 * @param params
	 */
	public void handleEvent(EventType eventType, Object... params) {
	}

	@Override
	public byte[] getGameRecord() {
		return this.getGameRecordCast().build().toByteArray();
	}

	public PlayerRecordCast.Builder getGameRecordCast() {
		if (gameRecordCast == null) {
			try {
				gameRecordCast = PlayerRecordCast.newBuilder().mergeFrom(
						this.gameRecord);
			} catch (InvalidProtocolBufferException e) {
				LoggerService.getPlatformLog().error(e.getMessage(), e);
			}
		}
		return gameRecordCast;
	}

	public PlayerCast.Builder getPlayerCast() {
		if (playerCast == null) {
			playerCast = PlayerCast.newBuilder().setDiamond(this.diamond);
		}
		return playerCast;
	}

	/**
	 * 记录游戏结果
	 * 
	 * @param record
	 * @param checkId
	 */
	public void recordGame(GameRecord record) {
		if (this.getGameRecordCast().getRecordCount() >= TimeConfig
				.getGameRecordMax()) {
			this.getGameRecordCast().removeRecord(0);
		}
		this.getGameRecordCast().addRecord(record);
		super.updateGameRecord();
		this.sendPlayerRecordCast();
	}

	/**
	 * 发送玩家数据
	 * 
	 * @return
	 */
	public IncomeUserI sendPlayer() {
		this.sendMessage(MsgId.PlayerCast, getPlayerCast());
		return this;
	}

	/**
	 * 检测是否必要发送玩家数据
	 * 
	 * @return
	 */
	public IncomeUserI checkSendPlayer() {
		if (this.isNeedSendPlayerSm) {
			this.sendPlayer();
			this.isNeedSendPlayerSm = false;
		}
		return this;
	}

	/**
	 * 发送玩家记录数据
	 * 
	 * @return
	 */
	public IncomeUserI sendPlayerRecordCast() {
		this.sendMessage(MsgId.PlayerRecordCast, this.getGameRecord());
		return this;
	}

	/**
	 * 当前所在房间
	 * 
	 * @return
	 */
	public RoomAbs getRoom() {
		return room;
	}

	public void setRoom(RoomAbs room) {
		this.room = room;
		if (this.room == null) {
			this.setRoomId(SystemConstantsAbs.NoRoomId);
			LoginModule.getInstance().decrementRoomUser();
			if (!this.isOnline()) {
				if (!this.cannotChangeServerId()) {
					UserManager.getInstance().removeUser(this.getUid());
				}
				String format = String.format(
						"%s,退出房间了，但玩家已经离线了！uid:%s,nick%s",
						new Exception().getStackTrace()[0], this.uid,
						this.nickname);
				System.err.println(format);
				LoggerService.getRoomlogs().error(format);
			}
		} else {
			this.setRoomId(this.room.getId());
			LoginModule.getInstance().incrementRoomUser();
		}
		try {
			this.save();
		} catch (SQLException e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
		}
	}

	@Override
	public void setDiamond(int diamond) {
		super.setDiamond(diamond);
		this.getPlayerCast().setDiamond(diamond);
		setNeedSendPlayerSm();
	}

	public void setNeedSendPlayerSm() {
		if (this.isNeedSendPlayerSm) {
			return;
		}
		this.isNeedSendPlayerSm = true;
	}

	@Override
	public boolean isOnline() {
		return super.isOnline() && this.getState() == UserState.online;
	}

	public void setState(UserState state) {
		super.setState(state);
		if (state == UserState.offline) {
			if (room != null) {
				Seat seat = room.getSeat(this);
				if (seat == null) {
					String format = String.format("%s,严重bug！",
							new Exception().getStackTrace()[0]);
					LoggerService.getLogicLog().error(format);
				}
				seat.setUserState(UserState.offline);
			}
			this.setLogoutTime(new Date(System.currentTimeMillis() - 1000));
		} else if (state == UserState.online) {
			this.setLoginTime(new Date());
		}
	}

	public void setHeartPause(long heartPause) {
		this.heartPause = heartPause;
	}

	public long getHeartPause() {
		return heartPause;
	}

	public void sendMessage(MsgId msgId, MessageLite.Builder builder) {
		this.sendMessage(msgId, builder.build().toByteArray());
	}

	public void sendMessage(MsgId msgId, MessageLite messageLite) {
		this.sendMessage(msgId, messageLite.toByteArray());
	}

	public void assembleJulebuMsg(LoginSm.Builder loginSm) {
		for (Entry<Integer, JSONObject> entry : this.myGuild.entrySet()) {
			loginSm.addMy(assembleJulebu(entry.getKey(), entry.getValue()));
		}
		for (Entry<Integer, JSONObject> entry : this.joinGuild.entrySet()) {
			loginSm.addJoin(assembleJulebu(entry.getKey(), entry.getValue()));
		}
	}

	public Julebu assembleJulebu(Integer key, JSONObject value) {
		return Julebu
				.newBuilder()
				.setId(key)
				.setName(value.optString(julebuName_index))
				.setHeadimg(
						ServerConfig.getHeadUrl(value
								.optLong(julebuMasterUid_index)))
				.setMasterUid(value.optLong(julebuMasterUid_index))
				.setMasterName(value.optString(julebuMasterName_index))
				.setState(value.optInt(julebuState_index))
				.setPlayType(value.optString(julebuPlayType_index)).build();
	}

	@Override
	public JSONObject createMyJulebu(GuildBean guild) {
		JSONObject createMyJulebu = super.createMyJulebu(guild);
		if (createMyJulebu == null) {
			return createMyJulebu;
		}
		this.sendMessage(
				MsgId.AddJulebuCast,
				AddJulebuCast.newBuilder()
						.setMy(assembleJulebu(guild.getId(), createMyJulebu))
						.setType(2));
		return createMyJulebu;
	}

	@Override
	public JSONObject removeMyJulebu(int guildId) {
		JSONObject removeMyJulebu = super.removeMyJulebu(guildId);
		if (removeMyJulebu == null) {
			return removeMyJulebu;
		}
		this.sendMessage(
				MsgId.DelJulebuCast,
				DelJulebuCast.newBuilder().setId(guildId)
						.setType(RemoveJoinJulebuType.dissolve.getType()));
		return removeMyJulebu;
	}

	@Override
	public JSONObject applyJulebu(GuildBean guild) {
		JSONObject applyJulebu = super.applyJulebu(guild);
		if (applyJulebu == null) {
			return applyJulebu;
		}
		this.sendMessage(
				MsgId.AddJulebuCast,
				AddJulebuCast.newBuilder()
						.setMy(assembleJulebu(guild.getId(), applyJulebu))
						.setType(1));
		return applyJulebu;
	}

	public JSONObject removeJoinJulebu(int guildId, RemoveJoinJulebuType type) {
		JSONObject removeJoinJulebu = super.removeJoinJulebu(guildId);
		if (removeJoinJulebu == null) {
			return removeJoinJulebu;
		}
		this.sendMessage(
				MsgId.DelJulebuCast,
				DelJulebuCast.newBuilder().setId(guildId)
						.setType(type.getType()));
		return removeJoinJulebu;
	}

	@Override
	public JSONObject joinJulebu(int guildId) {
		JSONObject joinJulebu = super.joinJulebu(guildId);
		if (joinJulebu == null) {
			return joinJulebu;
		}
		this.sendMessage(MsgId.UpdateJulebuCast, UpdateJulebuCast.newBuilder()
				.setMy(assembleJulebu(guildId, joinJulebu)).setType(1));
		return joinJulebu;
	}

	@Override
	public JSONObject updateJulebuInfo(int guildId, String name,
			String playTypeDesc) {
		JSONObject updateJulebuInfo = super.updateJulebuInfo(guildId, name,
				playTypeDesc);
		if (updateJulebuInfo == null) {
			return updateJulebuInfo;
		}
		this.sendMessage(MsgId.UpdateJulebuCast, UpdateJulebuCast.newBuilder()
				.setMy(assembleJulebu(guildId, updateJulebuInfo)).setType(2));
		return updateJulebuInfo;
	}

	@Override
	public int getCreateGuildServerId() {
		int createGuildServerId = super.getCreateGuildServerId();
		return createGuildServerId == SystemConstantsAbs.NoServerId ? ServerConfig.serverId
				: createGuildServerId;
	}

	public abstract String getIp();

	@Override
	public String toString() {
		return String.format("uid:%s,nick:%s,roomId:%s,room:%s", this.getUid(),
				this.getNickname(), this.getRoomId(),
				this.getRoom() == null ? "" : this.getRoom().toString());
	}

	public void cacheGameOverCast(byte[] bytes) {
		this.gameOverCast = bytes;
	}

	public boolean sendCacheGameOverCast() {
		if (this.gameOverCast != null) {
			this.sendMessage(MsgId.GameOverCast, this.gameOverCast);
			this.gameOverCast = null;
			return true;
		}
		return false;
	}
}
