package com.wk.server.logic.room;

import io.netty.buffer.ByteBuf;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.atomic.AtomicReference;

import msg.BackMessage.InitPai;
import msg.MjMessage.Mj;
import msg.MjMessage.MyRoundInfo;
import msg.MjMessage.SeetResult;
import msg.MjMessage.UserRoundInfo;
import msg.RoomMessage.NsCm;
import msg.RoomMessage.OfflineCast;
import msg.RoomMessage.UserInfo;

import com.wk.I.ByteBufferSerializable;
import com.wk.bean.SystemConstantsAbs;
import com.wk.engine.config.ServerConfig;
import com.wk.enun.UserState;
import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MemberDisType;
import com.wk.logic.enm.MsgId;
import com.wk.mj.GpcCache;
import com.wk.mj.ListMjAbs;
import com.wk.mj.MjTools;
import com.wk.mj.Pai;
import com.wk.mj.TingPaiCondiTionI;
import com.wk.mj.enun.AfterOtherDaPaiType;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.GetHuPaiType;
import com.wk.play.PlayTypeSet;
import com.wk.server.ibatis.select.IncomeUserI;
import com.wk.server.logic.item.ItemTemplate;

/**
 * 座位
 * 
 * @author ems
 *
 */
public class Seat extends ListMjAbs implements ByteBufferSerializable,
		TingPaiCondiTionI {
	/** 有一张宝牌在手上迟迟没打罚分 */
	private static final int LATE_BAO_FA_FEN = 5;
	/** 放杠番数 */
	private static final int FANG_GANG_FAN = 2;
	/** 暗杠番数 */
	private static final int AN_GANG_FAN = 2;
	/** 一字撬番数 */
	private static final int YI_ZI_QIAO_FAN = 2;
	/** 明杠番数 */
	private static final int MING_GANG_FAN = 1;
	/** 4个宝奖励分 **/
	private static final int BAO4_FEN = 10;
	/****/
	private static final NsCm NSCM = NsCm.newBuilder().build();
	/** 房间 */
	private transient final RoomAbs room;
	/** 数组下标 **/
	private final int index;
	/** 所属玩家 */
	private transient IncomeUserI user;
	/** 状态 */
	private final AtomicReference<GameState> gstate = new AtomicReference<>();
	/** 语音房间座位号 */
	private int imSeatIndex;
	/** 地理信息 **/
	private NsCm ns;
	/** 积分 */
	private int coin;
	/** 玩家状态 **/
	private UserState userState;
	/** 同意解散房间 0无 1同意 2不同意 3等待 **/
	private MemberDisType memberDisType;
	/** 消耗钻石数 **/
	private int consumeDiamond;
	// /////////////每局缓存/////////////////////
	/** 中鸟个数 */
	private int niaoNumber;
	/** 当前局积分变化 */
	private int roundRs;
	/** 其他人打牌后自己的操作 */
	private AfterOtherDaPaiType afterOtherDaPaiType;
	/** 局信息 */
	private transient final MyRoundInfo.Builder myRoundInfo = MyRoundInfo
			.newBuilder();

	@Override
	public void writeExternal(ByteBuf out) throws Exception {
		out.writeInt(this.coin);
		out.writeInt(this.consumeDiamond);
	}

	@Override
	public void readExternal(ByteBuf in) throws Exception {
		this.coin = in.readInt();
		this.consumeDiamond = in.readInt();
	}

	public Seat(RoomAbs room, int id, int index) {
		super(id);
		this.room = room;
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

	public void init(PlayTypeSet playTypeSet) {
		super.init(playTypeSet);
		this.user = null;
		this.gstate.set(GameState.noStart);
		this.imSeatIndex = 0;
		this.ns = null;
		this.coin = this.room.getAreaType().getInitCoin();
		this.userState = UserState.online;
		this.memberDisType = MemberDisType.empty;
	}

	/**
	 * 重新一局
	 */
	public void nextRound() {
		super.nextRound();
		this.niaoNumber = 0;
		this.roundRs = 0;
		this.afterOtherDaPaiType = null;
		this.myRoundInfo.clear();
	}

	public IncomeUserI getUser() {
		return this.user;
	}

	public long getUserUid() {
		return this.user == null ? SystemConstantsAbs.NoUid : this.user
				.getUid();
	}

	public String getUserNickname() {
		return this.user == null ? null : this.user.getNickname();
	}

	public String getUserIp() {
		return this.user == null ? null : this.user.getIp();
	}

	public void addItem(ItemTemplate itemId, int itemNum, boolean isCheck,
			String log) {
		if (this.user == null) {
			return;
		}
		this.user.addItem(itemId, itemNum, isCheck, log);
		if (itemId == ItemTemplate.Diamond_ID && itemNum < 0) {
			this.consumeDiamond += (-itemNum);
		}
	}

	public void setUser(IncomeUserI user) {
		synchronized (this) {
			if (this.user != null) {
				this.user.setRoom(null);
			}
			this.user = user;
			if (this.user != null) {
				this.user.setRoom(this.room);
				this.userState = this.user.getState();
			} else {
				this.userState = UserState.online;
			}
		}
	}

	public void setUserInfo(UserInfo.Builder userInfo) {
		if (this.user == null) {
			return;
		}
		userInfo.setUid(this.user.getUid()).setSeetIndex(this.getId())
				.setGstate(this.gstate.get().getType())
				.setUserState(this.getUserState().getType())
				.setImSeatIndex(imSeatIndex).setIsMaster(isMaster())
				.setHeadimg(ServerConfig.getHeadUrl(this.user.getUid()))
				.setNickname(this.user.getNickname()).setCoin(this.coin)
				.setSex(this.user.getSex()).setNs(ns == null ? NSCM : ns)
				.setIp(this.user.getIp());
	}

	public void setInitPai(InitPai.Builder initPai) {
		initPai.setUid(this.user.getUid());
		initPai.setSeetIndex(this.getId());
		initPai.setIsMaster(this.isMaster());
		initPai.setHeadimg(ServerConfig.getHeadUrl(this.user.getUid()));
		initPai.setNickname(this.user.getNickname());
		initPai.setCoin(this.coin);
		initPai.setSex(this.user.getSex());
		initPai.clearPais();
		for (Pai pai : this.getZiList()) {
			int paiCount = this.getPaiCount(pai);
			while (paiCount != 0 && paiCount-- > 0) {
				initPai.addPais(pai.getMj());
			}
		}
	}

	public boolean isMaster() {
		return this.user != null && this.user.getUid() == room.getMasterId();
	}

	public boolean isPrepared() {
		return gstate.get() == GameState.prepared;
	}

	public GameState getGstate() {
		return gstate.get();
	}

	public void setGstate(GameState gameState) {
		this.gstate.set(gameState);
	}

	public boolean setQiangGangGuo() {
		return this.gstate.compareAndSet(GameState.qiangGangGuo,
				GameState.waitOtherOperation);
	}

	/**
	 * 别人打牌后可吃碰杠过，，自己的操作缓存
	 * 
	 * @param afterOtherDaPaiType
	 * @return
	 */
	public boolean setAfterOtherDaPaiType(
			AfterOtherDaPaiType afterOtherDaPaiType) {
		if (this.gstate.compareAndSet(GameState.jiePaoJieGangPengChiGuo,
				GameState.waitOtherOperation)) {
			this.afterOtherDaPaiType = afterOtherDaPaiType;
			return true;
		}
		return false;
	}

	public AfterOtherDaPaiType getAfterOtherDaPaiType() {
		return afterOtherDaPaiType;
	}

	public void sendMessage(MsgId msgId, byte[] messageLiteOrBuilder) {
		if (this.getUser() != null && this.userState == UserState.online) {
			this.getUser().sendMessage(msgId, messageLiteOrBuilder);
		}
	}

	public void setImSeatIndex(int index) {
		this.imSeatIndex = index;
	}

	public void setUserState(UserState userState) {
		this.userState = userState;
		OfflineCast.Builder offlineCast = OfflineCast.newBuilder()
				.setIsOk(this.getUserState().getType())
				.setSeetIndex(this.getId());
		room.broadCast(MsgId.OfflineCast, offlineCast.build().toByteArray(),
				this);
		if (this.userState == UserState.offline) {
			this.room.checkAllOffLine();
		}
	}

	public UserState getUserState() {
		return userState;
	}

	/** 改变积分 */
	public void addCoin(int c) {
		if (c != 0) {
			this.coin += c;
		}
	}

	public int getMinusCoin() {
		return this.coin - this.room.getAreaType().getInitCoin();
	}

	public int getCoin() {
		return this.coin;
	}

	public MemberDisType getMemberDisType() {
		return memberDisType;
	}

	public void setMemberDisType(MemberDisType memberDisType) {
		this.memberDisType = memberDisType;
	}

	public void genGameOverCast(SeetResult.Builder addRsBuilder) {
		addRsBuilder.setSeetIndex(this.getId());
		addRsBuilder.setCoin(this.getCoin());
		addRsBuilder.setZiMo(this.getZiMoTimes());
		addRsBuilder.setJiePao(this.getJiePaoTimes());
		addRsBuilder.setAnGang(this.getAnGangTimes());
		addRsBuilder.setMingGang(this.getMingGangTimes());
		addRsBuilder.setJieGang(this.getJieGangTimes());
		addRsBuilder.setFangPao(this.getFangPaoTimes());
		addRsBuilder.setFangGang(this.getFangGangTimes());
	}

	/**
	 * 玩家局信息
	 * 
	 * @param addUsersRoundBuilder
	 */
	public void setUserRoundInfo(UserRoundInfo.Builder addUsersRoundBuilder) {
		addUsersRoundBuilder.setSeetIndex(this.getId());
		addUsersRoundBuilder.setBaoTing(this.isBaoTing());
		if (this.isMeHaveDaPai()) {
			int len = this.getHaveDaPaiList().size() - 1;
			for (int index = 0; index < len; index++) {
				Pai pai = this.getHaveDaPaiList().get(index);
				addUsersRoundBuilder.addMj(pai.getMj());
			}
		} else {
			for (Pai pai : this.getHaveDaPaiList()) {
				addUsersRoundBuilder.addMj(pai.getMj());
			}
		}
		if (this.isMeHavePeng() || this.isMeHaveChi()) {
			int len = this.getGpcList().size() - 1;
			for (int index = 0; index < len; index++) {
				GpcCache gpc = this.getGpcList().get(index);
				addUsersRoundBuilder.addGpc(gpc.genTargetMj());
			}
		} else {
			for (GpcCache gpc : this.getGpcList()) {
				addUsersRoundBuilder.addGpc(gpc.genTargetMj());
			}
		}
		if (isMeHaveZhuaBu()) {
			addUsersRoundBuilder.setNum(calcListNum() - 1);
		} else if (isMeHaveDaPai()) {
			addUsersRoundBuilder.setNum(calcListNum() + 1);
		} else if (isMeHavePeng() || isMeHaveChi()) {
			addUsersRoundBuilder.setNum(calcListNum() + 2);
		} else {
			addUsersRoundBuilder.setNum(calcListNum());
		}
	}

	public void addNiaoNumber(int niao) {
		this.niaoNumber += niao;
	}

	/**
	 * 飞中鸟个数
	 * 
	 * @return
	 */
	public int getNiaoNumber() {
		return niaoNumber;
	}

	public int getRoundRs() {
		return this.roundRs;
	}

	/**
	 * 下一个位置
	 * 
	 * @return
	 */
	public Seat nextOne() {
		int ind = this.getIndex() + 1;
		return this.room.getSeats()[ind == this.room.getSeats().length ? 0
				: ind];
	}

	/**
	 * 自己是抓牌阶段，把抓的这个牌移除，剩余牌数加1
	 * 
	 * 自己是补牌阶段，把补的这个牌移除，剩余牌数加1，补牌数减1
	 * 
	 * 自己是打牌阶段，把打的这个牌加入，
	 * 
	 * 自己是碰牌阶段，把碰的牌加入，
	 * 
	 * @return
	 */
	public MyRoundInfo getMyRoundInfo() {
		myRoundInfo.clear();
		boolean zhuaBu = isMeHaveZhuaBu();
		for (int i = 0; i < this.getZiList().size(); i++) {
			Pai pai = this.getZiList().get(i);
			if (pai != Pai.emptyMj) {
				int count = this.getCount(i);
				while (count-- > 0) {
					if (zhuaBu && pai == this.getZhuaPai()) {
						zhuaBu = false;
					} else
						myRoundInfo.addPais(pai.getMj());
				}
			}
		}
		if (isMeHaveDaPai()) {
			myRoundInfo.addPais(this.room.getHaveDaPai().getMj());
		}
		if (isMeHavePeng()) {
			Mj mj = this.room.pengPaiCast.getMj();
			myRoundInfo.addPais(mj).addPais(mj);
		}
		if (isMeHaveChi()) {
			Mj mj = this.room.chiPaiCast.getMj();
			ChiType chiType = ChiType.getEnum(this.room.chiPaiCast.getChi());
			Pai[] pais = ChiType.getPais(chiType, Pai.getPai(mj));
			myRoundInfo.addPais(pais[0].getMj()).addPais(pais[1].getMj());
		}
		myRoundInfo.addAllShaizi(this.room.getShaizi());
		myRoundInfo.setBaoTing(this.getGstate() == GameState.baoTing
				&& this.isCanBaoTing());
		myRoundInfo.setHasBaoTing(this.room.isHasBaoTing());
		if (room.getRoomState() == RoomStateCache.zhuaPaiCast) {//
			myRoundInfo.setLeftPaiNum(this.room.getLeftPaiNum() + 1);
			if (this.room.zhuaPaiCast.getBu()) {
				myRoundInfo.setBuPaiNum(room.getBuPaiNum() - 1);
			} else {
				myRoundInfo.setBuPaiNum(room.getBuPaiNum());
			}
		} else {
			myRoundInfo.setLeftPaiNum(this.room.getLeftPaiNum());
			myRoundInfo.setBuPaiNum(room.getBuPaiNum());
		}
		return myRoundInfo.build();
	}

	/** 我刚打了牌 */
	boolean isMeHaveDaPai() {
		return this.room.getRoomState() == RoomStateCache.daPaiCast
				&& this.room.getHaveDaPaiSeat() == this;
	}

	/** 我刚抓了牌 */
	boolean isMeHaveZhuaBu() {
		return room.getRoomState() == RoomStateCache.zhuaPaiCast
				&& (this.getGstate() == GameState.ziMoAnGangMingGangGuo || this
						.getGstate() == GameState.daPai);
	}

	/** 我刚碰牌 */
	boolean isMeHavePeng() {
		return room.getRoomState() == RoomStateCache.pengPaiCast
				&& (this.getGstate() == GameState.ziMoAnGangMingGangGuo || this
						.getGstate() == GameState.daPai);
	}

	/** 我刚吃了牌 */
	boolean isMeHaveChi() {
		return room.getRoomState() == RoomStateCache.chiPaiCast
				&& (this.getGstate() == GameState.ziMoAnGangMingGangGuo || this
						.getGstate() == GameState.daPai);
	}

	public boolean isBanker() {
		return this.room.isBanker(this);
	}

	@Override
	public String toString() {
		return String.format("状态：%s,位置：%s", this.gstate.get(), this.getId());
	}

	@Override
	public boolean isCanDiHu() {
		return this.room.getPlayTypeSet().isDiHu()
				&& this.room.getHaveDaPaiSeat().getHaveDaPaiList().size() == 1
				&& this.room.getHaveDaPaiSeat().isBanker();
	}

	@Override
	public boolean isLai(Pai pai) {
		return this.room.isLai(pai);
	}

	@Override
	public boolean isBao(Pai pai) {
		return this.room.isBao(pai);
	}

	/**
	 * 计算积分
	 */
	public void calcRs(Seat pengBao4Seat, Seat zhuaBao4Seat) {
		GetHuPaiType getHuPaiType2 = this.room.getGetHuPaiType();
		int ziMoHuPaiSeatNiaoNumber = this.room.getZiMoHuPaiSeatNiaoNumber();
		if (this.room.isHuPai(this)) {
			int huPaiSeatFan = this.getHuPaiFan();
			if (getHuPaiType2 == GetHuPaiType.ziMo) {
				this.roundRs += huPaiSeatFan * (1 + ziMoHuPaiSeatNiaoNumber)
						* 3;
				for (Seat st : this.room.getSeats()) {
					if (st != this && st.getNiaoNumber() > 0) {
						this.roundRs += huPaiSeatFan * st.getNiaoNumber();
					}
				}
			} else {
				if (this.getPlayTypeSet().isJiePaoJiangNiao()) {
					this.roundRs += huPaiSeatFan * (1 + 1);
				} else {
					this.roundRs += huPaiSeatFan;
				}
			}
		} else {
			int huPaiSeatFan = this.room.getHuPaiSeatFan();
			if (getHuPaiType2 == GetHuPaiType.ziMo) {
				this.roundRs -= huPaiSeatFan * (1 + ziMoHuPaiSeatNiaoNumber);
				if (this.getNiaoNumber() > 0) {
					this.roundRs -= huPaiSeatFan * this.getNiaoNumber();
				}
			} else {
				if (this.getFangPaoNumber() > 0
						|| this.getFangQiangGangNumber() > 0) {
					if (this.getPlayTypeSet().isJiePaoJiangNiao()) {
						this.roundRs -= huPaiSeatFan * (1 + 1);
					} else {
						this.roundRs -= huPaiSeatFan;
					}
				}
			}
		}
		if (this.isCanYiZiQiaoYouXi()) {
			this.roundRs += YI_ZI_QIAO_FAN * 3;
		}
		if (this.getYiZiQiaoNumber() > 0) {
			this.roundRs -= YI_ZI_QIAO_FAN * this.getYiZiQiaoNumber();
		}
		if (this.isNeedBaoFaFen()) {
			this.roundRs -= LATE_BAO_FA_FEN * 3;
		}
		if (this.getBaoFaFenNumber() > 0) {
			this.roundRs += LATE_BAO_FA_FEN * this.getBaoFaFenNumber();
		}
		if (pengBao4Seat != null) {
			if (this == pengBao4Seat)
				this.roundRs += BAO4_FEN;
			else if (pengBao4Seat.isPengBao4().getSeetIndex() == this.getId())
				this.roundRs -= BAO4_FEN;
		} else if (zhuaBao4Seat != null) {
			if (this == zhuaBao4Seat)
				this.roundRs += BAO4_FEN * 3;
			else
				this.roundRs -= BAO4_FEN;
		}
		int anGangBeen2 = this.getAnGangBeen();
		int mingGangBeen2 = this.getMingGangBeen();
		int fangGangNumber = this.getFangGangNumber();
		int anGangNumber = this.getAnGangNumber();
		int mingGangNumber = this.getMingGangNumber();
		int jieGangNumber = this.getJieGangNumber();
		if (anGangBeen2 > 0) {
			this.roundRs -= AN_GANG_FAN * anGangBeen2;
		}
		if (mingGangBeen2 > 0) {
			this.roundRs -= MING_GANG_FAN * mingGangBeen2;
		}
		if (fangGangNumber > 0) {
			this.roundRs -= FANG_GANG_FAN * fangGangNumber;
		}
		if (anGangNumber > 0) {
			this.roundRs += AN_GANG_FAN * anGangNumber * 3;
		}
		if (mingGangNumber > 0) {
			this.roundRs += MING_GANG_FAN * mingGangNumber * 3;
		}
		if (jieGangNumber > 0) {
			this.roundRs += FANG_GANG_FAN * jieGangNumber;
		}
		this.coin += this.roundRs;
	}

	/**
	 * 游戏没开始
	 * 
	 * @return
	 */
	public boolean gameNotBegin() {
		return this.gstate.get() == GameState.noStart
				|| this.gstate.get() == GameState.prepared;
	}

	public void seatReconnect() {
		switch (this.getGstate()) {
		case noStart:
			break;
		case prepared:
			break;
		case waitOtherOperation:
			break;
		case baoTing:
			break;
		case ziMoAnGangMingGangGuo:
			break;
		case daPai:
			break;
		case jiePaoJieGangPengChiGuo:
			break;
		case qiangGangGuo:
			break;
		default:
			break;
		}
	}

	public Seat getNextSeat() {
		int nextIndex = this.getIndex() + 1;
		if (nextIndex == this.room.getSeats().length) {
			return this.room.getSeats()[0];
		}
		return this.room.getSeats()[nextIndex];
	}

	public Seat getPrevSeat() {
		int prevIndex = this.getIndex() - 1;
		if (prevIndex < 0) {
			return this.room.getSeats()[this.room.getSeats().length - 1];
		}
		return this.room.getSeats()[prevIndex];
	}

	public void setNs(NsCm ns) {
		this.ns = ns;

	}

	public void cacheMsg(byte[] bytes) {
		if (this.getUser() != null && this.userState == UserState.online) {
			this.getUser().cacheGameOverCast(bytes);
		}
	}

	/***
	 * 打的这个牌可以怎么吃
	 * 
	 * @param haveDaPai
	 *            打的这个牌
	 * @return
	 */
	public List<Integer> getChiList(Pai haveDaPai) {
		List<Integer> chiList = new ArrayList<>();
		if (room.isChi() && !this.isBao(haveDaPai)
				&& room.getHaveDaPaiSeat().getNextSeat() == this) {
			for (ChiType type : ChiType.values())
				if (this.isCanChi(type, haveDaPai) != null)
					chiList.add(type.getType());
		}
		return chiList;
	}
}