package com.wk.server.logic.room;

import io.netty.channel.Channel;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;
import java.util.concurrent.ConcurrentHashMap;

import msg.BackMessage.BattleBackCm;
import msg.MjMessage.AnGangPaiCm;
import msg.MjMessage.BaoTingCm;
import msg.MjMessage.ChiPaiCm;
import msg.MjMessage.DaPaiCm;
import msg.MjMessage.MingGangPaiCm;
import msg.MjMessage.ReconnectCm;
import msg.RoomMessage.ChatCm;
import msg.RoomMessage.CreateRoomBeforeCm;
import msg.RoomMessage.CreateRoomCm;
import msg.RoomMessage.DissolveRoomCm;
import msg.RoomMessage.ImCm;
import msg.RoomMessage.JoinRoomBeforeCm;
import msg.RoomMessage.JoinRoomCm;
import msg.RoomMessage.LeaveRoomCm;
import msg.RoomMessage.MemberDissolveRoomCm;
import msg.RoomMessage.NsCm;
import msg.RoomMessage.PrepareRoomCm;
import msg.RoomMessage.ProxyCreateRoomBeforeCm;
import msg.RoomMessage.ProxyCreateRoomCm;
import msg.RoomMessage.ProxyRoomsDissovleCm;

import com.google.protobuf.MessageLite;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.db.IbatisDbServer;
import com.wk.db.dao.BattlebackDao;
import com.wk.db.dao.RoomDao;
import com.wk.engine.ModuleAbs;
import com.wk.engine.config.ServerConfig;
import com.wk.engine.event.EventAbs;
import com.wk.engine.event.EventType;
import com.wk.engine.net.IoMessage;
import com.wk.logic.area.AreaType;
import com.wk.logic.config.DissolveRoomType;
import com.wk.logic.config.NTxt;
import com.wk.logic.config.TimeConfig;
import com.wk.logic.enm.MsgId;
import com.wk.server.ibatis.select.IncomeUserI;
import com.wk.server.ibatis.select.User;

public class RoomModule extends ModuleAbs<Integer, RoomAbs> {

	private static final long serialVersionUID = 1L;

	private static RoomModule instance;

	public static RoomModule getInstance() {
		return instance;
	}

	/**
	 * <房间id,房间>
	 */
	private final ConcurrentHashMap<Integer, RoomAbs> roomMap = new ConcurrentHashMap<>();

	/**
	 * 缓存的房间对象 <区域玩法,stack>
	 */
	private final HashMap<AreaType, Stack<RoomAbs>> areaCacheRoomMap = new HashMap<>();

	private final EventAbs user_LogIn = new EventAbs(EventType.User_LogIn) {
		@Override
		public void eventNotify(User user, Object... params) {
		}
	};

	private final EventAbs User_LogOut = new EventAbs(EventType.User_LogOut) {
		@Override
		public void eventNotify(User user, Object... params) {
		}
	};

	private EventAbs shutDown = new EventAbs(EventType.ShutDown) {
		@Override
		public void eventNotify(User user, Object... params) {
			if (!TimeConfig.isShutDownDissolveRoom()) {
				return;
			}
			try {
				IbatisDbServer.getGmSqlMapper().startTransaction();
				try {
					for (Iterator<Entry<Integer, RoomAbs>> iterator = roomMap
							.entrySet().iterator(); iterator.hasNext();) {
						Entry<Integer, RoomAbs> type = iterator.next();
						try {
							type.getValue().dissolveRoom(
									DissolveRoomType.SERVER_STOP);
						} catch (Exception e) {
							LoggerService.getRoomlogs()
									.error(e.getMessage(), e);
							LoggerService.getRoomlogs().error(
									"没有重置房间成功！roomId:{}", type.getKey());
						}
					}
					IbatisDbServer.getGmSqlMapper().commitTransaction();
				} finally {
					IbatisDbServer.getGmSqlMapper().endTransaction();
				}
			} catch (SQLException e) {
				LoggerService.getRoomlogs().error(e.getMessage(), e);
			}
		}
	};

	@Override
	public List<EventAbs> getGameEventList() {
		return Arrays.asList(user_LogIn, User_LogOut, shutDown);
	}

	@Override
	public void init() throws Exception {
		TimeConfig.init();
		for (AreaType pType : AreaType.values()) {
			this.areaCacheRoomMap.put(pType, new Stack<RoomAbs>());
		}
	}

	@Override
	public void backDb() throws SQLException {
	}

	@Override
	public byte[] processMessage(Channel channel, IoMessage message)
			throws Exception {
		return null;
	}

	@Override
	public byte[] processMessage(IncomeUserI user, IoMessage message)
			throws Exception {
		MessageLite messageLite = message.genMessageLite();
		switch (message.getMsgId()) {
		case CreateRoomBeforeCm:
			return RoomManager.createRoomBefore(user,
					(CreateRoomBeforeCm) messageLite);
		case CreateRoomCm:
			return RoomManager.createRoom(user, (CreateRoomCm) messageLite);
		case JoinRoomBeforeCm:
			return RoomManager.joinRoomBefore(user,
					(JoinRoomBeforeCm) messageLite);
		case JoinRoomCm:
			return RoomManager.joinRoom(user, (JoinRoomCm) messageLite);
		case BattleBackCm:
			return RoomManager.battleBack(user,
					(BattleBackCm) message.genMessageLite());
		case PrepareRoomCm:
			return RoomManager.prepareRoom(user,
					(PrepareRoomCm) message.genMessageLite());
		default:
			return this.processRoomMessage(user, message);
		}
	}

	/**
	 * 处理游戏中消息
	 * 
	 * @param user
	 * @param message
	 * @return
	 * @throws Exception
	 */
	private byte[] processRoomMessage(IncomeUserI user, IoMessage message)
			throws Exception {
		MsgId msgId = message.getMsgId();
		MessageLite messageLite = message.genMessageLite();
		RoomAbs room = getRoom(user);
		if (room == null) {
			LoggerService.getLogicLog().error("找不到房间！uid:{},msgId:{}",
					user.getUid(), message.getMsgId());
			return msgId.gRErrMsg(NTxt.NOT_FOUND_ROOM);
		}
		Seat seat = room.getSeat(user);
		if (seat == null) {
			LoggerService.getLogicLog().error("找不到玩家位置！uid:{},msgId:{}",
					user.getUid(), message.getMsgId());
			return msgId.gRErrMsg(NTxt.NOT_FOUND_SEAT);
		}
		if (room.isGameOver()) {
			LoggerService.getLogicLog().error("游戏结束，无法处理！uid:{},msgId:{}",
					user.getUid(), message.getMsgId());
			return msgId.gRErrMsg(NTxt.GAME_OVER);
		}
		switch (msgId) {
		case ReconnectCm:
			return room.reconnect(seat, (ReconnectCm) message.genMessageLite());
		case ChatCm:
			return room.chat(seat, (ChatCm) message.genMessageLite());
		case ImCm:
			return room.im(seat, (ImCm) messageLite);
		case NsCm:
			return room.ns(seat, (NsCm) messageLite);
		default:
			break;
		}
		if (room.isStart()) {
			switch (msgId) {
			case MemberDissolveRoomCm:
				return room.memberDissolveRoom(seat,
						(MemberDissolveRoomCm) messageLite);
			case BaoTingCm:
				return room.baoTing(seat,
						((BaoTingCm) messageLite).getBaoTing());
			case ZiMoPaiCm:
				return room.ziMoPai(seat);
			case AnGangPaiCm:
				return room
						.anGangPai(seat, ((AnGangPaiCm) messageLite).getMj());
			case MingGangPaiCm:
				return room.mingGangPai(seat,
						((MingGangPaiCm) messageLite).getMj());
			case QiangGangCm:
				return room.qiangGang(seat);
			case DaPaiCm:
				return room.daPai(seat, ((DaPaiCm) messageLite).getMj());
			case JiePaoCm:
				return room.jiePao(seat);
			case JieGangCm:
				return room.jieGang(seat);
			case PengPaiCm:
				return room.pengPai(seat);
			case ChiPaiCm:
				return room.chiPai(seat, ((ChiPaiCm) messageLite).getChi());
			case OverCm:
				return room.over(seat);
			default:
				return msgId.gRErrMsg(NTxt.NOT_IMPLEMENT);
			}
		} else {
			switch (msgId) {
			case DissolveRoomCm:
				return room.dissolveRoom(seat, (DissolveRoomCm) messageLite);
			case LeaveRoomCm:
				return room.leaveRoom(seat, (LeaveRoomCm) messageLite);
			default:
				return msgId.gRErrMsg(NTxt.NOT_IMPLEMENT);
			}
		}
	}

	/**
	 * 获取玩家当前所在的房间
	 * 
	 * @param user
	 * @return
	 */
	public RoomAbs getRoom(IncomeUserI user) {
		return user.getRoom();
	}

	public RoomAbs getRoom(int roomId) {
		return this.roomMap.get(roomId);
	}

	public Stack<RoomAbs> getCacheRoomStack(AreaType areaType) {
		return this.areaCacheRoomMap.get(areaType);
	}

	public void putRoom(RoomAbs room) {
		this.roomMap.put(room.getId(), room);
	}

	public RoomAbs getRoom(String roomId) {
		return this.roomMap.get(Integer.parseInt(roomId));
	}

	public RoomAbs removeRoom(int id) throws SQLException {
		RoomAbs remove = this.roomMap.remove(id);
		if (remove != null) {
			Stack<RoomAbs> stack = this.getCacheRoomStack(remove.getAreaType());
			stack.push(remove);
		}
		int resetRoom = RoomDao.resetRoom(id);
		if (resetRoom != 1) {
			LoggerService.getLogicLog().error("没有重置房间成功！roomId:{}", id);
		}
		return remove;
	}
}
