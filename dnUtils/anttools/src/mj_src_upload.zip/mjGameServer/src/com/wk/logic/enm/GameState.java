package com.wk.logic.enm;


/**
 * 游戏状态
 * 
 * 准备，，未开始
 * 
 * @author ems
 *
 */
public enum GameState {
	/** 未开始 */
	noStart(0),
	/** 已经准备 */
	prepared(1),
	/** 等待他人操作 */
	waitOtherOperation(2),
	/** 选择报听 */
	baoTing(3),
	/** 自摸、暗杠、明杠、过 */
	ziMoAnGangMingGangGuo(4),
	/** 打牌 */
	daPai(5),
	/** 接炮、接杠、碰、吃、过 */
	jiePaoJieGangPengChiGuo(6),
	/** 抢杠、过 */
	qiangGangGuo(7),
	/***/
	;

	private int type;

	private GameState(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	// 自动生成开始
public static GameState getEnum(int type){
switch(type) {
case 0:
  return noStart;
case 1:
  return prepared;
case 2:
  return waitOtherOperation;
case 3:
  return baoTing;
case 4:
  return ziMoAnGangMingGangGuo;
case 5:
  return daPai;
case 6:
  return jiePaoJieGangPengChiGuo;
case 7:
  return qiangGangGuo;
default:
  return null;
}
}// 自动生成结束
}