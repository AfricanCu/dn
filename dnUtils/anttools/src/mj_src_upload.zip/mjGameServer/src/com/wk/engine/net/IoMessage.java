package com.wk.engine.net;

import com.google.protobuf.MessageLiteOrBuilder;
import com.wk.engine.net.I.IoMessageAbs;
import com.wk.logic.enm.MsgId;

/**
 * 逻辑消息
 * 
 * @author lixing 2015年3月30日
 */
public class IoMessage extends IoMessageAbs<MsgId> {

	public IoMessage(MsgId msgId, byte[] msg) throws Exception {
		super(msgId, msg);
	}

	public IoMessage(MsgId msgId, MessageLiteOrBuilder liteorBuilder)
			throws Exception {
		super(msgId, liteorBuilder);
	}

}
