package com.wk.logic.area;

import java.util.ArrayList;
import java.util.List;

import msg.RoomMessage.PlayType;

import com.wk.mj.enun.HuPaiType;
import com.wk.play.AreaPlayTypeI;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

public class YI_YANG extends AreaType {
	private static final YI_YANG instance = new YI_YANG();

	public static YI_YANG getInstance() {
		return instance;
	}

	/***/
	private YI_YANG() {
		super("益阳麻将", 2, YUAN_JIANG.timesList);
	}

	@Override
	public int getTimes(HuPaiType huPaiType, PlayTypeSet playTypeSet) {
		switch (huPaiType) {
		case pingHu:
			return 0;
		case mengQing:
			if (playTypeSet.isMengQing()) {
				return 1;
			}
			break;
		case tianHu:
			return 1;
		case diHu:
			if (playTypeSet.isDiHu())
				return 1;
			break;
		case baoTing:
			if (playTypeSet.isBaoTing())
				return 1;
			break;
		case jiangJiangHu:
			return 1;
		case qingYiSe:
			return 1;
		case yiTiaoLong:
			return 1;
		case pengPengHu:
			return 1;
		case xiaoQiDui:
			return 1;
		case haoHuaXiaoQiDui:
			return 2;
		case doubleHaoHuaXiaoQiDui:
			return 3;
		case threeHaoHuaXiaoQiDui:
			return 4;
		case haiDi:
			return 1;
		case qiangGangHu:
			return 1;
		case gangBao:
			return 1;
		case yiZiQiao:
			return 1;
		default:
			throw new UnsupportedOperationException(String.format(
					"这个地方不可能出现此胡法！huPaiType:%s", huPaiType));
		}
		throw new UnsupportedOperationException(String.format(
				"设置的玩法不包括此胡法！huPaiType:%s", huPaiType));
	}

	@Override
	public int calcFan(ArrayList<HuPaiType> arrayList, PlayTypeSet playTypeSet) {
		int sumDaHu = 0;
		for (HuPaiType type : arrayList) {
			int times = getTimes(type, playTypeSet);
			if (times > 0)
				sumDaHu += times;
		}
		if (sumDaHu > 1) {
			return (int) (3 * Math.pow(2, sumDaHu - 1));
		} else if (sumDaHu == 1) {
			return 3;
		} else {
			return 1;
		}
	}

	@Override
	public List<String> getPlayTypeDesc(PlayType playType) {
		List<String> list = new ArrayList<String>();
		list.add(this.getName());
		list.add(BankerMode.getEnum(playType.getBankerMode()).getName());
		list.add(TimesLimitType.getEnum(playType.getTimesLimit()).getName());
		if (playType.getMenQing()) {
			list.add("门清");
			if (playType.getJiangJiangHu()) {
				list.add("门清将将胡可接炮");
			}
		}
		if (playType.getYiZiQiao()) {
			list.add("有喜");
		} else
			list.add("没喜");
		switch (ZhaNiaoType.getEnum(playType.getZhaNiao())) {
		case zhuaNiao:
			list.add("抓鸟");
			break;
		case feiNiao:
			list.add("飞鸟");
			break;
		default:
			break;
		}
		list.add(String.format("%s鸟", playType.getSeveralNiao()));
		return list;
	}

	@Override
	public boolean getYiZiQiaoYouXi(PlayType playType) {
		return false;
	}

	@Override
	public boolean isYiZiQiao() {
		return true;
	}

	@Override
	public boolean isJiangJianghu() {
		return true;
	}

	@Override
	public boolean isRightNowZhuaCanMingGang() {
		return true;
	}

	@Override
	public boolean isJiePaoJiangNiao() {
		return true;
	}

	@Override
	public boolean isHaiDi() {
		return true;
	}

	@Override
	public HuPaiType getQuanQiuRenType() {
		return HuPaiType.yiZiQiao;
	}
}
