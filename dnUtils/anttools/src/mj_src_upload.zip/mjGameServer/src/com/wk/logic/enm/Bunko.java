package com.wk.logic.enm;

/**
 * 输赢
 * 
 * @author ems
 *
 */
public enum Bunko {
	/**
	 * 输0
	 */
	Fail(0),
	/**
	 * 赢1
	 */
	Win(1),

	;

	private int type;

	private Bunko(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

	// 自动生成开始
public static Bunko getEnum(int type){
switch(type) {
case 0:
  return Fail;
case 1:
  return Win;
default:
  return null;
}
}// 自动生成结束
}