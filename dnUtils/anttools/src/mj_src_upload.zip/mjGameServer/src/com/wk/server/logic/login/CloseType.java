package com.wk.server.logic.login;

/**
 * 关闭连接类型
 * 
 * @author ems
 *
 */
public enum CloseType {
	/**
	 * 踢人！
	 */
	kick(),
	/**
	 * 普通关闭
	 */
	normal;
	private CloseType() {
	}
}
