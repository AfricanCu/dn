package com.wk.server.logic.item;

public class ItemManager {

	private final static ItemManager instance = new ItemManager();

}
