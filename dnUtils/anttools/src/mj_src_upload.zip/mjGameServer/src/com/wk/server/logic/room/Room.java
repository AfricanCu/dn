package com.wk.server.logic.room;

import msg.MjMessage.RoundResultCast;
import io.netty.buffer.ByteBuf;

import com.wk.logic.area.AreaType;

/**
 * 房间
 * 
 * @author ems
 *
 */
public class Room extends RoomAbs {
	/** 游戏未开始空局结算广播 **/
	private static final RoundResultCast.Builder nullRoundResultCast = RoundResultCast
			.newBuilder();

	public Room(AreaType pType) {
		super(pType);
	}

	@Override
	public void writeExternal(ByteBuf out) throws Exception {
		new SerializeObj(
				this.getPlayType(),
				this.gameRecordSm,
				this.getRoomState() == RoomStateCache.noStart ? nullRoundResultCast
						: this.roundResultCast, this.getJulebuRoom(),
				this.getMasterId(), this.isStart(), this.getSeats(),
				this.battleBackSm, this.getGenPaiList(), this.getInitBanker())
				.writeExternal(out);
	}

	@Override
	public void readExternal(ByteBuf in) throws Exception {
		// TODO Auto-generated method stub
	}

	@Override
	public void initEx() throws Exception {
		// TODO Auto-generated method stub
	}

}
