package com.wk.logic.enm;

import msg.InnerMessage.GuildGsToGs;
import msg.InnerMessage.UserGsToGs;

import com.wk.server.logic.friend.FindUserHandlerI;
import com.wk.server.logic.guild.FindGuildHandlerI;
import com.wk.server.logic.guild.FindMemberHandlerI;

/**
 * 
 * @author ems
 *
 */
public enum UserGTGType {
	/**
	 * 
	 */
	RetDiamondToGuildMaster(1, "还钻石给会长") {
		@Override
		public int process(UserGsToGs userGsToGs) {
			return new FindUserHandlerI.ChangeDiamondHandler(this, userGsToGs)
					.getCode();
		}
	},
	CreateJulebuRoomConsumeDiamond(2, "创建俱乐部房间消耗钻石") {
		@Override
		public int process(UserGsToGs userGsToGs) {
			return new FindUserHandlerI.ChangeDiamondHandler(this, userGsToGs)
					.getCode();
		}
	},
	;
	private final int type;
	private final String name;

	private UserGTGType(int type, String name) {
		this.type = type;
		this.name = name;
	}

	public int getType() {
		return type;
	}

	public String getName() {
		return name;
	}

	// 自动生成开始
	public static UserGTGType getEnum(int type) {
		switch (type) {
		case 1:
			return RetDiamondToGuildMaster;
		default:
			return null;
		}
	}// 自动生成结束

	public abstract int process(UserGsToGs userGsToGs);
}