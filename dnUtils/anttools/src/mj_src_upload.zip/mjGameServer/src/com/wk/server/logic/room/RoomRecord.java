package com.wk.server.logic.room;

import java.io.File;
import java.nio.file.FileSystems;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;
import java.util.concurrent.TimeUnit;

import msg.BackMessage.SeetOpera;
import msg.MjMessage.FeiBao;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.BattlebackBean;
import com.wk.bean.SystemConstantsAbs;
import com.wk.db.dao.BattlebackDao;
import com.wk.logic.area.AreaType;
import com.wk.mj.MjTools;
import com.wk.mj.MjUtils;
import com.wk.mj.Pai;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.MjType;
import com.wk.mj.enun.OperaType;
import com.wk.util.FileProcessor;
import com.wk.util.TimeTaskUtil;

public abstract class RoomRecord extends RoomBase {
	public static final String paisPath = "./resource/aa";
	private static final int shaiziNum = 2;

	private static final boolean testHuPai() {
		return MjTools.isTestHuPai();
	}

	/** 色子 **/
	private List<Integer> shaizi;
	/** 麻将集合 **/
	private List<Pai> genPaiList;
	/** 顺抓数第几张牌 **/
	private int zhuaPaiNum;
	/** 补牌第几张 */
	private int buPaiNum;
	/** 飞宝消息 */
	private FeiBao.Builder feiBao = FeiBao.newBuilder();
	/** 跌宝牌位置后边有多少张可以补的牌 */
	private int dieRightBu;
	/** 跌宝牌位置 */
	private int dieBaoIndex;
	/** 跌宝牌 */
	private Pai dieBao;
	/** 宝牌 */
	private Pai bao;

	public RoomRecord(AreaType pType) {
		super(pType);
	}

	/**
	 * 
	 * @param shaiZiList
	 *            重载骰子
	 * @param genPaiList
	 *            重载牌集合
	 */
	protected void nextRound(List<List<Integer>> shaiZiList,
			List<Pai> genPaiList) {
		super.nextRound();
		for (Seat st : this.seats) {
			st.nextRound();
		}
		this.addRound();
		this.battleBackSm.setPlayType(this.getPlayType());
		this.battleBackSm.setRoomId(this.getIdStr());
		this.battleBackSm.setRound(this.getRound());
		this.setShaizi(shaiZiList.get(0));
		this.battleBackSm.addAllShaizi(this.getShaizi());
		this.battleBackSm.setIsProxy(this.isBelongGuild());
		this.battleBackSm.setBankerSeetIndex(this.getBankerSeat().getId());
		this.setGenPaiList(genPaiList);
		genTestPai();
		if (this.genPaiList == null) {
			this.setGenPaiList(this.isFeng() ? MjUtils.genHasFengPais()
					: MjUtils.genNoFengPais());
		}
		if (this.isFeiBao()) {
			feiBao.clear();
			List<Integer> list = shaiZiList.get(1);
			this.dieRightBu = (list.get(0) + list.get(1)) * 2 - 1;
			this.dieBaoIndex = this.genPaiList.size() - 1 - this.dieRightBu;
			this.dieBao = this.genPaiList.get(this.dieBaoIndex);
			this.bao = dieBao.getType().getBaoPai(this.dieBao);
			feiBao.addAllBaoPaiShaizi(list);
			feiBao.setDieBaoPai(dieBao.getMj());
			feiBao.setBaoPai(bao.getMj());
			this.battleBackSm.setFeiBao(feiBao.build());
		}
		this.zhuaPaiNum = 0;
		this.buPaiNum = 0;
	}

	public List<List<Integer>> genShaiZi() {
		List<List<Integer>> list = new ArrayList<>();
		int size;
		if (this.isFeiBao()) {
			size = 2;
		} else
			size = 1;
		for (int index = 0; index < size; index++) {
			ArrayList<Integer> arrayList = new ArrayList<Integer>();
			for (int i = 0; i < shaiziNum; i++) {
				arrayList.add(ThreadLocalRandom.current().nextInt(6) + 1);
			}
			list.add(arrayList);
		}
		return list;
	}

	public FeiBao getFeiBao() {
		return feiBao.build();
	}

	public Pai getDeiBao() {
		return dieBao;
	}

	public Pai getBao() {
		return bao;
	}

	public boolean isBao(Pai pai) {
		return this.isFeiBao() && pai == this.bao;
	}

	public void setShaizi(List<Integer> shaizi) {
		this.shaizi = shaizi;
	}

	public List<Integer> getShaizi() {
		return shaizi;
	}

	public List<Pai> getGenPaiList() {
		return genPaiList;
	}

	public void setGenPaiList(List<Pai> genPaiList) {
		this.genPaiList = genPaiList;
	}

	public List<Pai> getFaPais() {
		return this.genPaiList.subList(this.zhuaPaiNum,
				this.zhuaPaiNum += MjTools.getNumbermaxMinus());
	}

	/**
	 * 加入操作
	 * 
	 * @param seat
	 * @param seetIndex
	 *            没有填-1
	 * @param type
	 * @param pai
	 * @param chi
	 */
	protected void addSeetOpera(Seat seat, int seetIndex, OperaType type,
			Pai pai, ChiType chiType) {
		SeetOpera.Builder seetOpera = SeetOpera.newBuilder();
		seetOpera.setSIndex(seat.getId()).setOpera(type.getType());
		if (seetIndex != -1)
			seetOpera.setSeetIndex(seetIndex);
		if (pai != null) {
			seetOpera.setMj(pai.getMj());
		}
		if (chiType != null) {
			seetOpera.setChi(chiType.getType());
		}
		this.battleBackSm.addOpera(seetOpera.build());
		if (type != OperaType.zhuaPai) {
			if (saveTask == null)
				saveTask = TimeTaskUtil.getTaskmanager().submitOneTimeTask(
						new Runnable() {
							@Override
							public void run() {
								RoomRecord.this.save();
							}
						}, 60, TimeUnit.SECONDS);
		}
	}

	public void genTestPai() {
		if (testHuPai()) {
			String readString = FileProcessor.readString(FileSystems
					.getDefault().getPath(new File(paisPath).getPath()));
			String data = readString.replaceAll("\\s+", "");
			ArrayList<Pai> noFengPaiList = new ArrayList<>();
			for (String pai : data.split(SystemConstantsAbs.Double_SHARP_SEP)) {
				String[] split = pai.split(SystemConstantsAbs.dot_SEP);
				noFengPaiList.add(Pai.getPai(split[0]));
			}
			this.setGenPaiList(noFengPaiList);
			LoggerService.getLogicLog().error("重新读取数据成功，抓到第{}张牌,补到第{}张牌",
					this.zhuaPaiNum, this.buPaiNum);
		}
	}

	/** 剩余多少张牌可以抓 */
	public int getLeftPaiNum() {
		if (isFeiBao()) {
			if (this.buPaiNum > this.dieRightBu) {
				return this.dieBaoIndex - (this.buPaiNum - this.dieRightBu)
						- this.zhuaPaiNum;
			} else
				return this.dieBaoIndex - this.zhuaPaiNum;
		} else
			return this.genPaiList.size() - this.zhuaPaiNum - this.buPaiNum;
	}

	/**
	 * 移除一个牌
	 * 
	 * @param isBu
	 * 
	 * @return
	 */
	public Pai getPai(boolean isBu) {
		try {
			if (isFeiBao()) {
				if (isBu) {
					int index = this.genPaiList.size() - 1 - this.buPaiNum++;
					if (index <= this.dieBaoIndex) {
						index--;
					}
					if (index >= this.zhuaPaiNum)
						return this.genPaiList.get(index);
					else
						return null;
				} else {
					if (this.getLeftPaiNum() > 0)
						return this.genPaiList.get(this.zhuaPaiNum++);
					else
						return null;
				}
			} else {
				if (isBu) {
					int index = this.genPaiList.size() - 1 - this.buPaiNum++;
					if (index >= this.zhuaPaiNum)
						return this.genPaiList.get(index);
					else
						return null;
				} else {
					if (this.zhuaPaiNum < this.genPaiList.size()
							- this.buPaiNum)
						return this.genPaiList.get(this.zhuaPaiNum++);
					else
						return null;
				}
			}
		} finally {
			LoggerService.getLogicLog().error("抓到第{}张牌,补到第{}张牌",
					this.zhuaPaiNum, this.buPaiNum);
		}
	}

	/** 补了多少张牌 **/
	public int getBuPaiNum() {
		return buPaiNum;
	}

	/**
	 * 是否是海底
	 * 
	 * 只剩下了4张
	 * 
	 * @return
	 */
	public boolean isHaiDi() {// 0,1,2,3,4,5, 6,7,8,9
		return this.getPlayTypeSet().isHaiDi()
				&& this.zhuaPaiNum >= this.genPaiList.size() - this.buPaiNum
						- 4;
	}

	/**
	 * 是否摸的是海底
	 * 
	 * @return
	 */
	public boolean isMoHaiDi() {
		return this.getPlayTypeSet().isHaiDi()
				&& this.zhuaPaiNum >= this.genPaiList.size() - this.buPaiNum
						- 3;
	}

	/**
	 * 记录战斗回放到数据库
	 * 
	 * @return
	 */
	public int recordBattleback() {
		for (Seat st : this.seats) {
			this.battleBackSm.addRs(st.getRoundRs());
		}
		int insertBattleback = -1;
		try {
			insertBattleback = BattlebackDao
					.insertBattleback(new BattlebackBean(0, this.genPaiList,
							this.battleBackSm.build().toByteArray()));
		} catch (SQLException e) {
			LoggerService.getRoomlogs().error(e.getMessage(), e);
		}
		return insertBattleback;
	}
}