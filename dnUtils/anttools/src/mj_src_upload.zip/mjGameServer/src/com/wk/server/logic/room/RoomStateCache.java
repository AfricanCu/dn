package com.wk.server.logic.room;

import msg.MjMessage.ChiPaiCast;
import msg.MjMessage.DaPaiCast;
import msg.MjMessage.HaiDiZhuaPaiCast;
import msg.MjMessage.PengPaiCast;
import msg.MjMessage.RoundResultCast;
import msg.MjMessage.ZhuaPaiCast;

import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MsgId;
import com.wk.mj.MjTools;
import com.wk.mj.Pai;
import com.wk.mj.Ting;
import com.wk.mj.enun.ChiType;

public enum RoomStateCache {
	/** 未开始 */
	noStart() {
		@Override
		public void seatReconnect(RoomAbs room, Seat seat) {
			if (room.getRound() > 0) {
				RoundResultCast.Builder roundResultCast = room.roundResultCast;
				roundResultCast.setReconnect(true);
				seat.sendMessage(MsgId.RoundResultCast, roundResultCast.build()
						.toByteArray());
			}
		}
	},
	/** 等玩家选择报听 */
	baoTing {
		@Override
		public void seatReconnect(RoomAbs roomAbs, Seat seat) {
			// TODO Auto-generated method stub
		}
	},
	/** 玩家抓牌推送 */
	zhuaPaiCast() {
		@Override
		public void seatReconnect(RoomAbs room, Seat seat) {
			ZhuaPaiCast.Builder zhuaPaiCast = room.zhuaPaiCast;
			if (seat.isMeHaveZhuaBu()) {
				seat.sendMessage(MsgId.ZhuaPaiCast, zhuaPaiCast.build()
						.toByteArray());
			} else {
				seat.sendMessage(MsgId.SeetZhuaPaiCast, room.seetZhuaPaiCast
						.build().toByteArray());
			}
		}
	},
	/** 玩家打牌推送 */
	daPaiCast() {
		@Override
		public void seatReconnect(RoomAbs room, Seat seat) {
			DaPaiCast.Builder daPaiCast = room.daPaiCast;
			boolean isCanPeng = seat.isCanPeng(room.getHaveDaPai());
			boolean isCanJieGang = seat.isCanJieGang(room.getHaveDaPai());
			boolean isCanJiePao = seat.isCanJiePao();
			daPaiCast.setMj(room.getHaveDaPai().getMj());
			daPaiCast.setSeetIndex(room.getHaveDaPaiSeat().getId());
			daPaiCast.setPeng(!seat.isBaoTing() && isCanPeng);
			daPaiCast.setJieGang(!seat.isBaoTing() && isCanJieGang);
			daPaiCast.setJiePao(isCanJiePao);
			daPaiCast.clearChi();
			if (room.isChi() && room.getHaveDaPaiSeat().getNextSeat() == seat) {
				for (ChiType type : ChiType.values())
					if (seat.isCanChi(type, room.getHaveDaPai()) != null)
						daPaiCast.addChi(type.getType());
			}
			seat.sendMessage(MsgId.DaPaiCast, daPaiCast.build().toByteArray());
		}
	},
	/** 碰推送 */
	pengPaiCast() {
		@Override
		public void seatReconnect(RoomAbs room, Seat seat) {
			PengPaiCast.Builder pengPaiCast = room.pengPaiCast;
			if (seat.isMeHavePeng()) {
				for (Pai anGangPai : seat.getAnGangCacheArr()) {
					pengPaiCast.addAnGang(anGangPai.getMj());
				}
				for (Pai mingGangPai : seat.getMingGangCacheArr()) {
					pengPaiCast.addMingGang(mingGangPai.getMj());
				}
				for (Ting ting : seat.getTingCacheList()) {
					if (ting.isTing()) {
						pengPaiCast.addTing(ting.genTing());
					}
				}
			} else {
				pengPaiCast.clearAnGang();
				pengPaiCast.clearMingGang();
				pengPaiCast.clearTing();
			}
			seat.sendMessage(MsgId.PengPaiCast, pengPaiCast.build()
					.toByteArray());
		}
	},
	/** 吃推送 */
	chiPaiCast() {
		@Override
		public void seatReconnect(RoomAbs room, Seat seat) {
			ChiPaiCast.Builder chiPaiCast = room.chiPaiCast;
			if (seat.isMeHaveChi()) {
				for (Pai anGangPai : seat.getAnGangCacheArr()) {
					chiPaiCast.addAnGang(anGangPai.getMj());
				}
				for (Pai mingGangPai : seat.getMingGangCacheArr()) {
					chiPaiCast.addMingGang(mingGangPai.getMj());
				}
				for (Ting ting : seat.getTingCacheList()) {
					if (ting.isTing()) {
						chiPaiCast.addTing(ting.genTing());
					}
				}
			} else {
				chiPaiCast.clearAnGang();
				chiPaiCast.clearMingGang();
				chiPaiCast.clearTing();
			}
			seat.sendMessage(MsgId.ChiPaiCast, chiPaiCast.build().toByteArray());
		}
	},
	/** 海底抓牌 */
	haiDizhuaPaiCast() {
		@Override
		public void seatReconnect(RoomAbs room, Seat seat) {
			HaiDiZhuaPaiCast.Builder haiDiZhuaPaiCast = room.haiDiZhuaPaiCast;
			if (seat.getGstate() == GameState.ziMoAnGangMingGangGuo) {
				seat.sendMessage(MsgId.HaiDiZhuaPaiCast, haiDiZhuaPaiCast
						.build().toByteArray());
			} else {
				seat.sendMessage(MsgId.SeetZhuaPaiCast, room.seetZhuaPaiCast
						.build().toByteArray());
			}
		}
	},
	/**
	 */
	;
	public abstract void seatReconnect(RoomAbs room, Seat seat);
}
