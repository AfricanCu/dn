package com.wk.logic.area;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import msg.RoomMessage.PlayType;

import com.wk.mj.enun.HuPaiType;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

public class YING_TANG_FEI_BAO extends AreaType {

	public final static List<TimesLimitType> timesList = Arrays.asList(
			TimesLimitType._16Times, TimesLimitType._32Times,
			TimesLimitType._64Times);

	private final static YING_TANG_FEI_BAO instance = new YING_TANG_FEI_BAO(
			"鹰潭飞宝麻将", 3);

	public static YING_TANG_FEI_BAO getInstance() {
		return instance;
	}

	public YING_TANG_FEI_BAO(String name, int type) {
		super(name, type, timesList);
	}

	@Override
	public int getTimes(HuPaiType huPaiType, PlayTypeSet playTypeSet) {
		switch (huPaiType) {
		case pingHu:
			return 0;
		case pengPengHu:
			return 1;
		case shiSanLan:
			return 1;
		case qiXingShiSanLan:
			return 2;
		case hunYiSe:
			return 1;
		case xiaoQiDui:
			return 2;
		case haoHuaXiaoQiDui:
			return 3;
		case doubleHaoHuaXiaoQiDui:
			return 4;
		case threeHaoHuaXiaoQiDui:
			return 5;
		case qingYiSe:
			return 2;
		case qiangGangHu:
			return 1;
		case gangBao:
			return 1;
		case danDiao:
			return 1;
		case baoPai1:
			return 1;
		case baoPai2:
			return 2;
		case baoPai3:
			return 3;
		case baoPai4:
			return 4;
		case douBao:
			return 1;
		default:
			throw new UnsupportedOperationException(String.format(
					"这个地方不支持此胡法的2次幂计算！huPaiType:%s", huPaiType));
		}
	}

	@Override
	public final int calcFan(ArrayList<HuPaiType> arrayList,
			PlayTypeSet playTypeSet) {
		int sumDaHu = 0;
		for (HuPaiType type : arrayList) {
			if (type == HuPaiType.tianHu) {
				return 20;
			} else if (type == HuPaiType.diHu) {
				return 20;
			}
			int times = getTimes(type, playTypeSet);
			if (times > 0)
				sumDaHu += times;
		}
		if (sumDaHu > 0)
			return 2 * (int) Math.pow(2, sumDaHu);
		else
			return 2;
	}

	@Override
	public List<String> getPlayTypeDesc(PlayType playType) {
		List<String> list = new ArrayList<String>();
		list.add(this.getName());
		list.add(BankerMode.getEnum(playType.getBankerMode()).getName());
		list.add(TimesLimitType.getEnum(playType.getTimesLimit()).getName());
		return list;
	}

	@Override
	public SeveralNiaoType getSeveralNiaoType(PlayType playType)
			throws Exception {
		return SeveralNiaoType.zero;
	}

	@Override
	public boolean isMengQing(PlayType playType) {
		return false;
	}

	@Override
	public boolean getYiZiQiaoYouXi(PlayType playType) {
		return false;
	}

	@Override
	public ZhaNiaoType getZhaNiaoType(PlayType playType) {
		return null;
	}

	@Override
	public boolean isDiHu(PlayType playType) throws Exception {
		return true;
	}

	@Override
	public boolean isBaoTing(PlayType playType) throws Exception {
		return false;
	}

	@Override
	public boolean isFeng() {
		return true;
	}

	@Override
	public boolean isShiSanLan() {
		return isFeng();
	}

	@Override
	public boolean isHunYiSe() {
		return true;
	}

	@Override
	public boolean isPingHuJiePao() {
		return true;
	}

	@Override
	public boolean isFeiBao() {
		return true;
	}

	@Override
	public boolean isChi() {
		return true;
	}

	@Override
	public boolean isMingGangSuanJieGang() {
		return true;
	}

	@Override
	public HuPaiType getQuanQiuRenType() {
		return HuPaiType.danDiao;
	}
	
	@Override
	public boolean isJiePaoJiangNiao() {
		return false;
	}
}