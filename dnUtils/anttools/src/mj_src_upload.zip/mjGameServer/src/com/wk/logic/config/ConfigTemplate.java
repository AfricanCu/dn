package com.wk.logic.config;

import com.wk.util.ReadUtil;
import com.wk.util.TemplateCheckAbs;

/**
 * 游戏配置
 * 
 * @author ems
 *
 */
public class ConfigTemplate implements TemplateCheckAbs {

	private static ConfigTemplate configTemplate;

	public static void explain(String string) throws Exception {
		ConfigTemplate tmp = ReadUtil.explainCsvData(string,
				ConfigTemplate.class, true).get(0);
		configTemplate = tmp;
	}

	public static ConfigTemplate getConfigTemplate() {
		return configTemplate;
	}

	private int iD;
	private int overTimeInHourDissolve;
	private int guildCreateRoomMax;
	/** 公会最多多少成员 **/
	private int guildMemberMax;

	public int getiD() {
		return iD;
	}

	public int getOverTimeInHourDissolve() {
		return overTimeInHourDissolve;
	}

	@Override
	public void check() throws Exception {
	}

	public int getGuildCreateRoomMax() {
		return guildCreateRoomMax;
	}

	public int getGuildMemberMax() {
		return guildMemberMax;
	}

}
