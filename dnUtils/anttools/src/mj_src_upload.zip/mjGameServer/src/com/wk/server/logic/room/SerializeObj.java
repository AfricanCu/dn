package com.wk.server.logic.room;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.util.ArrayList;
import java.util.List;

import msg.BackMessage.BattleBackSm;
import msg.LoginMessage.GameRecordSm;
import msg.MjMessage.RoundResultCast;
import msg.RoomMessage.JulebuRoom;
import msg.RoomMessage.PlayType;

import com.google.protobuf.InvalidProtocolBufferException;
import com.wk.I.ByteBufferSerializable;
import com.wk.bean.SystemConstantsAbs;
import com.wk.mj.Pai;

/**
 * 房间序列化对象
 * 
 * @author ems
 *
 */
public class SerializeObj implements ByteBufferSerializable {
	private final byte[] playType_byteArray;
	private final byte[] gameRecordSm_byteArray;
	private final byte[] roundResultCast_byteArray;
	private final byte[] julebuRoom_byteArray;
	private final long masterId;
	private final boolean start;
	private final long[] uids;
	private final ByteBuf[] seats;
	private final byte[] battleBackSm_byteArray;
	private final List<Pai> genNoFengPais;
	private final int initBankerSeetIndex;

	/**
	 * 
	 * @param playType
	 * @param gameRecordSm
	 * @param roundResultCast
	 * @param proxy
	 * @param masterId
	 * @param start
	 * @param seats
	 * @param battleBackSm
	 * @param genNoFengPais
	 * @param initBanker
	 * @throws Exception
	 */
	public SerializeObj(PlayType playType, GameRecordSm.Builder gameRecordSm,
			RoundResultCast.Builder roundResultCast, JulebuRoom julebuRoom,
			long masterId, boolean start, Seat[] seats,
			BattleBackSm.Builder battleBackSm, List<Pai> genNoFengPais,
			Seat initBanker) throws Exception {
		super();
		this.playType_byteArray = playType.toByteArray();
		this.gameRecordSm_byteArray = gameRecordSm.build().toByteArray();
		this.roundResultCast_byteArray = roundResultCast.build().toByteArray();
		this.julebuRoom_byteArray = julebuRoom.toByteArray();
		this.masterId = masterId;
		this.start = start;
		this.uids = new long[seats.length];
		int index = 0;
		for (Seat st : seats) {
			this.uids[index] = st.getUserUid();
			index++;
		}
		this.seats = new ByteBuf[seats.length];
		int index2 = 0;
		for (Seat st : seats) {
			ByteBuf out = Unpooled.buffer();
			st.writeExternal(out);
			this.seats[index2] = out;
			index2++;
		}
		this.battleBackSm_byteArray = battleBackSm.build().toByteArray();
		this.genNoFengPais = genNoFengPais == null ? new ArrayList<Pai>()
				: genNoFengPais;
		this.initBankerSeetIndex = initBanker == null ? 0 : initBanker.getId();
	}

	public void writeExternal(ByteBuf out) throws Exception {
		out.writeInt(playType_byteArray.length);
		out.writeBytes(playType_byteArray);
		out.writeInt(gameRecordSm_byteArray.length);
		out.writeBytes(gameRecordSm_byteArray);
		out.writeInt(roundResultCast_byteArray.length);
		out.writeBytes(roundResultCast_byteArray);
		out.writeInt(julebuRoom_byteArray.length);
		out.writeBytes(julebuRoom_byteArray);
		out.writeLong(this.masterId);
		out.writeBoolean(this.start);
		out.writeInt(this.uids.length);
		for (long uid : uids) {
			out.writeLong(uid);
		}
		out.writeInt(this.seats.length);
		for (ByteBuf st : this.seats) {
			out.writeInt(st.readableBytes());
			out.writeBytes(st);
		}
		out.writeInt(battleBackSm_byteArray.length);
		out.writeBytes(battleBackSm_byteArray);
		out.writeInt(this.genNoFengPais.size());
		for (Pai pai : this.genNoFengPais) {
			out.writeInt(pai.getId());
		}
		out.writeInt(this.initBankerSeetIndex);
	}

	public SerializeObj(ByteBuf in) throws Exception {
		playType_byteArray = new byte[in.readInt()];
		in.readBytes(playType_byteArray);
		gameRecordSm_byteArray = new byte[in.readInt()];
		in.readBytes(gameRecordSm_byteArray);
		roundResultCast_byteArray = new byte[in.readInt()];
		in.readBytes(roundResultCast_byteArray);
		julebuRoom_byteArray = new byte[in.readInt()];
		in.readBytes(julebuRoom_byteArray);
		this.masterId = in.readLong();
		this.start = in.readBoolean();
		this.uids = new long[in.readInt()];
		for (int index = 0; index < this.uids.length; index++) {
			this.uids[index] = in.readLong();
		}
		this.seats = new ByteBuf[in.readInt()];
		for (int index = 0; index < this.seats.length; index++) {
			int length = in.readInt();
			ByteBuf buffer = Unpooled.buffer(length);
			in.readBytes(buffer, length);
			this.seats[index] = buffer;
		}
		battleBackSm_byteArray = new byte[in.readInt()];
		in.readBytes(battleBackSm_byteArray);
		this.genNoFengPais = new ArrayList<Pai>();
		int size = in.readInt();
		for (int i = 0; i < size; i++) {
			this.genNoFengPais.add(Pai.getPai(in.readInt()));
		}
		this.initBankerSeetIndex = in.readInt();
	}

	@Override
	public void readExternal(ByteBuf in) throws Exception {
	}

	public byte[] getPlayType_byteArray() {
		return playType_byteArray;
	}

	public byte[] getGameRecordSm_byteArray() {
		return gameRecordSm_byteArray;
	}

	public byte[] getRoundResultCast_byteArray() {
		return roundResultCast_byteArray;
	}

	public JulebuRoom getJulebuRoom() throws InvalidProtocolBufferException {
		if (julebuRoom_byteArray.length == 0) {
			return JulebuRoom.getDefaultInstance();
		}
		return JulebuRoom.newBuilder().mergeFrom(julebuRoom_byteArray).build();
	}

	public static void main(String[] args) {
		System.err
				.println(JulebuRoom.getDefaultInstance().toByteArray().length);
	}

	public long getMasterId() {
		return masterId;
	}

	public boolean isStart() {
		return start;
	}

	public long[] getUids() {
		return uids;
	}

	public ByteBuf[] getSeats() {
		return seats;
	}

	public byte[] getBattleBackSm_byteArray() {
		return battleBackSm_byteArray;
	}

	public PlayType getPlayType() throws InvalidProtocolBufferException {
		return PlayType.newBuilder().mergeFrom(this.playType_byteArray).build();
	}

	public List<Pai> getGenNoFengPais() {
		return this.genNoFengPais;
	}

	public int getInitBankerSeetIndex() {
		return initBankerSeetIndex;
	}
}