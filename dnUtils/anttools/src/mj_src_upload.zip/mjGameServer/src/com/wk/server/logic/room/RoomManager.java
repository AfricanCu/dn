package com.wk.server.logic.room;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.sql.SQLException;
import java.util.Arrays;
import java.util.Stack;

import msg.BackMessage.BattleBackCm;
import msg.BackMessage.BattleBackSm;
import msg.BackMessage.SeetOpera;
import msg.RoomMessage;
import msg.RoomMessage.CreateRoomBeforeCm;
import msg.RoomMessage.CreateRoomBeforeSm;
import msg.RoomMessage.CreateRoomCm;
import msg.RoomMessage.CreateRoomSm;
import msg.RoomMessage.JoinRoomBeforeCm;
import msg.RoomMessage.JoinRoomBeforeSm;
import msg.RoomMessage.JoinRoomCm;
import msg.RoomMessage.JulebuRoom;
import msg.RoomMessage.PlayType;
import msg.RoomMessage.PrepareRoomCm;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.RoomBean;
import com.wk.bean.SystemConstantsAbs;
import com.wk.db.dao.BattlebackDao;
import com.wk.db.dao.RoomDao;
import com.wk.engine.config.ServerConfig;
import com.wk.engine.config.SystemConstants;
import com.wk.engine.inner.BusSysModule;
import com.wk.engine.inner.GsSysModule;
import com.wk.logic.area.AreaType;
import com.wk.logic.config.NTxt;
import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MsgId;
import com.wk.logic.enm.SwType;
import com.wk.mj.enun.OperaType;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.BankerMode;
import com.wk.server.ibatis.select.IncomeUserI;
import com.wk.server.ibatis.select.User;
import com.wk.server.logic.guild.Guild;
import com.wk.server.logic.guild.GuildManager;
import com.wk.server.logic.login.LoginModule;
import com.wk.server.logic.login.UserManager;

public class RoomManager {
	public static final boolean IS_PROXY = true;
	public static final boolean NOT_IS_PROXY = false;
	public static final boolean IS_MASTER = true;
	public static final boolean NOT_IS_MASTER = false;

	public static byte[] createRoomBefore(IncomeUserI user,
			CreateRoomBeforeCm messageLite) {
		PlayType playType = filterPlayType(messageLite.getPlayType());
		if (RoomModule.getInstance().getRoom(user) != null) {
			return MsgId.CreateRoomBeforeCm.gRErrMsg(NTxt.BEFORE_ROOM_ALREADY);
		}
		if (LoginModule.getInstance().getStatus().isFull()) {
			RoomMessage.SwServer.Builder sw = GsSysModule.getInstance().getSw(
					BusSysModule.getInstance().getOserverId(),
					SwType.createRoom, user);
			if (sw == null) {
				return MsgId.CreateRoomBeforeCm.gRErrMsg(NTxt.BEFORE_SW_EMPTY);
			}
			return CreateRoomBeforeSm.newBuilder().setSw(sw)
					.setPlayType(playType).setCode(NTxt.SERVER_NEED_SWITCH)
					.build().toByteArray();
		} else {
			byte[] createRoom = createRoom(user, playType);
			user.sendMessage(MsgId.CreateRoomSm, createRoom);
			return null;
		}
	}

	/**
	 * 所有客户端传过来的玩法都要过滤一下，加入牌总数
	 * 
	 * @param playType
	 * @return
	 */
	public static PlayType filterPlayType(PlayType playType) {
		if (playType.getSumN() < 108)
			playType = PlayType.newBuilder().mergeFrom(playType)
					.setSumN(AreaType.getEnum(playType.getArea()).getSumN())
					.build();
		return playType;

	}

	public static byte[] joinRoomBefore(IncomeUserI user,
			JoinRoomBeforeCm messageLite) throws SQLException {
		int roomId = Integer.parseInt(messageLite.getRoomId());
		if (RoomModule.getInstance().getRoom(user) != null) {
			return MsgId.JoinRoomBeforeCm.gRErrMsg(NTxt.BEFORE_ROOM_ALREADY);
		}
		int serverIdByRoomId = RoomDao.serverIdByRoomId(roomId);
		if (serverIdByRoomId == SystemConstantsAbs.NoServerId) {
			return MsgId.JoinRoomBeforeCm
					.gRErrMsg(NTxt.JOIN_ROOM_BEFORE_NOT_FOUND_ROOM);
		}
		if (serverIdByRoomId != ServerConfig.serverId) {
			RoomMessage.SwServer.Builder sw = GsSysModule.getInstance().getSw(
					serverIdByRoomId, SwType.joinRoom, user);
			if (sw == null) {
				return MsgId.JoinRoomBeforeCm
						.gRErrMsg(NTxt.JOIN_ROOM_BEFORE_SW_EMPTY);
			}
			return JoinRoomBeforeSm.newBuilder()
					.setCode(NTxt.SERVER_NEED_SWITCH).setSw(sw)
					.setRoomId(messageLite.getRoomId()).build().toByteArray();
		} else {
			byte[] joinRoom = joinRoom(user, roomId);
			user.sendMessage(MsgId.JoinRoomSm, joinRoom);
			return null;
		}
	}

	/**
	 * 创建房间
	 * 
	 * @param playType
	 *            玩法
	 * @param masterId
	 *            房主ID
	 * @param areaType
	 *            麻将区域玩法类型
	 * @param julebuRoom
	 * @param reloadRoomId
	 *            传一个房间ID,重新加载房间数据时
	 * @return
	 * @throws Exception
	 */
	public static RoomAbs createRoom(PlayType playType, long masterId,
			AreaType areaType, PlayTypeSet playTypeSet, JulebuRoom julebuRoom,
			int reloadRoomId) throws Exception {
		if (masterId == SystemConstants.NoUid) {
			throw new Exception("房主不能为空！");
		}
		Stack<RoomAbs> stack = RoomModule.getInstance().getCacheRoomStack(
				areaType);
		RoomAbs room = null;
		if (stack.empty()) {
			room = RoomUtils.createRoom(areaType);
		} else {
			try {
				room = stack.pop();
			} catch (Exception e) {
				LoggerService.getRoomlogs().error(e.getMessage(), e);
				room = RoomUtils.createRoom(areaType);
			}
		}
		int id;
		if (reloadRoomId == SystemConstantsAbs.NoRoomId)
			id = RoomUtils.genRoomId(masterId);
		else
			id = reloadRoomId;
		if (id == SystemConstants.NoRoomId) {
			throw new Exception("随机房间号失败!");
		}
		room.init(playType, playTypeSet, masterId, julebuRoom, id);
		if (id != reloadRoomId) {
			room.save();
		}
		RoomModule.getInstance().putRoom(room);
		LoggerService.getLogicLog().error(
				"创房{},guildId:{},num:{}",
				new Object[] { room.getIdStr(), room.getJulebuRoom().getId(),
						room.getJulebuRoom().getNum() });
		return room;
	}

	public static byte[] joinRoom(IncomeUserI user, JoinRoomCm messageLite) {
		JulebuRoom julebuRoom = messageLite.getJulebuRoom();
		int id = julebuRoom.getId();
		int num = julebuRoom.getNum();
		if (id != SystemConstantsAbs.NoGuildId) {
			Guild guild = GuildManager.getInstance().getAndReloadGuild(id);
			if (guild == null) {
				return MsgId.JoinRoomCm.gRErrMsg(NTxt.NO_FOUND_GUILD);
			}
			if (!guild.isMasterOrAssistOrMember(user.getUid())) {
				return MsgId.JoinRoomCm
						.gRErrMsg(NTxt.NOT_GUILD_MASTER_OR_ASSIST_OR_MEMBER);
			}
			return guild.joinRoom(user, num);
		} else {
			int roomId = Integer.parseInt(messageLite.getRoomId());
			return joinRoom(user, roomId);
		}
	}

	/**
	 * 进入普通房间
	 * 
	 * @param user
	 * @param roomId
	 * @return
	 */
	private static byte[] joinRoom(IncomeUserI user, int roomId) {
		if (RoomModule.getInstance().getRoom(user) != null) {
			return MsgId.JoinRoomCm.gRErrMsg(NTxt.JOIN_ROOM_ALREADY_IN_ROOM);
		}
		RoomAbs room = RoomModule.getInstance().getRoom(roomId);
		if (room == null) {
			return MsgId.JoinRoomCm.gRErrMsg(NTxt.JOIN_ROOM_NOT_FOUND_ROOM);
		}
		if (room.isBelongGuild()) {
			return MsgId.JoinRoomCm.gRErrMsg(NTxt.JOIN_ROOM_NOT_FOUND_ROOM);
		}
		byte[] joinRoom = room.joinRoom(user, true);
		return joinRoom;
	}

	public static byte[] createRoom(IncomeUserI user, CreateRoomCm messageLite) {
		PlayType playType = filterPlayType(messageLite.getPlayType());
		return createRoom(user, playType);
	}

	/**
	 * 普通创房
	 * 
	 * @param user
	 *            既是房主又是房间玩家
	 * @param playType
	 * @return
	 */
	private static byte[] createRoom(IncomeUserI user, PlayType playType) {
		if (BusSysModule.getInstance().isCloseCreateRoom()) {
			return MsgId.CreateRoomCm.gRErrMsg(NTxt.CREATE_ROOM_SERVER_FIXING);
		}
		if (RoomModule.getInstance().getRoom(user) != null) {
			return MsgId.CreateRoomCm
					.gRErrMsg(NTxt.CREATE_ROOM_ALREADY_IN_ROOM);
		}
		AreaType areaType = AreaType.getEnum(playType.getArea());
		if (areaType == null) {
			return MsgId.CreateRoomCm.gRErrMsg(NTxt.CREATE_ROOM_PTYPE_EMPTY);
		}
		PlayTypeSet playTypeSet = areaType.getPlayTypeSet(playType);
		if (playTypeSet == null) {
			return MsgId.CreateRoomCm.gRErrMsg(NTxt.PLAY_TYPE_SET_ERROR);
		}
		BankerMode bankerMode = BankerMode.getEnum(playType.getBankerMode());
		if (user.getDiamond() < bankerMode.getNeedDiamond()) {
			return MsgId.CreateRoomCm
					.gRErrMsg(NTxt.CREATE_ROOM_DIAMOND_NOT_ENOUGH);
		}
		try {
			RoomAbs room = createRoom(playType, user.getUid(), areaType,
					playTypeSet, JulebuRoom.getDefaultInstance(),
					SystemConstantsAbs.NoRoomId);
			byte[] code = room.joinRoom(user, false);
			if (code != null) {
				throw new Exception(String.format("房主加入失败!code:%s",
						NTxt.getCode(code)));
			}
			Seat seat = room.getSeat(user);
			CreateRoomSm.Builder createRoomSm = CreateRoomSm.newBuilder()
					.setCode(NTxt.SUCCESS).setChatRoomId(room.getImId())
					.setPlayType(room.getPlayType()).setRoomId(room.getIdStr());
			seat.setUserInfo(createRoomSm.getInfoBuilder());
			return createRoomSm.build().toByteArray();
		} catch (Exception e) {
			LoggerService.getRoomlogs().error(e.getMessage(), e);
			return MsgId.CreateRoomCm.gRErrMsg(NTxt.CREATE_ROOM_EXCEPTION);
		}
	}

	/**
	 * 公会创房
	 * 
	 * @param masterUser
	 *            会长
	 * @param julebuRoom
	 * @param playType
	 * @param playTypeSet
	 * @param areaType
	 * @return
	 */
	public static RoomAbs julebuCreateRoom(long masterId,
			JulebuRoom julebuRoom, PlayType playType, PlayTypeSet playTypeSet,
			AreaType areaType) {
		try {
			RoomAbs room = createRoom(playType, masterId, areaType,
					playTypeSet, julebuRoom, SystemConstantsAbs.NoRoomId);
			return room;
		} catch (Exception e) {
			LoggerService.getRoomlogs().error(e.getMessage(), e);
			return null;
		}
	}

	/**
	 * 重新加载房间数据
	 * 
	 * @param bean
	 * @return
	 * @throws Exception
	 */
	public static RoomAbs reloadRoom(RoomBean bean) throws Exception {
		ByteBuf in = Unpooled.buffer();
		in.writeBytes(bean.getBack());
		SerializeObj serializeObj = new SerializeObj(in);
		AreaType areaType = AreaType.getEnum(serializeObj.getPlayType()
				.getArea());
		PlayType playType = serializeObj.getPlayType();
		PlayTypeSet playTypeSet = areaType.getPlayTypeSet(playType);
		RoomAbs room = createRoom(playType, serializeObj.getMasterId(),
				areaType, playTypeSet, serializeObj.getJulebuRoom(),
				(int) bean.getId());
		room.setReload(true);
		room.gameRecordSm.mergeFrom(serializeObj.getGameRecordSm_byteArray());
		room.roundResultCast.mergeFrom(serializeObj
				.getRoundResultCast_byteArray());
		long[] uids = serializeObj.getUids();
		ByteBuf[] seats = serializeObj.getSeats();
		for (int index = 0; index < seats.length; index++) {
			long uid = uids[index];
			if (uid != SystemConstantsAbs.NoUid) {
				User user = UserManager.getInstance().reLoadUser(uid);
				room.joinRoom(user, false);
			}
			room.getSeats()[index].readExternal(seats[index]);
		}
		room.setStart(serializeObj.isStart());
		room.setRound(room.gameRecordSm.getRoundCount());
		BattleBackSm.Builder battleBackSm = BattleBackSm.newBuilder()
				.mergeFrom(serializeObj.getBattleBackSm_byteArray());
		if (room.isStart()) {
			room.setInitBanker(serializeObj.getInitBankerSeetIndex() != 0 ? null
					: room.getSeat(serializeObj.getInitBankerSeetIndex()));
			if (room.roundResultCast.getRsList().isEmpty()) {// 这一局还没有结束， 重新跑一下
				room.setSeatsGameState(GameState.prepared);
				room.setBankerSeat(room.getSeat(battleBackSm
						.getBankerSeetIndex()));
				room.nextRound(Arrays.asList(battleBackSm.getShaiziList(),
						battleBackSm.getFeiBao().getBaoPaiShaiziList()),
						serializeObj.getGenNoFengPais().isEmpty() ? null
								: serializeObj.getGenNoFengPais());
				for (int index = 0; index < battleBackSm.getOperaList().size(); index++) {
					SeetOpera opera = battleBackSm.getOperaList().get(index);
					Seat seat = room.getSeat(opera.getSIndex());
					switch (OperaType.getEnum(opera.getOpera())) {
					case baoTing:
						room.baoTing(seat, true);
						break;
					case notBaoTing:
						room.baoTing(seat, false);
						break;
					case zhuaPai:
						break;
					case ziMo:
						room.ziMoPai(seat);
						break;
					case anGang:
						room.anGangPai(seat, opera.getMj());
						break;
					case mingGang:
						room.mingGangPai(seat, opera.getMj());
						break;
					case daPai:
						room.daPai(seat, opera.getMj());
						break;
					case jiePao:
						room.jiePao(seat);
						break;
					case jieGang:
						room.jieGang(seat);
						break;
					case pengPai:
						room.pengPai(seat);
						break;
					case chiPai:
						room.chiPai(seat, opera.getChi());
						break;
					case jiePaoJieGangPengChiGuo:
						room.over(seat);
						break;
					case qiangGangHu:
						room.qiangGang(seat);
						break;
					case qiangGangGuo:
						room.over(seat);
						break;
					case jieGangCast:
						break;
					case pengPaiCast:
						break;
					case chiPaiCast:
						break;
					default:
						break;
					}
				}
			} else {
				room.setSeatsGameState(GameState.noStart);
			}
		}
		room.checkAllOffLine();
		if (room.isBelongGuild()) {
			GuildManager.getInstance().getAndReloadGuild(room.getGuildId())
					.set(room.getNum(), room.getId());
		}
		room.setReload(false);
		return room;
	}

	public static byte[] battleBack(IncomeUserI user,
			BattleBackCm genMessageLite) {
		int id = genMessageLite.getId();
		try {
			return BattlebackDao.queryRecord(id).getData();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static byte[] prepareRoom(IncomeUserI user,
			PrepareRoomCm genMessageLite) {
		if (user.sendCacheGameOverCast()) {
			return MsgId.PrepareRoomCm.gRErrMsg(NTxt.GAME_OVER);
		} else {
			RoomAbs room = RoomModule.getInstance().getRoom(user);
			if (room == null) {
				return MsgId.PrepareRoomCm.gRErrMsg(NTxt.NOT_FOUND_ROOM);
			}
			Seat seat = room.getSeat(user);
			if (seat == null) {
				return MsgId.PrepareRoomCm.gRErrMsg(NTxt.NOT_FOUND_SEAT);
			}
			room.prepareRoom(seat);
			return null;
		}
	}
}
