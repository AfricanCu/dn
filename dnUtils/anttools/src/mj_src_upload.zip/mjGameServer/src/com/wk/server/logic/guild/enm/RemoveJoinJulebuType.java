package com.wk.server.logic.guild.enm;

//1拒绝加入 2踢出 3解散
public enum RemoveJoinJulebuType {
	disagreeJoin(1), kick(2), dissolve(3), quit(4);
	private final int type;

	private RemoveJoinJulebuType(int type) {
		this.type = type;
	}

	public int getType() {
		return type;
	}

}
