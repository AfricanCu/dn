package com.wk.logic.enm;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.HashMap;
import java.util.Map;

import test.client.util.NoticeTextTemplate;

import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.MessageLite;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.engine.config.SystemConstants;
import com.wk.engine.net.IoMessage;
import com.wk.engine.net.I.MsgIdI;
import com.wk.engine.util.ProtobufUtils;

public enum MsgId implements MsgIdI {
	// 自动生成开始
/**桌子详情返回 1548**/
TableDetailSm(1548,"桌子详情返回",msg.GuildMessage.TableDetailSm.getDefaultInstance(),null,250),
/**桌子详情请求 1547**/
TableDetailCm(1547,"桌子详情请求",msg.GuildMessage.TableDetailCm.getDefaultInstance(),TableDetailSm,250),
/**搜索成员返回 1546**/
SearchMemberSm(1546,"搜索成员返回",msg.GuildMessage.SearchMemberSm.getDefaultInstance(),null,250),
/**搜索成员请求 1545**/
SearchMemberCm(1545,"搜索成员请求",msg.GuildMessage.SearchMemberCm.getDefaultInstance(),SearchMemberSm,250),
/**清除大赢家返回 1544**/
ClearWinnerSm(1544,"清除大赢家返回",msg.GuildMessage.ClearWinnerSm.getDefaultInstance(),null,250),
/**清除大赢家请求 1543**/
ClearWinnerCm(1543,"清除大赢家请求",msg.GuildMessage.ClearWinnerCm.getDefaultInstance(),ClearWinnerSm,250),
/**大赢家列表返回 1542**/
WinnerSm(1542,"大赢家列表返回",msg.GuildMessage.WinnerSm.getDefaultInstance(),null,250),
/**大赢家列表请求 1541**/
WinnerCm(1541,"大赢家列表请求",msg.GuildMessage.WinnerCm.getDefaultInstance(),WinnerSm,250),
/**俱乐部游戏记录返回 1540**/
JulebuRecordSm(1540,"俱乐部游戏记录返回",msg.GuildMessage.JulebuRecordSm.getDefaultInstance(),null,250),
/**俱乐部游戏记录请求 1539**/
JulebuRecordCm(1539,"俱乐部游戏记录请求",msg.GuildMessage.JulebuRecordCm.getDefaultInstance(),JulebuRecordSm,250),
/**晋升成员返回 1537**/
LevelupMemberSm(1537,"晋升成员返回",msg.GuildMessage.LevelupMemberSm.getDefaultInstance(),null,250),
/**晋升成员请求 1536**/
LevelupMemberCm(1536,"晋升成员请求",msg.GuildMessage.LevelupMemberCm.getDefaultInstance(),LevelupMemberSm,250),
/**踢俱乐部成员返回 1535**/
KickJulebuMemberSm(1535,"踢俱乐部成员返回",msg.GuildMessage.KickJulebuMemberSm.getDefaultInstance(),null,250),
/**踢俱乐部成员请求 1534**/
KickJulebuMemberCm(1534,"踢俱乐部成员请求",msg.GuildMessage.KickJulebuMemberCm.getDefaultInstance(),KickJulebuMemberSm,250),
/**成员列表返回 1533**/
JulebuMemberListSm(1533,"成员列表返回",msg.GuildMessage.JulebuMemberListSm.getDefaultInstance(),null,250),
/**成员列表请求 1532**/
JulebuMemberListCm(1532,"成员列表请求",msg.GuildMessage.JulebuMemberListCm.getDefaultInstance(),JulebuMemberListSm,250),
/**拒绝加入返回 1531**/
DisagreeApplySm(1531,"拒绝加入返回",msg.GuildMessage.DisagreeApplySm.getDefaultInstance(),null,250),
/**拒绝加入请求 1530**/
DisagreeApplyCm(1530,"拒绝加入请求",msg.GuildMessage.DisagreeApplyCm.getDefaultInstance(),DisagreeApplySm,250),
/**同意加入返回 1529**/
AgreeApplySm(1529,"同意加入返回",msg.GuildMessage.AgreeApplySm.getDefaultInstance(),null,250),
/**同意加入请求 1528**/
AgreeApplyCm(1528,"同意加入请求",msg.GuildMessage.AgreeApplyCm.getDefaultInstance(),AgreeApplySm,250),
/**申请人列表返回 1527**/
ApplyMemberListSm(1527,"申请人列表返回",msg.GuildMessage.ApplyMemberListSm.getDefaultInstance(),null,250),
/**申请人列表请求 1526**/
ApplyMemberListCm(1526,"申请人列表请求",msg.GuildMessage.ApplyMemberListCm.getDefaultInstance(),ApplyMemberListSm,250),
/**申请加入俱乐部返回 1525**/
ApplyJulebuSm(1525,"申请加入俱乐部返回",msg.GuildMessage.ApplyJulebuSm.getDefaultInstance(),null,250),
/**申请加入俱乐部请求 1524**/
ApplyJulebuCm(1524,"申请加入俱乐部请求",msg.GuildMessage.ApplyJulebuCm.getDefaultInstance(),ApplyJulebuSm,250),
/**俱乐部大厅桌子信息返回 1523**/
TableInfoSm(1523,"俱乐部大厅桌子信息返回",msg.GuildMessage.TableInfoSm.getDefaultInstance(),null,250),
/**俱乐部大厅桌子信息请求 1522**/
TableInfoCm(1522,"俱乐部大厅桌子信息请求",msg.GuildMessage.TableInfoCm.getDefaultInstance(),TableInfoSm,250),
/**退出俱乐部返回 1521**/
QuitJulebuSm(1521,"退出俱乐部返回",msg.GuildMessage.QuitJulebuSm.getDefaultInstance(),null,250),
/**退出俱乐部请求 1520**/
QuitJulebuCm(1520,"退出俱乐部请求",msg.GuildMessage.QuitJulebuCm.getDefaultInstance(),QuitJulebuSm,250),
/**进入俱乐部大厅返回 1519**/
InJulebuSm(1519,"进入俱乐部大厅返回",msg.GuildMessage.InJulebuSm.getDefaultInstance(),null,250),
/**进入俱乐部大厅请求 1518**/
InJulebuCm(1518,"进入俱乐部大厅请求",msg.GuildMessage.InJulebuCm.getDefaultInstance(),InJulebuSm,250),
/**进入俱乐部大厅预处理返回 1517**/
InJulebuBeforeSm(1517,"进入俱乐部大厅预处理返回",msg.GuildMessage.InJulebuBeforeSm.getDefaultInstance(),null,250),
/**进入俱乐部大厅预处理请求 1516**/
InJulebuBeforeCm(1516,"进入俱乐部大厅预处理请求",msg.GuildMessage.InJulebuBeforeCm.getDefaultInstance(),InJulebuBeforeSm,250),
/**解散俱乐部返回 1515**/
DissolveJulebuSm(1515,"解散俱乐部返回",msg.GuildMessage.DissolveJulebuSm.getDefaultInstance(),null,250),
/**解散俱乐部请求 1514**/
DissolveJulebuCm(1514,"解散俱乐部请求",msg.GuildMessage.DissolveJulebuCm.getDefaultInstance(),DissolveJulebuSm,250),
/**其他设置返回 1513**/
OtherSetSm(1513,"其他设置返回",msg.GuildMessage.OtherSetSm.getDefaultInstance(),null,250),
/**其他设置请求 1512**/
OtherSetCm(1512,"其他设置请求",msg.GuildMessage.OtherSetCm.getDefaultInstance(),OtherSetSm,250),
/**玩法设置返回 1511**/
PlaySetSm(1511,"玩法设置返回",msg.GuildMessage.PlaySetSm.getDefaultInstance(),null,250),
/**玩法设置请求 1510**/
PlaySetCm(1510,"玩法设置请求",msg.GuildMessage.PlaySetCm.getDefaultInstance(),PlaySetSm,250),
/**信息设置返回 1509**/
InfoSetSm(1509,"信息设置返回",msg.GuildMessage.InfoSetSm.getDefaultInstance(),null,250),
/**信息设置请求 1508**/
InfoSetCm(1508,"信息设置请求",msg.GuildMessage.InfoSetCm.getDefaultInstance(),InfoSetSm,250),
/**创建俱乐部返回 1507**/
CreateJulebuSm(1507,"创建俱乐部返回",msg.GuildMessage.CreateJulebuSm.getDefaultInstance(),null,250),
/**创建俱乐部请求 1506**/
CreateJulebuCm(1506,"创建俱乐部请求",msg.GuildMessage.CreateJulebuCm.getDefaultInstance(),CreateJulebuSm,250),
/**创建俱乐部预处理返回 1505**/
CreateJulebuBeforeSm(1505,"创建俱乐部预处理返回",msg.GuildMessage.CreateJulebuBeforeSm.getDefaultInstance(),null,250),
/**创建俱乐部预处理请求 1504**/
CreateJulebuBeforeCm(1504,"创建俱乐部预处理请求",msg.GuildMessage.CreateJulebuBeforeCm.getDefaultInstance(),CreateJulebuBeforeSm,250),
/**更新俱乐部广播 1502**/
UpdateJulebuCast(1502,"更新俱乐部广播",msg.GuildMessage.UpdateJulebuCast.getDefaultInstance(),null,250),
/**删除俱乐部广播 1501**/
DelJulebuCast(1501,"删除俱乐部广播",msg.GuildMessage.DelJulebuCast.getDefaultInstance(),null,250),
/**加俱乐部广播 1500**/
AddJulebuCast(1500,"加俱乐部广播",msg.GuildMessage.AddJulebuCast.getDefaultInstance(),null,250),
/**吃牌广播 840**/
ChiPaiCast(840,"吃牌广播",msg.MjMessage.ChiPaiCast.getDefaultInstance(),null,250),
/**吃牌返回 839**/
ChiPaiSm(839,"吃牌返回",msg.MjMessage.ChiPaiSm.getDefaultInstance(),null,250),
/**吃牌请求 838**/
ChiPaiCm(838,"吃牌请求",msg.MjMessage.ChiPaiCm.getDefaultInstance(),ChiPaiSm,250),
/**战斗回放返回 837**/
BattleBackSm(837,"战斗回放返回",msg.BackMessage.BattleBackSm.getDefaultInstance(),null,250),
/**战斗回放请求 836**/
BattleBackCm(836,"战斗回放请求",msg.BackMessage.BattleBackCm.getDefaultInstance(),BattleBackSm,250),
/**海底自动操作广播 835**/
HaiDiZhuaPaiCast(835,"海底自动操作广播",msg.MjMessage.HaiDiZhuaPaiCast.getDefaultInstance(),null,250),
/**抢杠返回 834**/
QiangGangSm(834,"抢杠返回",msg.MjMessage.QiangGangSm.getDefaultInstance(),null,250),
/**抢杠请求 833**/
QiangGangCm(833,"抢杠请求",msg.MjMessage.QiangGangCm.getDefaultInstance(),QiangGangSm,250),
/**过返回 832**/
OverSm(832,"过返回",msg.MjMessage.OverSm.getDefaultInstance(),null,250),
/**过请求 831**/
OverCm(831,"过请求",msg.MjMessage.OverCm.getDefaultInstance(),OverSm,250),
/**报听抓牌打牌广播 830**/
BaoTingZhuaDaPaiCast(830,"报听抓牌打牌广播",msg.MjMessage.BaoTingZhuaDaPaiCast.getDefaultInstance(),null,250),
/**报听自动操作广播 829**/
BaoTingAutoCast(829,"报听自动操作广播",msg.MjMessage.BaoTingAutoCast.getDefaultInstance(),null,250),
/**断线重连返回 828**/
ReconnectSm(828,"断线重连返回",msg.MjMessage.ReconnectSm.getDefaultInstance(),null,250),
/**断线重连请求 827**/
ReconnectCm(827,"断线重连请求",msg.MjMessage.ReconnectCm.getDefaultInstance(),ReconnectSm,250),
/**游戏结束 826**/
GameOverCast(826,"游戏结束",msg.MjMessage.GameOverCast.getDefaultInstance(),null,250),
/**局结算广播 825**/
RoundResultCast(825,"局结算广播",msg.MjMessage.RoundResultCast.getDefaultInstance(),null,250),
/**碰牌广播 824**/
PengPaiCast(824,"碰牌广播",msg.MjMessage.PengPaiCast.getDefaultInstance(),null,250),
/**碰牌返回 823**/
PengPaiSm(823,"碰牌返回",msg.MjMessage.PengPaiSm.getDefaultInstance(),null,250),
/**碰牌请求 822**/
PengPaiCm(822,"碰牌请求",msg.MjMessage.PengPaiCm.getDefaultInstance(),PengPaiSm,250),
/**接杠广播 821**/
JieGangCast(821,"接杠广播",msg.MjMessage.JieGangCast.getDefaultInstance(),null,250),
/**接杠返回 820**/
JieGangSm(820,"接杠返回",msg.MjMessage.JieGangSm.getDefaultInstance(),null,250),
/**接杠请求 819**/
JieGangCm(819,"接杠请求",msg.MjMessage.JieGangCm.getDefaultInstance(),JieGangSm,250),
/**接炮返回 818**/
JiePaoSm(818,"接炮返回",msg.MjMessage.JiePaoSm.getDefaultInstance(),null,250),
/**接炮请求 817**/
JiePaoCm(817,"接炮请求",msg.MjMessage.JiePaoCm.getDefaultInstance(),JiePaoSm,250),
/**打牌广播 816**/
DaPaiCast(816,"打牌广播",msg.MjMessage.DaPaiCast.getDefaultInstance(),null,250),
/**打牌返回 815**/
DaPaiSm(815,"打牌返回",msg.MjMessage.DaPaiSm.getDefaultInstance(),null,250),
/**打牌请求 814**/
DaPaiCm(814,"打牌请求",msg.MjMessage.DaPaiCm.getDefaultInstance(),DaPaiSm,250),
/**明杠牌广播 813**/
MingGangPaiCast(813,"明杠牌广播",msg.MjMessage.MingGangPaiCast.getDefaultInstance(),null,250),
/**明杠牌返回 812**/
MingGangPaiSm(812,"明杠牌返回",msg.MjMessage.MingGangPaiSm.getDefaultInstance(),null,250),
/**明杠牌请求 811**/
MingGangPaiCm(811,"明杠牌请求",msg.MjMessage.MingGangPaiCm.getDefaultInstance(),MingGangPaiSm,250),
/**暗杠牌广播 810**/
AnGangPaiCast(810,"暗杠牌广播",msg.MjMessage.AnGangPaiCast.getDefaultInstance(),null,250),
/**暗杠牌返回 809**/
AnGangPaiSm(809,"暗杠牌返回",msg.MjMessage.AnGangPaiSm.getDefaultInstance(),null,250),
/**暗杠牌请求 808**/
AnGangPaiCm(808,"暗杠牌请求",msg.MjMessage.AnGangPaiCm.getDefaultInstance(),AnGangPaiSm,250),
/**自摸牌返回 807**/
ZiMoPaiSm(807,"自摸牌返回",msg.MjMessage.ZiMoPaiSm.getDefaultInstance(),null,250),
/**自摸牌请求 806**/
ZiMoPaiCm(806,"自摸牌请求",msg.MjMessage.ZiMoPaiCm.getDefaultInstance(),ZiMoPaiSm,250),
/**谁抓牌广播 805**/
SeetZhuaPaiCast(805,"谁抓牌广播",msg.MjMessage.SeetZhuaPaiCast.getDefaultInstance(),null,250),
/**抓牌推送 804**/
ZhuaPaiCast(804,"抓牌推送",msg.MjMessage.ZhuaPaiCast.getDefaultInstance(),null,250),
/**报听广播 803**/
BaoTingCast(803,"报听广播",msg.MjMessage.BaoTingCast.getDefaultInstance(),null,250),
/**报听返回 802**/
BaoTingSm(802,"报听返回",msg.MjMessage.BaoTingSm.getDefaultInstance(),null,250),
/**报听请求 801**/
BaoTingCm(801,"报听请求",msg.MjMessage.BaoTingCm.getDefaultInstance(),BaoTingSm,250),
/**发牌推送 800**/
FaPaiCast(800,"发牌推送",msg.MjMessage.FaPaiCast.getDefaultInstance(),null,250),
/**玩家解散房间广播 502**/
MemberDissolveRoomCast(502,"玩家解散房间广播",msg.RoomMessage.MemberDissolveRoomCast.getDefaultInstance(),null,0),
/**玩家解散房间返回 501**/
MemberDissolveRoomSm(501,"玩家解散房间返回",msg.RoomMessage.MemberDissolveRoomSm.getDefaultInstance(),null,0),
/**玩家解散房间请求 500**/
MemberDissolveRoomCm(500,"玩家解散房间请求",msg.RoomMessage.MemberDissolveRoomCm.getDefaultInstance(),MemberDissolveRoomSm,250),
/**经纬广播 239**/
NsCast(239,"经纬广播",msg.RoomMessage.NsCast.getDefaultInstance(),null,0),
/**经纬返回 238**/
NsSm(238,"经纬返回",msg.RoomMessage.NsSm.getDefaultInstance(),null,0),
/**经纬请求 237**/
NsCm(237,"经纬请求",msg.RoomMessage.NsCm.getDefaultInstance(),NsSm,250),
/**代理创建房间预处理返回 236**/
ProxyCreateRoomBeforeSm(236,"代理创建房间预处理返回",msg.RoomMessage.ProxyCreateRoomBeforeSm.getDefaultInstance(),null,0),
/**代理创建房间预处理请求 235**/
ProxyCreateRoomBeforeCm(235,"代理创建房间预处理请求",msg.RoomMessage.ProxyCreateRoomBeforeCm.getDefaultInstance(),ProxyCreateRoomBeforeSm,250),
/**房主创建房间预处理返回 234**/
CreateRoomBeforeSm(234,"房主创建房间预处理返回",msg.RoomMessage.CreateRoomBeforeSm.getDefaultInstance(),null,0),
/**房主创建房间预处理请求 233**/
CreateRoomBeforeCm(233,"房主创建房间预处理请求",msg.RoomMessage.CreateRoomBeforeCm.getDefaultInstance(),CreateRoomBeforeSm,250),
/**代解散房返回 232**/
ProxyRoomsDissovleSm(232,"代解散房返回",msg.RoomMessage.ProxyRoomsDissovleSm.getDefaultInstance(),null,0),
/**代解散房请求 231**/
ProxyRoomsDissovleCm(231,"代解散房请求",msg.RoomMessage.ProxyRoomsDissovleCm.getDefaultInstance(),ProxyRoomsDissovleSm,250),
/**房间状态改变推送 230**/
ProxyRoomsUpdateCast(230,"房间状态改变推送",msg.RoomMessage.ProxyRoomsUpdateCast.getDefaultInstance(),null,0),
/**解散房间推送 229**/
ProxyRoomsDelCast(229,"解散房间推送",msg.RoomMessage.ProxyRoomsDelCast.getDefaultInstance(),null,0),
/**增加房间推送 228**/
ProxyRoomsAddCast(228,"增加房间推送",msg.RoomMessage.ProxyRoomsAddCast.getDefaultInstance(),null,0),
/**房间列表推送 227**/
ProxyRoomsCast(227,"房间列表推送",msg.RoomMessage.ProxyRoomsCast.getDefaultInstance(),null,0),
/**代开房返回 226**/
ProxyCreateRoomSm(226,"代开房返回",msg.RoomMessage.ProxyCreateRoomSm.getDefaultInstance(),null,0),
/**代开房请求 225**/
ProxyCreateRoomCm(225,"代开房请求",msg.RoomMessage.ProxyCreateRoomCm.getDefaultInstance(),ProxyCreateRoomSm,250),
/**语音广播 224**/
ImCast(224,"语音广播",msg.RoomMessage.ImCast.getDefaultInstance(),null,0),
/**语音返回 223**/
ImSm(223,"语音返回",msg.RoomMessage.ImSm.getDefaultInstance(),null,0),
/**语音请求 222**/
ImCm(222,"语音请求",msg.RoomMessage.ImCm.getDefaultInstance(),ImSm,250),
/**聊天广播 221**/
ChatCast(221,"聊天广播",msg.RoomMessage.ChatCast.getDefaultInstance(),null,0),
/**聊天返回 220**/
ChatSm(220,"聊天返回",msg.RoomMessage.ChatSm.getDefaultInstance(),null,0),
/**聊天请求 219**/
ChatCm(219,"聊天请求",msg.RoomMessage.ChatCm.getDefaultInstance(),ChatSm,250),
/**解散房间广播 218**/
DissolveRoomCast(218,"解散房间广播",msg.RoomMessage.DissolveRoomCast.getDefaultInstance(),null,250),
/**语音房间信息保存广播 217**/
ImInfoSaveCast(217,"语音房间信息保存广播",msg.RoomMessage.ImInfoSaveCast.getDefaultInstance(),null,0),
/**语音房间信息保存返回 216**/
ImInfoSaveSm(216,"语音房间信息保存返回",msg.RoomMessage.ImInfoSaveSm.getDefaultInstance(),null,0),
/**语音房间信息保存请求 215**/
ImInfoSaveCm(215,"语音房间信息保存请求",msg.RoomMessage.ImInfoSaveCm.getDefaultInstance(),ImInfoSaveSm,250),
/**断线广播 214**/
OfflineCast(214,"断线广播",msg.RoomMessage.OfflineCast.getDefaultInstance(),null,0),
/**准备广播 213**/
PrepareRoomCast(213,"准备广播",msg.RoomMessage.PrepareRoomCast.getDefaultInstance(),null,0),
/**准备返回 212**/
PrepareRoomSm(212,"准备返回",msg.RoomMessage.PrepareRoomSm.getDefaultInstance(),null,0),
/**准备请求 211**/
PrepareRoomCm(211,"准备请求",msg.RoomMessage.PrepareRoomCm.getDefaultInstance(),PrepareRoomSm,250),
/**解散房间返回 210**/
DissolveRoomSm(210,"解散房间返回",msg.RoomMessage.DissolveRoomSm.getDefaultInstance(),null,0),
/**解散房间请求 209**/
DissolveRoomCm(209,"解散房间请求",msg.RoomMessage.DissolveRoomCm.getDefaultInstance(),DissolveRoomSm,250),
/**离开房间返回 208**/
LeaveRoomSm(208,"离开房间返回",msg.RoomMessage.LeaveRoomSm.getDefaultInstance(),null,0),
/**离开房间请求 207**/
LeaveRoomCm(207,"离开房间请求",msg.RoomMessage.LeaveRoomCm.getDefaultInstance(),LeaveRoomSm,250),
/**房间加入推送 206**/
JoinRoomCast(206,"房间加入推送",msg.RoomMessage.JoinRoomCast.getDefaultInstance(),null,0),
/**加入房间返回 205**/
JoinRoomSm(205,"加入房间返回",msg.RoomMessage.JoinRoomSm.getDefaultInstance(),null,0),
/**加入房间请求 204**/
JoinRoomCm(204,"加入房间请求",msg.RoomMessage.JoinRoomCm.getDefaultInstance(),JoinRoomSm,250),
/**房主加入房间预处理返回 203**/
JoinRoomBeforeSm(203,"房主加入房间预处理返回",msg.RoomMessage.JoinRoomBeforeSm.getDefaultInstance(),null,0),
/**房主加入房间预处理请求 202**/
JoinRoomBeforeCm(202,"房主加入房间预处理请求",msg.RoomMessage.JoinRoomBeforeCm.getDefaultInstance(),JoinRoomBeforeSm,250),
/**房主创建房间返回 201**/
CreateRoomSm(201,"房主创建房间返回",msg.RoomMessage.CreateRoomSm.getDefaultInstance(),null,0),
/**房主创建房间请求 200**/
CreateRoomCm(200,"房主创建房间请求",msg.RoomMessage.CreateRoomCm.getDefaultInstance(),CreateRoomSm,250),
/**proxy游戏记录返回 11**/
ProxyRecordCast(11,"proxy游戏记录返回",msg.LoginMessage.ProxyRecordCast.getDefaultInstance(),null,250),
/**游戏记录返回 10**/
GameRecordSm(10,"游戏记录返回",msg.LoginMessage.GameRecordSm.getDefaultInstance(),null,250),
/**游戏记录请求 9**/
GameRecordCm(9,"游戏记录请求",msg.LoginMessage.GameRecordCm.getDefaultInstance(),GameRecordSm,250),
/**充值成功推送 8**/
ChargeCast(8,"充值成功推送",msg.LoginMessage.ChargeCast.getDefaultInstance(),null,250),
/**记录推送 7**/
PlayerRecordCast(7,"记录推送",msg.LoginMessage.PlayerRecordCast.getDefaultInstance(),null,250),
/**个人信息推送 6**/
PlayerCast(6,"个人信息推送",msg.LoginMessage.PlayerCast.getDefaultInstance(),null,250),
/**切服登录返回 4**/
SwLoginSm(4,"切服登录返回",msg.LoginMessage.SwLoginSm.getDefaultInstance(),null,0),
/**切服登录请求 3**/
SwLoginCm(3,"切服登录请求",msg.LoginMessage.SwLoginCm.getDefaultInstance(),SwLoginSm,250),
/**返回登录 2**/
LoginSm(2,"返回登录",msg.LoginMessage.LoginSm.getDefaultInstance(),null,0),
/**请求登录 1**/
LoginCm(1,"请求登录",msg.LoginMessage.LoginCm.getDefaultInstance(),LoginSm,250),
// 自动生成结束
	/** 心跳挂起10分钟请求 -4 **/
	HeartPause(-4, "心跳挂起10分钟请求", null, null, 10000),
	/** 心跳挂起10分钟恢复 -5 **/
	HeartResume(-5, "心跳挂起10分钟恢复", null, null, 10000), ;
	;
	private final short type;
	private final String name;
	/** 消息默认实例 */
	private final MessageLite defaultInst;
	private final MsgId resMsgId;
	/** 消息发送间隔限制 单位（毫秒） */
	private final long period;
	/** setCode方法，返回消息都要求有这个方法 */
	private Method setCodeMethod;
	/** 缓存错误返回消息 **/
	private final HashMap<Integer, byte[]> errorResCacheMap = new HashMap<Integer, byte[]>(
			0);

	private MsgId(int type, String name, MessageLite clazz, MsgId resMsgId,
			long period) {
		this.type = (short) type;
		this.name = name;
		this.defaultInst = clazz;
		this.resMsgId = resMsgId;
		this.period = period;
		if (this.resMsgId != null
				&& !SystemConstants.exceptNameList.contains(this.resMsgId
						.name())) {
			Class<? extends MessageLite.Builder> clazs = this.resMsgId
					.genMessageLiteBuilder().getClass();
			Class<? extends MessageLite> liteClazs = this.resMsgId.defaultInst
					.getClass();
			try {
				this.setCodeMethod = clazs.getMethod("setCode", int.class);
				Field field = liteClazs.getField("CODE_FIELD_NUMBER");
				int CODE_FIELD_NUMBER = field.getInt(this.defaultInst);
				if (CODE_FIELD_NUMBER != 1) {
					throw new IllegalArgumentException(
							"消息返回code字段下标错误！!=1 CODE_FIELD_NUMBER="
									+ CODE_FIELD_NUMBER);
				}
			} catch (NoSuchMethodException | SecurityException
					| NoSuchFieldException | IllegalArgumentException
					| IllegalAccessException e) {
				LoggerService.getPlatformLog().error(e.getMessage(), e);
			}
		} else {
			this.setCodeMethod = null;
		}
	}

	public short getType() {
		return type;
	}

	public long getPeriod() {
		return period;
	}

	public String getName() {
		return name;
	}

	public MessageLite getDefaultInst() {
		return defaultInst;
	}

	/**
	 * 生成proto builder
	 */
	public MessageLite.Builder genMessageLiteBuilder() {
		return defaultInst.newBuilderForType();
	}

	public MsgId getResMsgId() {
		return resMsgId;
	}

	public Method getSetCodeMethod() {
		return setCodeMethod;
	}

	public byte[] gRErrMsg(int code) {
		byte[] bs = this.errorResCacheMap.get(code);
		if (bs == null) {
			MessageLite.Builder liteorBuilder = this.resMsgId
					.genMessageLiteBuilder();
			try {
				setCodeMethod.invoke(liteorBuilder, code);
			} catch (IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				LoggerService.getPlatformLog().error(e.getMessage(), e);
			}
			bs = liteorBuilder.build().toByteArray();
			this.errorResCacheMap.put(code, bs);
		}
		String format = String.format("%s,消息:%s,%s,error:%s,code:%s",
				new Exception().getStackTrace()[1], this.name, this.name(),
				NoticeTextTemplate.getNoticeText(code), code);
		LoggerService.getLogicLog().error(format);
		System.err.println(format);
		return bs;
	}

	public static MessageLite getMessageLite(IoMessage message)
			throws InvalidProtocolBufferException {
		return ProtobufUtils.getProtobuf(message.getMsg(), message.getMsgId()
				.getDefaultInst());
	}

	private final static Map<Short, MsgId> typeMap = new HashMap<>();
	static {
		MsgId[] missionStateArr = MsgId.values();
		for (int i = 0; i < missionStateArr.length; i++) {
			MsgId missionState = missionStateArr[i];
			typeMap.put(missionState.getType(), missionState);
		}
	}

	/**
	 *
	 * @param type
	 * @return
	 */
	public static MsgId getEnum(short type) {
		return typeMap.get(type);
	}

}
