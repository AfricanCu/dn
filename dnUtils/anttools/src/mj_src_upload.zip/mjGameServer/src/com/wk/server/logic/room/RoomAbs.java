package com.wk.server.logic.room;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import msg.MjMessage.BaoTingCast;
import msg.MjMessage.FeiBao;
import msg.MjMessage.Mj;
import msg.MjMessage.ReconnectCm;
import msg.MjMessage.ReconnectSm;
import msg.RoomMessage.JulebuRoom;
import msg.RoomMessage.PlayType;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.SystemConstantsAbs;
import com.wk.engine.config.SystemConstants;
import com.wk.enun.UserState;
import com.wk.logic.area.AreaType;
import com.wk.logic.config.DissolveRoomType;
import com.wk.logic.config.NTxt;
import com.wk.logic.config.TimeConfig;
import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MsgId;
import com.wk.mj.GpcCache;
import com.wk.mj.MjTools;
import com.wk.mj.Pai;
import com.wk.mj.Ting;
import com.wk.mj.enun.AfterOtherDaPaiType;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.GetHuPaiType;
import com.wk.mj.enun.HuPaiType;
import com.wk.mj.enun.OperaType;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.ZhaNiaoType;
import com.wk.server.ibatis.select.IncomeUserI;
import com.wk.util.TimeTaskUtil;

/**
 * 房间抽象类
 * 
 * @author ems
 *
 */
public abstract class RoomAbs extends RoomRecord {
	/** 杠类型 */
	public enum GangType {
		JieGang, MingGang, AnGang,
	}

	// ///////////每一局缓存/////////////////
	/** 谁胡牌 */
	private final List<Seat> huPaiList = new ArrayList<>();
	/** 怎么胡的牌 */
	private GetHuPaiType getHuPaiType;
	/** 抓的鸟牌 */
	private final List<Pai> niaoPaiList = new ArrayList<>();
	/** 谁放炮临时 */
	private Seat fangPaoSeatTmp;
	/** 谁放炮 */
	private Seat fangPaoSeat;
	/** 胡牌 */
	private Pai huPai;
	/** 打牌的人 */
	private Seat haveDaPaiSeat;
	/** 哪个能吃，在打牌的时候缓存和清除 */
	private Seat chiPaiSeat;
	/** 怎么吃，选择吃时缓存 **/
	private ChiType chi;
	/** 哪个能碰，在打牌的时候缓存和清除 */
	private Seat pengPaiSeat;
	/** 哪个能接杠，在打牌的时候缓存和清除 */
	private Seat jieGangSeat;
	/** 哪几个能接炮，在打牌的时候缓存和清除 */
	private final List<Seat> jiePaoSeatList = new ArrayList<>();
	/** 可以报听列表 */
	private final List<Seat> baoTingSeatList = new ArrayList<>();
	/** 可以抢杠列表 */
	private final List<Seat> qiangGangSeatList = new ArrayList<>();
	/** 最近杠类型和杠的座位 */
	private GangType gangType;
	private Seat haveGangSeat;
	/** 最近一个抓牌的位置 */
	private Seat lastZhuaPaiSeat;
	/** 初始化庄家 **/
	private Seat initBanker;

	public RoomAbs(AreaType pType) {
		super(pType);
		for (int index = 0; index < this.seats.length; index++) {
			this.seats[index] = new Seat(this, index + 1, index);
		}
	}

	/**
	 * 房间初始化
	 * 
	 * @param playType
	 *            玩法
	 * @param masterId
	 *            房主ID
	 * @param julebuRoom
	 *            俱乐部房间信息
	 * @param id
	 *            房间ID
	 * @throws Exception
	 */
	public void init(PlayType playType, PlayTypeSet playTypeSet, long masterId,
			JulebuRoom julebuRoom, int id) throws Exception {
		super.init(playType, playTypeSet, masterId, julebuRoom, id);
		this.initEx();
		for (Seat seat : this.seats) {
			seat.init(this.getPlayTypeSet());
		}
		this.setInit(true);
	}

	/**
	 * 初始化扩展
	 * 
	 * @throws Exception
	 */
	public abstract void initEx() throws Exception;

	/** 下个坐庄 */
	public void nextBanker() {
		this.setInitBanker(this.initBanker == null ? this.initBanker()
				: this.initBanker);
		this.setBankerSeat(this.initBanker);
		if (this.getRound() >= this.getBankerMode().getNum()) {
			this.dissolveRoom(DissolveRoomType.GAME_OVER_NO_NEXT_BANKER);
		} else {
			this.nextRound(this.genShaiZi(), null);
		}
	}

	public void setInitBanker(Seat initBanker) {
		this.initBanker = initBanker;
	}

	public Seat getInitBanker() {
		return initBanker;
	}

	/** 初始化每一局的庄家 **/
	private Seat initBanker() {
		if (this.getRound() == 0) {
			return this.getDefaultBankerSeat();
		} else if (this.getHuPaiType != null) {
			switch (this.getHuPaiType) {
			case ziMo:
				return this.huPaiList.get(0);
			case jiePao:
			case qiangGang:
				if (this.huPaiList.size() == 1) {
					return this.huPaiList.get(0);
				} else {
					return this.fangPaoSeat;
				}
			default:
				LoggerService.getLogicLog().error("未实现下一个庄家!");
				return this.getDefaultBankerSeat();
			}
		} else {
			return this.lastZhuaPaiSeat;
		}
	}

	public List<Seat> getBaoTingSeatList() {
		return baoTingSeatList;
	}

	/**
	 * 是否有人可报听？
	 * 
	 * @return
	 */
	public boolean isHasBaoTing() {
		return !this.baoTingSeatList.isEmpty();
	}

	public List<Seat> getQiangGangSeatList() {
		return qiangGangSeatList;
	}

	public boolean isHasQiangGang() {
		return !this.qiangGangSeatList.isEmpty();
	}

	/**
	 * 打牌位置
	 * 
	 * @return
	 */
	public Seat getHaveDaPaiSeat() {
		return haveDaPaiSeat;
	}

	/**
	 * 打的牌
	 * 
	 * @return
	 */
	public Pai getHaveDaPai() {
		return haveDaPaiSeat.getHaveDaPai();
	}

	/** 自摸的座位中了几个鸟 */
	public int getZiMoHuPaiSeatNiaoNumber() {
		if (getHuPaiType == GetHuPaiType.ziMo) {
			return this.huPaiList.get(0).getNiaoNumber();
		}
		return 0;
	}

	/** 胡牌座位番数 */
	public int getHuPaiSeatFan() {
		if (getHuPaiType == GetHuPaiType.ziMo) {
			return this.huPaiList.get(0).getHuPaiFan();
		}
		int fan = 0;
		for (Seat st : this.huPaiList) {
			fan += st.getHuPaiFan();
		}
		return fan;
	}

	public GetHuPaiType getGetHuPaiType() {
		return getHuPaiType;
	}

	public boolean isHuPai(Seat seat) {
		return huPaiList.contains(seat);
	}

	/** 下一局开始 */
	protected void nextRound(List<List<Integer>> shaiZiList,
			List<Pai> genNoFengPais) {
		super.nextRound(shaiZiList, genNoFengPais);
		this.huPaiList.clear();
		this.getHuPaiType = null;
		this.niaoPaiList.clear();
		this.fangPaoSeatTmp = null;
		this.fangPaoSeat = null;
		this.huPai = null;
		this.haveDaPaiSeat = null;
		this.chiPaiSeat = null;
		this.chi = null;
		this.pengPaiSeat = null;
		this.jieGangSeat = null;
		this.jiePaoSeatList.clear();
		this.baoTingSeatList.clear();
		this.qiangGangSeatList.clear();
		this.gangType = null;
		this.haveGangSeat = null;
		this.lastZhuaPaiSeat = null;
		for (Seat st : seats) {
			st.faPai(this.getFaPais());
			st.setInitPai(this.initPai);
			battleBackSm.addInitPai(initPai.build());
		}
		for (Seat st : this.seats) {
			if (st.isCanBaoTing()) {
				baoTingSeatList.add(st);
			}
		}
		faPaiCast.setRound(this.getRound()).setBankerSeetIndex(
				this.getBankerSeat().getId());
		faPaiCast.addAllShaizi(this.getShaizi());
		for (Seat st : this.seats) {
			faPaiCast.clearPais();
			for (Pai pai : st.getZiList()) {
				int paiCount = st.getPaiCount(pai);
				while (paiCount != 0 && paiCount-- > 0) {
					faPaiCast.addPais(pai.getMj());
				}
			}
			faPaiCast.setBaoTing(st.isCanBaoTing());
			faPaiCast.setHasBaoTing(isHasBaoTing());
			if (this.isFeiBao()) {
				faPaiCast.setFeiBao(this.getFeiBao());
			}
			st.sendMessage(MsgId.FaPaiCast, faPaiCast.build().toByteArray());
		}
		this.setSeatsGameState(GameState.waitOtherOperation);
		if (isHasBaoTing()) {
			for (Seat st : this.baoTingSeatList)
				st.setGstate(GameState.baoTing);
			this.setRoomState(RoomStateCache.baoTing);
		} else {
			if (this.isReload()) {
				RoomAbs.this.zhuaPaiCast(RoomAbs.this.getBankerSeat());
			} else
				TimeTaskUtil.getTaskmanager()
						.submitOneTimeTask(
								new Runnable() {
									@Override
									public void run() {
										RoomAbs.this.zhuaPaiCast(RoomAbs.this
												.getBankerSeat());
									}
								}, TimeConfig.getBankerZhuaPaiWaitInSeconds(),
								TimeUnit.SECONDS);
		}
	}

	/** 流局 */
	private void liuJu() {
		roundResultCast(true);
	}

	private void roundResultCast() {
		roundResultCast(false);
	}

	/** 局结算广播 */
	private void roundResultCast(boolean liuju) {
		if (this.isYiZiQiaoYouXi()) {
			for (Seat st : this.seats) {
				if (st.isCanYiZiQiaoYouXi()) {
					for (Seat tmp : this.seats) {
						if (tmp == st)
							continue;
						tmp.addYiZiQiaoNumber();
					}
				}
			}
		}
		Seat pengBao4Seat = null;
		Seat zhuaBao4Seat = null;
		if (this.isFeiBao()) {
			for (Seat st : this.seats) {
				if (st.isNeedBaoFaFen()) {
					for (Seat tmp : this.seats) {
						if (tmp == st)
							continue;
						tmp.addBaoFanFenNumber();
					}
				}
				if (st.isPengBao4() != null) {
					pengBao4Seat = st;
				} else if (st.isZhuaBao4()) {
					zhuaBao4Seat = st;
				}
			}
		}
		for (Seat st : this.seats) {
			st.calcRs(pengBao4Seat, zhuaBao4Seat);
		}
		roundResultCast.setReconnect(false);
		roundResultCast.setLiuju(liuju);
		if (this.huPai != null) {
			roundResultCast.setMj(this.huPai.getMj());
			roundResultCast.setGetHuPaiType(this.getHuPaiType.getType());
		}
		for (Seat st : this.huPaiList) {
			huResult.setSeetIndex(st.getId());
			huResult.clearHuPaiType();
			for (HuPaiType type : st.getHuPaiTypes()) {
				huResult.addHuPaiType(type.getType());
			}
			roundResultCast.addHu(huResult.build());
		}
		for (Seat st : this.seats) {
			st.setGstate(GameState.noStart);
			roundResult.setSeetIndex(st.getId());
			roundResult.setRs(st.getRoundRs());
			roundResult.setNiaoNumber(st.getNiaoNumber());
			roundResult.setAnGang(st.getAnGangNumber());
			roundResult.setMingGang(st.getMingGangNumber());
			roundResult.setJieGang(st.getJieGangNumber());
			roundResult.setFangPao(st.getFangPaoNumber());
			roundResult.setFangQiangGang(st.getFangQiangGangNumber());
			roundResult.setFangGang(st.getFangGangNumber());
			roundResult.setYiZiQiaoYouXi(st.isCanYiZiQiaoYouXi());
			roundResult.clearMj();
			for (int i = 0; i < st.getZiList().size(); i++) {
				Pai pai = st.getZiList().get(i);
				if (pai != Pai.emptyMj) {
					int count = st.getCount(i);
					if (this.getHuPaiType == GetHuPaiType.ziMo
							&& pai == this.huPai) {
						count--;
					}
					while (count-- > 0)
						roundResult.addMj(pai.getMj());
				}
			}
			roundResult.setCoin(st.getCoin());
			roundResult.clearGpc();
			for (GpcCache gpc : st.getGpcList()) {
				roundResult.addGpc(gpc.genTargetMj());
			}
			roundResultCast.addRs(roundResult.build());
		}
		roundBuilder.clear();
		for (Seat st : this.seats) {
			roundBuilder.addCoin(st.getRoundRs());
		}
		roundBuilder.setTime(System.currentTimeMillis());
		roundBuilder.setBankerSeetIndex(this.getBankerSeat().getId());
		roundBuilder.setBattlebackIndex(super.recordBattleback());
		this.gameRecordSm.addRound(roundBuilder.build());
		this.setRoomState(RoomStateCache.noStart);
		this.setInitBanker(this.initBanker());
		this.broadCast(MsgId.RoundResultCast, roundResultCast.build()
				.toByteArray());
	}

	/** 杠了补牌 */
	private void buPai(Seat seat, GangType type) {
		this.gangType = type;
		this.haveGangSeat = seat;
		if (this.isHaiDi()) {
			this.zhuaPaiCast(seat.nextOne());
		} else
			zhuaPaiCast(seat, true);
	}

	/** 抓牌 */
	private void zhuaPaiCast(Seat seat) {
		zhuaPaiCast(seat, false);
	}

	/**
	 * 抓牌推送
	 * 
	 * @param seat
	 * @param isBu
	 *            是否是补牌
	 */
	private void zhuaPaiCast(Seat seat, boolean isBu) {
		Pai pai = this.getPai(isBu);
		if (pai == null) {
			this.liuJu();
			return;
		}
		boolean isMoHaiDi = isMoHaiDi();
		seat.zhuaPai(pai, isBu, isMoHaiDi);
		this.lastZhuaPaiSeat = seat;
		this.addSeetOpera(seat, -1, OperaType.zhuaPai, pai, null);
		if (isMoHaiDi) {
			this.haiDiZhuaPaiCast(seat, pai);
			return;
		}
		if (seat.isBaoTing() && !seat.isCanZiMo()) {
			this.baoTingAutoCast(seat, pai);
			return;
		}
		zhuaPaiCast.setMj(pai.getMj());
		zhuaPaiCast.setBu(isBu);
		zhuaPaiCast.setZiMo(seat.isCanZiMo());
		zhuaPaiCast.clearAnGang();
		for (Pai anGangPai : seat.getAnGangCacheArr()) {
			zhuaPaiCast.addAnGang(anGangPai.getMj());
		}
		zhuaPaiCast.clearMingGang();
		for (Pai mingGangPai : seat.getMingGangCacheArr()) {
			zhuaPaiCast.addMingGang(mingGangPai.getMj());
		}
		zhuaPaiCast.clearTing();
		for (Ting ting : seat.getTingCacheList()) {
			if (ting.isTing()) {
				zhuaPaiCast.addTing(ting.genTing());
			}
		}
		if (seat.isCanZiMo() || !seat.getAnGangCacheArr().isEmpty()
				|| !seat.getMingGangCacheArr().isEmpty()) {
			seat.setGstate(GameState.ziMoAnGangMingGangGuo);
		} else {
			seat.setGstate(GameState.daPai);
		}
		if (!isBu) {
			this.gangType = null;
			this.haveGangSeat = null;
		}
		this.setRoomState(RoomStateCache.zhuaPaiCast);
		seat.sendMessage(MsgId.ZhuaPaiCast, zhuaPaiCast.build().toByteArray());
		this.broadCast(MsgId.SeetZhuaPaiCast,
				seetZhuaPaiCast.setSeetIndex(seat.getId()).setBu(isBu).build()
						.toByteArray(), seat);
	}

	private void haiDiZhuaPaiCast(final Seat seat, Pai pai) {
		haiDiZhuaPaiCast.setMj(pai.getMj());
		haiDiZhuaPaiCast.setZiMo(seat.isCanZiMo());
		haiDiZhuaPaiCast.clearAnGang();
		for (Pai anGangPai : seat.getAnGangCacheArr()) {
			haiDiZhuaPaiCast.addAnGang(anGangPai.getMj());
		}
		haiDiZhuaPaiCast.clearMingGang();
		for (Pai mingGangPai : seat.getMingGangCacheArr()) {
			haiDiZhuaPaiCast.addMingGang(mingGangPai.getMj());
		}
		if (seat.isCanZiMo() || !seat.getAnGangCacheArr().isEmpty()
				|| !seat.getMingGangCacheArr().isEmpty()) {
			seat.setGstate(GameState.ziMoAnGangMingGangGuo);
			this.setRoomState(RoomStateCache.haiDizhuaPaiCast);
			seat.sendMessage(MsgId.HaiDiZhuaPaiCast, haiDiZhuaPaiCast.build()
					.toByteArray());
			this.broadCast(MsgId.SeetZhuaPaiCast,
					seetZhuaPaiCast.setSeetIndex(seat.getId()).setBu(false)
							.build().toByteArray(), seat);
		} else {
			seat.setGstate(GameState.waitOtherOperation);
			seat.sendMessage(MsgId.HaiDiZhuaPaiCast, haiDiZhuaPaiCast.build()
					.toByteArray());
			this.broadCast(MsgId.SeetZhuaPaiCast,
					seetZhuaPaiCast.setSeetIndex(seat.getId()).setBu(false)
							.build().toByteArray(), seat);
			if (isReload()) {
				RoomAbs.this.zhuaPaiCast(seat.nextOne());
			} else
				TimeTaskUtil.getTaskmanager().submitOneTimeTask(new Runnable() {
					@Override
					public void run() {
						RoomAbs.this.zhuaPaiCast(seat.nextOne());
					}
				}, 2, TimeUnit.SECONDS);
		}
	}

	/** 如果报听，只能胡牌 */
	private void baoTingAutoCast(Seat seat, Pai pai) {
		seat.daPai(pai);
		daPaiCast(seat, MsgId.BaoTingZhuaDaPaiCast);
	}

	/**
	 * 报听
	 * 
	 * @param seat
	 * @param genMessageLite
	 * @return
	 */
	public byte[] baoTing(Seat seat, boolean baoTing) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.baoTing || !seat.isCanBaoTing()) {
				return MsgId.BaoTingCm.gRErrMsg(NTxt.BAO_TING_CAN_NOT);
			}
			seat.setBaoTing(baoTing);
			if (baoTing) {
				addSeetOpera(seat, -1, OperaType.baoTing, null, null);
			} else {
				addSeetOpera(seat, -1, OperaType.notBaoTing, null, null);
			}
			seat.setGstate(GameState.waitOtherOperation);
			seat.sendMessage(MsgId.BaoTingSm, baoTingSm.setCode(NTxt.SUCCESS)
					.setBaoTing(baoTing).build().toByteArray());
			if (baoTing)
				this.broadCast(MsgId.BaoTingCast, BaoTingCast.newBuilder()
						.setSeetIndex(baoTing ? seat.getId() : 0).build()
						.toByteArray(), seat);
			for (Seat st : this.baoTingSeatList) {
				if (st.getGstate() == GameState.baoTing) {
					return null;
				}
			}
			this.zhuaPaiCast(this.getBankerSeat());
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	/**
	 * 自摸牌请求
	 * 
	 * @param seat
	 * @param genMessageLite
	 * @return
	 */
	public byte[] ziMoPai(Seat seat) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.ziMoAnGangMingGangGuo
					|| !seat.isCanZiMo()) {
				return MsgId.ZiMoPaiCm.gRErrMsg(NTxt.ZI_MO_PAI_CAN_NOT);
			}
			this.ziMohuPai(seat);
			seat.sendMessage(MsgId.ZiMoPaiSm, NTxt.ZI_MO_SUCCESS);
			this.roundResultCast();
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void ziMohuPai(Seat huPaiSeat) {
		this.huPai = huPaiSeat.getZiMoPai();
		this.getHuPaiType = GetHuPaiType.ziMo;
		this.huPaiList.add(huPaiSeat);
		this.addSeetOpera(huPaiSeat, -1, OperaType.ziMo, this.huPai, null);
		int severalNiao = this.getSeveralNiao().getType();
		roundResultCast.setNiaoRen(huPaiSeat.getId());
		while (severalNiao-- > 0) {
			Pai pai = this.getPai(false);
			if (pai == null) {// 如果后面没牌，，胡的牌作为鸟
				pai = this.huPai;
			}
			this.niaoPaiList.add(pai);
			Seat seat = this.seats[(huPaiSeat.getIndex() + pai.getNumber() - 1) % 4];
			niao.setSeetIndex(seat.getId()).setMj(pai.getMj());
			roundResultCast.addNiao(niao.build());
			switch (this.getZhaNiao()) {
			case feiNiao:
				seat.addNiaoNumber(1);
				break;
			case zhuaNiao:
				if (seat == huPaiSeat) {
					seat.addNiaoNumber(1);
				}
				break;
			default:
				break;
			}
		}
		huPaiSeat.ziMo();
	}

	/**
	 * 暗杠牌请求
	 * 
	 * @param seat
	 * @param mj
	 * @return
	 */
	public byte[] anGangPai(Seat seat, Mj mj) {
		rwLock.writeLock().lock();
		try {
			Pai pai = Pai.getPai(mj);
			if (pai == null
					|| seat.getGstate() != GameState.ziMoAnGangMingGangGuo) {
				return MsgId.AnGangPaiCm.gRErrMsg(NTxt.AN_GANG_PAI_CAN_NOT);
			}
			boolean anGang = seat.anGang(pai);
			if (!anGang) {
				return MsgId.AnGangPaiCm.gRErrMsg(NTxt.AN_GANG_PAI_CAN_NOT);
			}
			for (Seat st : this.seats) {
				if (st != seat) {
					st.addAnGangBeen();
				}
			}
			seat.sendMessage(MsgId.AnGangPaiSm,
					anGangPaiSm.setCode(NTxt.SUCCESS).setMj(mj).build()
							.toByteArray());
			this.broadCast(MsgId.AnGangPaiCast,
					anGangPaiCast.setSeetIndex(seat.getId()).setMj(mj).build()
							.toByteArray(), seat);
			this.addSeetOpera(seat, -1, OperaType.anGang, pai, null);
			this.buPai(seat, GangType.AnGang);
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	public byte[] mingGangPai(Seat seat, Mj mj) {
		rwLock.writeLock().lock();
		try {
			Pai pai = Pai.getPai(mj);
			if (pai == null
					|| seat.getGstate() != GameState.ziMoAnGangMingGangGuo) {
				return MsgId.MingGangPaiCm.gRErrMsg(NTxt.MING_GANG_PAI_CAN_NOT);
			}
			boolean mingGang = seat.mingGangPrev(pai);
			if (!mingGang) {
				return MsgId.MingGangPaiCm.gRErrMsg(NTxt.MING_GANG_PAI_CAN_NOT);
			}
			seat.sendMessage(MsgId.MingGangPaiSm,
					mingGangPaiSm.setCode(NTxt.SUCCESS).setMj(mj).build()
							.toByteArray());
			this.qiangGangSeatList.clear();
			for (Seat st : this.seats) {
				if (st == seat) {
					continue;
				}
				st.cacheQiangGangHu(pai);
				if (st.isCanQiangGangHu()) {
					st.setGstate(GameState.qiangGangGuo);
					this.qiangGangSeatList.add(st);
				}
				st.sendMessage(MsgId.MingGangPaiCast,
						mingGangPaiCast.setSeetIndex(seat.getId()).setMj(mj)
								.setQiangGang(st.isCanQiangGangHu()).build()
								.toByteArray());
			}
			this.addSeetOpera(seat, -1, OperaType.mingGang, pai, null);
			if (this.isHasQiangGang()) {
				this.fangPaoSeatTmp = seat;
				seat.setGstate(GameState.waitOtherOperation);
			} else {
				this.mingGangSuccess(seat, pai);
			}
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	/** 成功明杠 */
	private void mingGangSuccess(Seat seat, Pai pai) {
		GpcCache mingGangSuccess = seat.mingGangSuccess(pai,
				isMingGangSuanJieGang());
		if (isMingGangSuanJieGang())
			this.getSeat(mingGangSuccess.getSeetIndex()).mingGangFangGang(pai);
		else {
			for (Seat st : this.seats) {
				if (st != seat) {
					st.addMingGangBeen();
				}
			}
		}
		this.buPai(seat, GangType.MingGang);
	}

	public byte[] qiangGang(Seat seat) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.qiangGangGuo) {
				return MsgId.QiangGangCm.gRErrMsg(NTxt.QIANG_GANG_CAN_NOT);
			}
			qiangGanghuPai(seat);
			seat.setGstate(GameState.waitOtherOperation);
			seat.sendMessage(MsgId.QiangGangSm, NTxt.QIANG_GANG_SUCCESS);
			for (Seat st : this.qiangGangSeatList) {
				if (st.getGstate() == GameState.qiangGangGuo) {
					return null;
				}
			}
			this.roundResultCast();
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void qiangGanghuPai(Seat seat) {
		this.huPai = seat.getQiangGangPai();
		this.getHuPaiType = GetHuPaiType.qiangGang;
		this.huPaiList.add(seat);
		this.addSeetOpera(seat, this.fangPaoSeatTmp.getId(),
				OperaType.qiangGangHu, this.huPai, null);
		seat.qiangGang();
		this.fangPaoSeat = this.fangPaoSeatTmp;
		this.fangPaoSeat.fangQiangGang(seat);
	}

	/**
	 * 打牌请求
	 * 
	 * @param seat
	 * @param mj
	 * @return
	 */
	public byte[] daPai(Seat seat, Mj mj) {
		rwLock.writeLock().lock();
		try {
			Pai pai = Pai.getPai(mj);
			if (pai == null
					|| (seat.getGstate() != GameState.daPai && seat.getGstate() != GameState.ziMoAnGangMingGangGuo)) {
				return MsgId.DaPaiCm.gRErrMsg(NTxt.DA_PAI_PAI_CAN_NOT);
			}
			if (seat.isBaoTing() && pai != seat.getZiMoPai()) {
				LoggerService.getLogicLog().error("报听自摸了还打牌 ！傻子uid:{}",
						seat.getUserUid());
				return MsgId.DaPaiCm.gRErrMsg(NTxt.DA_PAI_PAI_CAN_NOT);
			}
			if (this.isMoHaiDi()) {
				return MsgId.DaPaiCm.gRErrMsg(NTxt.DA_PAI_PAI_CAN_NOT);
			}
			boolean rs = seat.daPai(pai);
			if (!rs) {
				LoggerService.getLogicLog()
						.error("打牌错误！uid:{}，nickname:{},pai:{},zi:{}",
								new Object[] { seat.getUserUid(),
										seat.getUserNickname(), pai,
										seat.getZiList() });
				return MsgId.DaPaiCm.gRErrMsg(NTxt.DA_PAI_PAI_CAN_NOT);
			}
			seat.sendMessage(MsgId.DaPaiSm, daPaiSm.setCode(NTxt.SUCCESS)
					.setMj(mj).build().toByteArray());
			daPaiCast(seat, MsgId.DaPaiCast);
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void daPaiCast(Seat seat, MsgId msgId) {
		this.haveDaPaiSeat = seat;
		Pai haveDaPai = this.getHaveDaPai();
		daPaiCast.setSeetIndex(this.getHaveDaPaiSeat().getId());
		daPaiCast.setMj(haveDaPai.getMj());
		this.chiPaiSeat = null;
		this.pengPaiSeat = null;
		this.jieGangSeat = null;
		this.jiePaoSeatList.clear();
		for (Seat st : this.seats) {
			if (st != this.getHaveDaPaiSeat()) {
				st.cacheJiePao(haveDaPai);
				boolean isCanPeng = st.isCanPeng(haveDaPai);
				boolean isCanJieGang = st.isCanJieGang(haveDaPai);
				boolean isCanJiePao = st.isCanJiePao();
				List<Integer> chiList = st.getChiList(haveDaPai);
				daPaiCast.setPeng(isCanPeng);
				daPaiCast.setJieGang(isCanJieGang);
				daPaiCast.setJiePao(isCanJiePao);
				daPaiCast.clearChi();
				if (!chiList.isEmpty())
					daPaiCast.addAllChi(chiList);
				if (isCanPeng)
					this.pengPaiSeat = st;
				if (isCanJieGang)
					this.jieGangSeat = st;
				if (isCanJiePao)
					this.jiePaoSeatList.add(st);
				if (!chiList.isEmpty()) {
					this.chiPaiSeat = st;
				}
				if (isCanPeng || isCanJieGang || isCanJiePao
						|| !chiList.isEmpty()) {
					st.setGstate(GameState.jiePaoJieGangPengChiGuo);
				} else {
					st.setGstate(GameState.waitOtherOperation);
				}
				st.sendMessage(msgId, daPaiCast.build().toByteArray());
			} else {
				this.getHaveDaPaiSeat().setGstate(GameState.waitOtherOperation);
				if (msgId != MsgId.DaPaiCast) {
					daPaiCast.clearPeng();// 不发给自己
					daPaiCast.clearJieGang();
					daPaiCast.clearJiePao();
					daPaiCast.clearChi();
					st.sendMessage(msgId, daPaiCast.build().toByteArray());
				}
			}
		}
		this.addSeetOpera(this.getHaveDaPaiSeat(), -1, OperaType.daPai,
				haveDaPai, null);
		if (!this.jiePaoSeatList.isEmpty()) {
			this.fangPaoSeatTmp = this.getHaveDaPaiSeat();
		}
		if (this.jiePaoSeatList.isEmpty() && this.jieGangSeat == null
				&& this.pengPaiSeat == null && this.chiPaiSeat == null) {
			zhuaPaiCast(this.getHaveDaPaiSeat().nextOne());
		} else {
			this.setRoomState(RoomStateCache.daPaiCast);
		}
	}

	/**
	 * 缓存操作
	 * 
	 * @param seat
	 * @param type
	 */
	private boolean cacheOpera(Seat seat, AfterOtherDaPaiType type) {
		if (!seat.setAfterOtherDaPaiType(type)) {
			LoggerService.getRoomlogs().error("无法缓存打牌后的操作！type:{}", type);
			return false;
		}
		switch (type) {
		case jiePao:
			this.addSeetOpera(seat, this.getHaveDaPaiSeat().getId(),
					OperaType.jiePao, this.huPai, null);
			for (Seat st : this.jiePaoSeatList) {
				if (st.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			this.roundResultCast();
			return true;
		case jieGang:
			this.addSeetOpera(seat, -1, OperaType.jieGang, getHaveDaPai(), null);
			for (Seat st : this.jiePaoSeatList) {
				if (st.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			jieGangCast(this.jieGangSeat);
			return true;
		case pengPai:
			this.addSeetOpera(seat, this.getHaveDaPaiSeat().getId(),
					OperaType.pengPai, getHaveDaPai(), null);
			for (Seat st : this.jiePaoSeatList) {
				if (st.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			pengPaiCast(this.pengPaiSeat);
			return true;
		case chiPai:
			this.addSeetOpera(seat, this.getHaveDaPaiSeat().getId(),
					OperaType.chiPai, getHaveDaPai(), chi);
			for (Seat st : this.jiePaoSeatList) {
				if (st.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			if (this.jieGangSeat != null) {
				if (this.jieGangSeat.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			if (this.pengPaiSeat != null) {
				if (this.pengPaiSeat.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			chiPaiCast(this.chiPaiSeat);
			return true;
		case nothing:
			this.addSeetOpera(seat, -1, OperaType.jiePaoJieGangPengChiGuo,
					null, null);
			for (Seat st : this.jiePaoSeatList) {
				if (st.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			if (this.jieGangSeat != null) {
				if (this.jieGangSeat.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			if (this.pengPaiSeat != null) {
				if (this.pengPaiSeat.getGstate() == GameState.jiePaoJieGangPengChiGuo) {
					return true;
				}
			}
			if (!this.huPaiList.isEmpty()) {// 有人选择胡牌
				this.roundResultCast();
			} else if (this.jieGangSeat != null
					&& this.jieGangSeat.getAfterOtherDaPaiType() == AfterOtherDaPaiType.jieGang) {
				jieGangCast(this.jieGangSeat);
			} else if (this.pengPaiSeat != null
					&& this.pengPaiSeat.getAfterOtherDaPaiType() == AfterOtherDaPaiType.pengPai) {
				pengPaiCast(this.pengPaiSeat);
			} else if (this.chiPaiSeat != null
					&& this.chiPaiSeat.getAfterOtherDaPaiType() == AfterOtherDaPaiType.chiPai) {
				chiPaiCast(this.chiPaiSeat);
			} else {
				zhuaPaiCast(this.haveDaPaiSeat.nextOne());
			}
			return true;
		default:
			LoggerService.getRoomlogs().error("未实现的操作缓存！type:{}", type);
			return false;
		}
	}

	public byte[] jiePao(Seat seat) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.jiePaoJieGangPengChiGuo
					|| !this.jiePaoSeatList.contains(seat)) {
				return MsgId.JiePaoCm.gRErrMsg(NTxt.JIE_PAO_CAN_NOT);
			}
			if (!seat.isCanJiePao()) {
				return MsgId.JiePaoCm.gRErrMsg(NTxt.JIE_PAO_CAN_NOT);
			}
			this.jiePaohuPai(seat);
			seat.sendMessage(MsgId.JiePaoSm, NTxt.JIE_PAO_SUCCESS);
			cacheOpera(seat, AfterOtherDaPaiType.jiePao);
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void jiePaohuPai(Seat seat) {
		this.huPai = getHaveDaPai();
		this.getHuPaiType = GetHuPaiType.jiePao;
		this.huPaiList.add(seat);
		seat.jiePao();
		this.fangPaoSeat = this.fangPaoSeatTmp;
		this.fangPaoSeat.fangPao(seat);
	}

	public byte[] jieGang(Seat seat) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.jiePaoJieGangPengChiGuo
					|| this.jieGangSeat != seat) {
				return MsgId.JieGangCm.gRErrMsg(NTxt.JIE_GANG_CAN_NOT);
			}
			jieGangSm.setCode(NTxt.SUCCESS).setMj(getHaveDaPai().getMj());
			seat.sendMessage(MsgId.JieGangSm, jieGangSm.build().toByteArray());
			this.cacheOpera(seat, AfterOtherDaPaiType.jieGang);
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void jieGangCast(Seat seat) {
		Pai haveDaPai = getHaveDaPai();
		seat.jieGang(haveDaPai, this.getHaveDaPaiSeat().getId());
		this.getHaveDaPaiSeat().fangGang();
		this.addSeetOpera(seat, this.getHaveDaPaiSeat().getId(),
				OperaType.jieGangCast, haveDaPai, null);
		this.broadCast(MsgId.JieGangCast, jieGangCast
				.setSeetIndex(seat.getId()).setMj(haveDaPai.getMj()).build()
				.toByteArray());
		this.buPai(seat, GangType.JieGang);
	}

	public byte[] pengPai(Seat seat) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.jiePaoJieGangPengChiGuo
					|| this.pengPaiSeat != seat) {
				return MsgId.PengPaiCm.gRErrMsg(NTxt.PENG_PAI_CAN_NOT);
			}
			pengPaiSm.setCode(NTxt.SUCCESS).setMj(getHaveDaPai().getMj());
			seat.sendMessage(MsgId.PengPaiSm, pengPaiSm.build().toByteArray());
			this.cacheOpera(seat, AfterOtherDaPaiType.pengPai);
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void pengPaiCast(Seat seat) {
		Pai haveDaPai = getHaveDaPai();
		seat.peng(haveDaPai, this.getHaveDaPaiSeat().getId());
		this.getHaveDaPaiSeat().fangPeng();
		this.addSeetOpera(seat, this.getHaveDaPaiSeat().getId(),
				OperaType.pengPaiCast, haveDaPai, null);
		pengPaiCast.clear();
		pengPaiCast.setSeetIndex(seat.getId()).setMj(haveDaPai.getMj());
		this.broadCast(MsgId.PengPaiCast, pengPaiCast.build().toByteArray(),
				seat);
		for (Pai anGangPai : seat.getAnGangCacheArr()) {
			pengPaiCast.addAnGang(anGangPai.getMj());
		}
		for (Pai mingGangPai : seat.getMingGangCacheArr()) {
			pengPaiCast.addMingGang(mingGangPai.getMj());
		}
		for (Ting ting : seat.getTingCacheList()) {
			if (ting.isTing()) {
				pengPaiCast.addTing(ting.genTing());
			}
		}
		if (!seat.getAnGangCacheArr().isEmpty()
				|| !seat.getMingGangCacheArr().isEmpty()) {
			seat.setGstate(GameState.ziMoAnGangMingGangGuo);
		} else {
			seat.setGstate(GameState.daPai);
		}
		this.setRoomState(RoomStateCache.pengPaiCast);
		seat.sendMessage(MsgId.PengPaiCast, pengPaiCast.build().toByteArray());
	}

	public byte[] chiPai(Seat seat, int type) {
		rwLock.writeLock().lock();
		try {
			ChiType chiType = ChiType.getEnum(type);
			if (seat.getGstate() != GameState.jiePaoJieGangPengChiGuo
					|| this.chiPaiSeat != seat || chiType == null
					|| !seat.getChiList(this.getHaveDaPai()).contains(type)) {
				return MsgId.ChiPaiCm.gRErrMsg(NTxt.CHI_PAI_CAN_NOT);
			}
			this.chi = chiType;
			chiPaiSm.setCode(NTxt.SUCCESS).setMj(getHaveDaPai().getMj())
					.setChi(chiType.getType());
			seat.sendMessage(MsgId.ChiPaiSm, chiPaiSm.build().toByteArray());
			this.cacheOpera(seat, AfterOtherDaPaiType.chiPai);
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void chiPaiCast(Seat seat) {
		Pai haveDaPai = getHaveDaPai();
		seat.chi(chi, haveDaPai, this.getHaveDaPaiSeat().getId());
		this.getHaveDaPaiSeat().fangChi();
		this.addSeetOpera(seat, this.getHaveDaPaiSeat().getId(),
				OperaType.chiPaiCast, haveDaPai, chi);
		chiPaiCast.clear();
		chiPaiCast.setSeetIndex(seat.getId()).setMj(haveDaPai.getMj())
				.setChi(chi.getType());
		this.broadCast(MsgId.ChiPaiCast, chiPaiCast.build().toByteArray(), seat);
		for (Pai anGangPai : seat.getAnGangCacheArr()) {
			chiPaiCast.addAnGang(anGangPai.getMj());
		}
		for (Pai mingGangPai : seat.getMingGangCacheArr()) {
			chiPaiCast.addMingGang(mingGangPai.getMj());
		}
		for (Ting ting : seat.getTingCacheList()) {
			if (ting.isTing()) {
				chiPaiCast.addTing(ting.genTing());
			}
		}
		if (!seat.getAnGangCacheArr().isEmpty()
				|| !seat.getMingGangCacheArr().isEmpty()) {
			seat.setGstate(GameState.ziMoAnGangMingGangGuo);
		} else {
			seat.setGstate(GameState.daPai);
		}
		this.setRoomState(RoomStateCache.chiPaiCast);
		seat.sendMessage(MsgId.ChiPaiCast, chiPaiCast.build().toByteArray());
	}

	/**
	 * 过请求
	 * 
	 * @param seat
	 * @return
	 */
	public byte[] over(Seat seat) {
		rwLock.writeLock().lock();
		try {
			switch (seat.getGstate()) {
			case qiangGangGuo:
				seat.sendMessage(MsgId.OverSm, NTxt.OVER_SUCCESS);
				qiangGangGuo(seat);
				break;
			case jiePaoJieGangPengChiGuo:
				seat.sendMessage(MsgId.OverSm, NTxt.OVER_SUCCESS);
				if (this.jiePaoSeatList.contains(seat) && seat.isCanJiePao()) {// 本轮不接炮，，这一轮都不能接炮
					seat.recordNoJiePao(this.getHaveDaPai());
				}
				this.cacheOpera(seat, AfterOtherDaPaiType.nothing);
				break;
			default:
				return MsgId.OverCm.gRErrMsg(NTxt.OVER_CAN_NOT);
			}
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void qiangGangGuo(Seat seat) {
		if (!seat.setQiangGangGuo()) {
			return;
		}
		this.addSeetOpera(seat, -1, OperaType.qiangGangGuo, null, null);
		for (Seat st : this.qiangGangSeatList) {
			if (st.getGstate() == GameState.qiangGangGuo) {
				return;
			}
		}
		if (!this.huPaiList.isEmpty()) {// 有人选择抢杠胡牌
			this.roundResultCast();
		} else {
			mingGangSuccess(this.fangPaoSeatTmp, seat.getQiangGangPai());
		}
	}

	/**
	 * 断线重连请求
	 * 
	 * @param seat
	 * @param genMessageLite
	 * @return
	 */
	public byte[] reconnect(Seat seat, ReconnectCm genMessageLite) {
		rwLock.readLock().lock();
		try {
			seat.setUserState(UserState.online);
			ReconnectSm.Builder reconnectSm = ReconnectSm.newBuilder().setCode(
					NTxt.SUCCESS);
			for (Seat st : seats) {
				if (st.getUser() != null)
					st.setUserInfo(reconnectSm.addUsersBuilder());
			}
			reconnectSm.setPlayType(this.getPlayType())
					.setRoomId(this.getIdStr()).setChatRoomId(this.getImId());
			if (!seat.gameNotBegin())
				for (Seat st : seats) {
					st.setUserRoundInfo(reconnectSm.addUsersRoundBuilder());
				}
			reconnectSm.setStart(this.isStart());
			if (!seat.gameNotBegin())
				reconnectSm.setMy(seat.getMyRoundInfo());
			reconnectSm.setRound(this.getRound());
			if (this.getBankerSeat() != null)
				reconnectSm.setBankerSeetIndex(this.getBankerSeat().getId());
			if (this.isBelongGuild())
				reconnectSm.setJuelebuRoom(this.getJulebuRoom());
			if (this.isStart() && this.isFeiBao()) {
				reconnectSm.setFeiBao(this.getFeiBao());
			}
			seat.sendMessage(MsgId.ReconnectSm, reconnectSm.build()
					.toByteArray());
			this.getRoomState().seatReconnect(this, seat);
			if (memberDissolveRoomCast.getAgreeSeetIndexCount() != 0)
				seat.sendMessage(MsgId.MemberDissolveRoomCast,
						this.memberDissolveRoomCast.build().toByteArray());
			this.wakeupGame();
		} finally {
			rwLock.readLock().unlock();
		}
		return null;
	}

	public boolean hasSameIp(String ip) {
		for (Seat seat : this.seats) {
			if (seat.getUserIp().equals(ip)) {
				return true;
			}
		}
		return false;
	}
}
