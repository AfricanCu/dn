package com.wk.server.logic.room;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.util.List;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import msg.LoginMessage.GameRecord;
import msg.MjMessage.GameOverCast;
import msg.RoomMessage.ChatCast;
import msg.RoomMessage.ChatCm;
import msg.RoomMessage.DissolveRoomCm;
import msg.RoomMessage.ImCast;
import msg.RoomMessage.ImCm;
import msg.RoomMessage.ImInfoSaveCm;
import msg.RoomMessage.JoinRoomCast;
import msg.RoomMessage.JoinRoomSm;
import msg.RoomMessage.JulebuRoom;
import msg.RoomMessage.LeaveRoomCm;
import msg.RoomMessage.MemberDissolveRoomCm;
import msg.RoomMessage.NsCast;
import msg.RoomMessage.NsCm;
import msg.RoomMessage.PlayType;
import msg.RoomMessage.PrepareRoomCast;
import msg.RoomMessage.PrepareRoomCm;
import msg.RoomMessage.ProxyRoom;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.FriendBean;
import com.wk.bean.GamerecordBean;
import com.wk.bean.SystemConstantsAbs;
import com.wk.db.dao.GamerecordDao;
import com.wk.db.dao.RoomDao;
import com.wk.engine.config.ServerConfig;
import com.wk.engine.config.SystemConstants;
import com.wk.enun.UserState;
import com.wk.guild.bean.GuildBean;
import com.wk.guild.enm.WinnerNumType;
import com.wk.logic.area.AreaType;
import com.wk.logic.area.YI_YANG;
import com.wk.logic.config.DissolveRoomType;
import com.wk.logic.config.NTxt;
import com.wk.logic.config.TimeConfig;
import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MemberDisType;
import com.wk.logic.enm.MsgId;
import com.wk.logic.enm.UserGTGType;
import com.wk.mj.Pai;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.ZhaNiaoType;
import com.wk.server.ibatis.select.IncomeUserI;
import com.wk.server.ibatis.select.User;
import com.wk.server.logic.friend.FindUserHandlerI;
import com.wk.server.logic.guild.FindGuildHandlerI;
import com.wk.server.logic.guild.Guild;
import com.wk.server.logic.guild.GuildManager;
import com.wk.server.logic.item.ItemTemplate;
import com.wk.server.logic.login.LoginModule;
import com.wk.user.bean.UserBean;
import com.wk.util.TimeTaskUtil;

public abstract class RoomBase extends RoomMessageBase {
	/** 读写锁 */
	protected final ReentrantReadWriteLock rwLock = new ReentrantReadWriteLock();
	/** 座位 */
	protected final Seat seats[];
	/** 麻将玩法类型 **/
	protected final AreaType areaType;
	/** 房间玩法 */
	private PlayType playType;
	/** 房间玩法设置 */
	private PlayTypeSet playTypeSet;
	/** 房主id */
	private long masterId;
	/** 庄家位置 */
	private Seat bankerSeat;
	/*** 是否是代理开房 **/
	private JulebuRoom julebuRoom;
	/** 房间id */
	private int id;
	private String idStr;
	/** 语音房间id */
	private String imId;
	/** 游戏是否结束 */
	private boolean gameOver;
	/** 对游戏发生改变的时间 */
	private long changeTimeInMillis;
	/** 是否已经开始 */
	private boolean start;
	/** 房间状态 */
	private RoomStateCache roomState;
	/** 第几局 */
	private int round;
	/** 什么时候开始解散房间请求 **/
	private long memberDissolveTimeInMillis;
	/*** 同意解散时效 **/
	private ScheduledFuture<?> submitOneTimeTask;
	/*** 太久未操作房间解散时效 **/
	private ScheduledFuture<?> dissolveTask;
	/** 保存任务 **/
	protected ScheduledFuture<?> saveTask;
	/** 是否初始化 */
	private boolean isInit;
	/** 是否是加载复盘数据 **/
	private boolean reload;
	/** 癞子 */
	private Pai lai;

	public RoomBase(AreaType pType) {
		this.areaType = pType;
		this.seats = new Seat[this.areaType.getNum()];
	}

	public void init(PlayType playType, PlayTypeSet playTypeSet, long masterId,
			JulebuRoom julebuRoom, int id) throws Exception {
		super.init();
		this.playType = playType;
		this.playTypeSet = playTypeSet;
		if (AreaType.getEnum(this.playType.getArea()) == YI_YANG.getInstance()) {
			System.err.println("暂不开发益阳麻将！");
		}
		this.masterId = masterId;
		this.bankerSeat = null;
		this.julebuRoom = julebuRoom;
		this.id = id;
		this.idStr = ServerConfig.getRoomStr(this.id);
		this.imId = RoomUtils.genImId();
		this.gameOver = false;
		this.changeTimeInMillis = System.currentTimeMillis();
		this.start = false;
		this.round = 0;
		this.roomState = RoomStateCache.noStart;
		this.memberDissolveTimeInMillis = 0l;
		if (this.submitOneTimeTask != null) {
			this.submitOneTimeTask.cancel(true);
			this.submitOneTimeTask = null;
			LoggerService.getRoomlogs().error("数据没有清干净！");
		}
		if (this.dissolveTask != null) {
			this.dissolveTask.cancel(true);
			this.dissolveTask = null;
			LoggerService.getRoomlogs().error("数据没有清干净！");
		}
	}

	protected void nextRound() {
		super.nextRound();
	}

	public Seat[] getSeats() {
		return seats;
	}

	public int getSeatLength() {
		return seats.length;
	}

	public Seat getSeat(IncomeUserI user) {
		for (Seat seat : this.seats) {
			if (seat.getUser() == user) {
				return seat;
			}
		}
		return null;
	}

	public Seat getSeat(int id) {
		if (id > 0 && id <= this.seats.length)
			return this.seats[id - 1];
		return null;
	}

	/**
	 * 玩家数
	 * 
	 * @return
	 */
	public int getUserNum() {
		int num = 0;
		for (Seat seat : this.seats) {
			if (seat.getUser() != null) {
				num++;
			}
		}
		return num;
	}

	private Seat getMasterSeat() {
		for (Seat st : this.seats) {
			if (st.isMaster()) {
				return st;
			}
		}
		return null;
	}

	/**
	 * 广播
	 * 
	 * @param msgId
	 * @param bytes
	 */
	public void broadCast(MsgId msgId, byte[] bytes) {
		for (Seat seat : seats) {
			seat.sendMessage(msgId, bytes);
		}
	}

	/**
	 * 缓存广播
	 * 
	 * @param msgId
	 * @param bytes
	 */
	public void broadCastCache(byte[] bytes) {
		for (Seat seat : seats) {
			seat.cacheMsg(bytes);
		}
	}

	/**
	 * 广播
	 * 
	 * @param msgId
	 * @param bytes
	 */
	public void broadCast(MsgId msgId, byte[] bytes, Seat exceptSeat) {
		for (Seat seat : seats) {
			if (seat != exceptSeat)
				seat.sendMessage(msgId, bytes);
		}
	}

	protected void setSeatsGameState(GameState gameState) {
		for (Seat st : this.seats) {
			st.setGstate(gameState);
		}
	}

	public AreaType getAreaType() {
		return areaType;
	}

	public PlayType getPlayType() {
		return playType;
	}

	public PlayTypeSet getPlayTypeSet() {
		return playTypeSet;
	}

	public boolean isYiZiQiaoYouXi() {
		return playTypeSet.isYiZiQiaoYouXi();
	}

	public SeveralNiaoType getSeveralNiao() {
		return playTypeSet.getSeveralNiaoType();
	}

	public ZhaNiaoType getZhaNiao() {
		return playTypeSet.getZhaNiaoType();
	}

	public boolean isMengQingJiangJiangJiePao() {
		return playTypeSet.isMengQingJiangJiangJiePao();
	}

	public BankerMode getBankerMode() {
		return playTypeSet.getBankerMode();
	}

	public boolean isFeng() {
		return playTypeSet.isFeng();
	}

	public boolean isLai(Pai pai) {
		return this.playTypeSet.isLai() && pai == this.lai;
	}

	public boolean isChi() {
		return this.playTypeSet.isChi();
	}

	public boolean isFeiBao() {
		return this.playTypeSet.isFeiBao();
	}

	public boolean isMingGangSuanJieGang() {
		return this.playTypeSet.isMingGangSuanJieGang();
	}

	public int getNeedDiamond() {
		return getBankerMode().getNeedDiamond();
	}

	public long getMasterId() {
		return masterId;
	}

	public Seat getBankerSeat() {
		return this.bankerSeat;
	}

	public void setBankerSeat(Seat seat) {
		this.bankerSeat = seat;
	}

	/**
	 * 初始默认庄家
	 * 
	 * @return
	 */
	protected Seat getDefaultBankerSeat() {
		Seat masterSeat = this.getMasterSeat();
		if (masterSeat != null) {
			return masterSeat;
		}
		return this.seats[0];
	}

	/** 是否庄家 **/
	public boolean isBanker(Seat seat) {
		return this.bankerSeat != null && seat == this.bankerSeat;
	}

	/**
	 * 不是工会开房
	 * 
	 * @return
	 */
	public boolean isBelongGuild() {
		return this.julebuRoom != JulebuRoom.getDefaultInstance();
	}

	public int getGuildId() {
		return julebuRoom.getId();
	}

	public int getNum() {
		return julebuRoom.getNum();
	}

	/***/
	public JulebuRoom getJulebuRoom() {
		return julebuRoom;
	}

	public int getId() {
		return this.id;
	}

	public String getIdStr() {
		return this.idStr;
	}

	public String getImId() {
		return imId;
	}

	/**
	 * 游戏是否结束
	 * 
	 * @return
	 */
	public boolean isGameOver() {
		return gameOver;
	}

	/**
	 * 记录对游戏有改变的操作时间
	 */
	public void recordChange() {
		this.changeTimeInMillis = System.currentTimeMillis();
	}

	public long getChangeTimeInMillis() {
		return changeTimeInMillis;
	}

	public boolean isStart() {
		return this.start;
	}

	public void setStart(boolean start) {
		this.start = start;
	}

	public int getRound() {
		return this.round;
	}

	public void addRound() {
		this.round++;
	}

	public void setRound(int round) {
		this.round = round;
	}

	/** 暂停游戏 **/
	public void pauseGame() {
		checkNullTask(this.dissolveTask);
		this.dissolveTask = TimeTaskUtil.getTaskmanager().submitOneTimeTask(
				new Runnable() {
					@Override
					public void run() {
						RoomBase.this
								.dissolveRoom(DissolveRoomType.NO_MAN_OPERA);
						RoomBase.this.dissolveTask = null;
					}
				}, TimeConfig.getPauseGameDissolveTimeInSecond(),
				TimeUnit.SECONDS);
		LoggerService.getLogicLog().error("暂停游戏");
	}

	/** 唤醒游戏 **/
	public void wakeupGame() {
		if (this.dissolveTask != null) {
			this.dissolveTask.cancel(true);
			this.dissolveTask = null;
			LoggerService.getLogicLog().error("唤醒游戏");
		}
	}

	public boolean isInit() {
		return isInit;
	}

	public void setInit(boolean isInit) {
		this.isInit = isInit;
	}

	/**
	 * im 信息保存请求
	 * 
	 * @param seat
	 * @param genMessageLite
	 * @return
	 */
	public byte[] imInfoSave(Seat seat, ImInfoSaveCm genMessageLite) {
		int index = genMessageLite.getIndex();
		seat.setImSeatIndex(index);
		return NTxt.IM_INFO_SAVE_SUCCESS;
	}

	public byte[] chat(Seat seat, ChatCm genMessageLite) {
		int id2 = genMessageLite.getId();
		String content = genMessageLite.getContent();
		int type = genMessageLite.getType();
		seat.sendMessage(MsgId.ChatSm, NTxt.CHAT_SUCCESS);
		this.broadCast(MsgId.ChatCast, ChatCast.newBuilder().setId(id2)
				.setContent(content).setType(type).setSeetIndex(seat.getId())
				.build().toByteArray());
		return null;
	}

	public byte[] im(Seat seat, ImCm genMessageLite) {
		String fileid = genMessageLite.getFileid();
		seat.sendMessage(MsgId.ImSm, NTxt.IM_SUCCESS);
		this.broadCast(MsgId.ImCast,
				ImCast.newBuilder().setSeetIndex(seat.getId())
						.setFileid(fileid).build().toByteArray(), seat);
		return null;
	}

	public byte[] ns(Seat seat, NsCm genMessageLite) {
		seat.sendMessage(MsgId.NsSm, NTxt.NS_SUCCESS);
		seat.setNs(genMessageLite);
		this.broadCast(
				MsgId.NsCast,
				NsCast.newBuilder().setSeetIndex(seat.getId())
						.setNs(genMessageLite).build().toByteArray(), seat);

		return null;
	}

	/**
	 * 加入房间
	 * 
	 * @param user
	 * @param send
	 *            是否需要发送
	 * @return 加入成功返回null
	 */
	public byte[] joinRoom(IncomeUserI user, boolean send) {
		if (this.isStart()) {
			return MsgId.JoinRoomCm.gRErrMsg(NTxt.FORBIDDEN_GAME_RUNNING);
		}
		for (Seat seat : this.seats) {
			if (seat.getUserUid() == user.getUid()) {
				return MsgId.JoinRoomCm.gRErrMsg(NTxt.COMMON_ERROR);
			}
		}
		rwLock.writeLock().lock();
		try {
			if (this.isStart()) {
				return MsgId.JoinRoomCm.gRErrMsg(NTxt.FORBIDDEN_GAME_RUNNING);
			}
			for (Seat seat : this.seats) {
				if (seat.getUserUid() == user.getUid()) {
					return MsgId.JoinRoomCm.gRErrMsg(NTxt.COMMON_ERROR);
				}
			}
			for (Seat seat : this.seats) {
				if (seat.getUser() == null) {
					seat.setUser(user);
					if (send) {
						JoinRoomSm.Builder joinRoomSm = JoinRoomSm.newBuilder()
								.setCode(NTxt.SUCCESS)
								.setSeatIndex(seat.getId())
								.setChatRoomId(this.getImId())
								.setPlayType(this.getPlayType())
								.setRoomId(this.getIdStr());
						if (julebuRoom != JulebuRoom.getDefaultInstance()) {
							joinRoomSm.setJulebuRoom(julebuRoom);
						}
						for (Seat st : this.getSeats()) {
							if (st.getUser() != null)
								st.setUserInfo(joinRoomSm.addUsersBuilder());
						}
						user.sendMessage(MsgId.JoinRoomSm, joinRoomSm);
						JoinRoomCast.Builder joinRoomCast = JoinRoomCast
								.newBuilder();
						seat.setUserInfo(joinRoomCast.getAddUserBuilder());
						this.broadCast(MsgId.JoinRoomCast, joinRoomCast.build()
								.toByteArray(), seat);
					}
					this.wakeupGame();
					return null;
				}
			}
			return MsgId.JoinRoomCm.gRErrMsg(NTxt.JOIN_ROOM_NO_LEFT_SEAT);
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	/**
	 * 离开房间请求
	 * 
	 * @param seat
	 * @param genMessageLite
	 * @return
	 */
	public byte[] leaveRoom(Seat seat, LeaveRoomCm genMessageLite) {
		return leave(seat);
	}

	/**
	 * 离开房间
	 * 
	 * @param seat
	 * @return
	 */
	public byte[] leave(Seat seat) {
		if (seat.isMaster()) {
			return MsgId.LeaveRoomCm
					.gRErrMsg(NTxt.LEAVE_ROOM_MASTER_CAN_NOT_LEAVE);
		}
		if (this.isStart()) {
			return MsgId.LeaveRoomCm.gRErrMsg(NTxt.FORBIDDEN_GAME_RUNNING);
		}
		rwLock.writeLock().lock();
		try {
			if (seat.isMaster()) {
				return MsgId.LeaveRoomCm
						.gRErrMsg(NTxt.LEAVE_ROOM_MASTER_CAN_NOT_LEAVE);
			}
			if (this.isStart()) {
				return MsgId.LeaveRoomCm.gRErrMsg(NTxt.FORBIDDEN_GAME_RUNNING);
			}
			IncomeUserI user = seat.getUser();
			seat.setUser(null);
			seat.setGstate(GameState.noStart);
			user.sendMessage(MsgId.LeaveRoomSm, NTxt.LEAVE_ROOM_SUCCESS);
			this.broadCast(MsgId.JoinRoomCast, JoinRoomCast.newBuilder()
					.setDelSeatIndex(seat.getId()).build().toByteArray());
			this.checkAllOffLine();
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	/**
	 * 解散房间请求
	 * 
	 * @param seat
	 * @param genMessageLite
	 */
	public byte[] dissolveRoom(Seat seat, DissolveRoomCm genMessageLite) {
		if (!seat.isMaster()) {
			return MsgId.DissolveRoomCm
					.gRErrMsg(NTxt.DISSOLVE_ROOM_NO_RIGHT_TO_DO);
		}
		IncomeUserI user = seat.getUser();
		if (this.isStart()) {
			return MsgId.DissolveRoomCm
					.gRErrMsg(NTxt.DISSOLVE_ROOM_FORBIDDEN_GAME_RUNNING);
		}
		if (isBelongGuild()) {
			user.addItem(ItemTemplate.Diamond_ID, this.getBankerMode()
					.getNeedDiamond(), true, NTxt.PROXY_DISSOLVE_ROOM);
		}
		this.dissolveRoom(DissolveRoomType.DISSOLVE_OPERATION);
		user.sendMessage(MsgId.DissolveRoomSm, NTxt.DISSOVE_ROOM_SUCCESS);
		return null;
	}

	/**
	 * 解散房间
	 * 
	 * @param reason
	 *            解散原因
	 * @return
	 */
	public void dissolveRoom(DissolveRoomType reason) {
		rwLock.writeLock().lock();
		if (!isInit()) {
			return;
		}
		setInit(false);
		try {
			this.gameOver = true;
			Guild andReloadGuild = isBelongGuild() ? GuildManager.getInstance()
					.getAndReloadGuild(getGuildId()) : null;
			if (andReloadGuild != null)
				andReloadGuild.set(getNum(), SystemConstantsAbs.NoRoomId);
			if (this.isStart()) {
				dis();
				GameOverCast.Builder gameOverCast = GameOverCast.newBuilder();
				Seat winner = seats[0];
				Seat paoShou = seats[0];
				for (Seat seat : seats) {
					if (seat.getMinusCoin() > winner.getMinusCoin()) {
						winner = seat;
					}
					if (seat.getFangPaoTimes() > paoShou.getFangPaoTimes()) {
						paoShou = seat;
					}
					seat.genGameOverCast(gameOverCast.addRsBuilder());
				}
				for (Seat seat : seats) {
					if (seat.getMinusCoin() == winner.getMinusCoin()) {
						gameOverCast.addSeetIndex(seat.getId());
					}
					if (seat.getFangPaoTimes() == paoShou.getFangPaoTimes()) {
						gameOverCast.addPaoShou(seat.getId());
					}
				}
				if (andReloadGuild != null) {
					List<Integer> seetIndexList = gameOverCast
							.getSeetIndexList();
					WinnerNumType type = WinnerNumType.getEnum(seetIndexList
							.size());
					for (int seatIndex : seetIndexList) {
						andReloadGuild.changeMemberWinNum(getSeat(seatIndex)
								.getUserUid(), type.getAdd());
					}
					for (Seat seat : seats)
						andReloadGuild.addMemberActiveNum(seat.getUserUid());
				}
				if (reason == DissolveRoomType.GAME_OVER_NO_NEXT_BANKER)
					this.broadCastCache(gameOverCast.build().toByteArray());
				else {
					this.broadCast(MsgId.GameOverCast, gameOverCast.build()
							.toByteArray());
				}
				int index = 0;
				try {
					index = GamerecordDao.insertGamerecord(new GamerecordBean(
							0, this.gameRecordSm.build().toByteArray()));
				} catch (Exception e) {
					LoggerService.getRoomlogs().error(
							String.format(
									"insertGamerecord!roomid:%s,%s,error:%s",
									this.idStr, reason.getDesc(),
									e.getMessage()), e);
				}
				GameRecord.Builder gameRecordBuilder = GameRecord.newBuilder()
						.setRound(this.gameRecordSm.getRoundCount())
						.setRoomId(this.idStr)
						.setPlayType(this.getAreaType().getType())
						.setTime(System.currentTimeMillis()).setIndex(index);
				for (Seat seat : seats) {
					gameRecordBuilder.addNickname(seat.getUserNickname())
							.addCoin(seat.getMinusCoin());
				}
				GameRecord gameRecord = gameRecordBuilder.build();
				for (Seat seat : seats) {
					seat.getUser().recordGame(gameRecord);
				}
				if (andReloadGuild != null) {
					andReloadGuild.recordGame(gameRecord);
				}
			}
			this.retDiamond(reason);
			// ////////////
			if (reason == DissolveRoomType.MEMBER_DISSOLVE_ALL_AGREE) {// 放到520之后，，客户端要求
				this.broadCast(MsgId.MemberDissolveRoomCast,
						this.memberDissolveRoomCast.setIsOk(1).build()
								.toByteArray());
				this.resetMember();
			}
			if (!this.isStart())
				for (Seat seat : seats) {
					seat.sendMessage(MsgId.DissolveRoomCast,
							SystemConstants.dissolveRoomCast);

				}
			for (Seat seat : seats) {
				seat.setUser(null);
			}
			// //////////这个一定在最后执行！
			try {
				RoomModule.getInstance().removeRoom(this.id);
			} catch (Exception e) {
				LoggerService.getRoomlogs().error(
						String.format("移除房间错误!roomid:%s,%s,error:%s",
								this.idStr, reason.getDesc(), e.getMessage()),
						e);
			}
			LoggerService.getRoomlogs().warn("移除房间！roomid:{},{}", this.idStr,
					reason.getDesc());
		} finally {
			rwLock.writeLock().unlock();
			wakeupGame();
		}
	}

	private void resetMember() {
		for (Seat st : this.seats) {
			st.setMemberDisType(MemberDisType.empty);
		}
		this.memberDissolveRoomCast.clear();
		this.memberDissolveTimeInMillis = 0l;
		this.submitOneTimeTask.cancel(true);
		this.submitOneTimeTask = null;
	}

	/** 游戏已经开始，进行解散处理 */
	public void dis() {
	}

	/** 还钻 **/
	private void retDiamond(DissolveRoomType reason) {
		if (reason.isNormal()) {
			return;
		}
		LoggerService.getLogicLog().error("还钻！！！！！");
		try {
			if (isBelongGuild()) {
				new FindUserHandlerI.ChangeDiamondHandler(
						UserGTGType.RetDiamondToGuildMaster,
						this.getMasterId(), this.getNeedDiamond());
			} else {
				getMasterSeat()
						.addItem(ItemTemplate.Diamond_ID,
								this.getNeedDiamond(), true,
								NTxt.SPECIAL_DISSOLVE_ROOM);
			}
		} catch (Exception ee) {
			LoggerService.getRoomlogs().error(ee.getMessage(), ee);
		}
	}

	/**
	 * 房间准备请求
	 * 
	 * @param seat
	 * @return
	 */
	public byte[] prepareRoom(Seat seat) {
		rwLock.writeLock().lock();
		try {
			if (seat.getGstate() != GameState.noStart) {
				return MsgId.PrepareRoomCm
						.gRErrMsg(NTxt.PREPARE_ROOM_NO_IN_STATE);
			}
			if (seat.isPrepared()) {
				return MsgId.PrepareRoomCm.gRErrMsg(NTxt.PREPARED_ALREADY);
			}
			return prepare(seat, false);
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	protected byte[] prepare(Seat seat, boolean isCastToMe) {
		if (this.isGameOver()) {
			return MsgId.PrepareRoomCm.gRErrMsg(NTxt.GAME_OVER);
		}
		seat.setGstate(GameState.prepared);
		if (isCastToMe) {
			this.broadCast(MsgId.PrepareRoomCast, PrepareRoomCast.newBuilder()
					.setSeatIndex(seat.getId()).build().toByteArray());
		} else
			this.broadCast(MsgId.PrepareRoomCast, PrepareRoomCast.newBuilder()
					.setSeatIndex(seat.getId()).build().toByteArray(), seat);
		if (this.isAllPrepared()) {
			if (!this.isStart()) {
				this.start();
				this.nextBanker();
			} else {
				this.nextBanker();
			}
			this.save();
			return NTxt.PREPARE_ROOM_SUCCESS;
		} else if (this.getRound() >= this.getBankerMode().getNum()) {
			IncomeUserI user = seat.getUser();
			this.dissolveRoom(DissolveRoomType.GAME_OVER_NO_NEXT_BANKER);
			user.sendCacheGameOverCast();
			return MsgId.PrepareRoomCm.gRErrMsg(NTxt.GAME_OVER);
		} else {
			return NTxt.PREPARE_ROOM_SUCCESS;
		}
	}

	/**
	 * 保存房间数据
	 */
	public void save() {
		if (this.isReload()) {
			return;
		}
		try {
			ByteBuf out = Unpooled.buffer();
			this.writeExternal(out);
			byte[] back = out.array();
			RoomDao.updateRoomBack(back, this.getId(), ServerConfig.serverId);
		} catch (Exception e) {
			LoggerService.getRoomlogs().error(e.getMessage(), e);
		}
		checkNullTask(saveTask);
	}

	/** 游戏开始 */
	private void start() {
		if (!this.isBelongGuild()) {
			getMasterSeat().addItem(ItemTemplate.Diamond_ID,
					-getBankerMode().getNeedDiamond(), true,
					NTxt.ROOM_START_MASTER_CONSUME_DIAMOND);
		}
		this.setStart(true);
	}

	/** 下一轮庄 */
	protected abstract void nextBanker();

	protected boolean isAllPrepared() {
		for (Seat seat : this.seats) {
			if (!seat.isPrepared()) {
				return false;
			}
		}
		return true;
	}

	/** 检测是否都下线了 **/
	public void checkAllOffLine() {
		for (Seat st : seats) {
			if (st.getUser() != null && st.getUserState() == UserState.online) {
				return;
			}
		}
		this.pauseGame();
	}

	/**
	 * 玩家解散房间请求
	 * 
	 * @param seat
	 * @param genMessageLite
	 * @return
	 */
	public byte[] memberDissolveRoom(Seat seat,
			MemberDissolveRoomCm genMessageLite) {
		boolean agree = genMessageLite.getAgree();
		rwLock.writeLock().lock();
		try {
			if (!agree && seat.getMemberDisType() == MemberDisType.empty) {
				return MsgId.MemberDissolveRoomCm
						.gRErrMsg(NTxt.MEMBER_DISSOLVEROOM_COMMON_ERROR);
			}
			if (seat.getMemberDisType() == MemberDisType.empty) {// 第一个请求解散的
				for (Seat st : this.seats) {
					st.setMemberDisType(MemberDisType.waiting);
				}
				memberDissolveRoomCast.clear();
				this.memberDissolveTimeInMillis = System.currentTimeMillis();
				checkNullTask(this.submitOneTimeTask);
				this.submitOneTimeTask = TimeTaskUtil.getTaskmanager()
						.submitOneTimeTask(
								new Runnable() {
									@Override
									public void run() {
										for (Seat st : seats) {
											if (st.getMemberDisType() == MemberDisType.waiting) {
												st.setMemberDisType(MemberDisType.agree);
												memberDissolveRoomCast
														.addAgreeSeetIndex(st
																.getId());
											}
										}
										checkMemberDissolve();
									}

								},
								TimeConfig.getMemberDissolveRoomTimeInMillis(),
								TimeUnit.MILLISECONDS);
			}
			if (seat.getMemberDisType() != MemberDisType.waiting) {
				return MsgId.MemberDissolveRoomCm
						.gRErrMsg(NTxt.MEMBER_DISSOLVEROOM_AGREE_ALREADY);
			}
			if (agree) {
				seat.setMemberDisType(MemberDisType.agree);
				memberDissolveRoomCast.addAgreeSeetIndex(seat.getId());
			} else {
				seat.setMemberDisType(MemberDisType.disagree);
				memberDissolveRoomCast.addDisagreeSeetIndex(seat.getId());
			}
			seat.sendMessage(MsgId.MemberDissolveRoomSm,
					NTxt.MEMBER_DISSOLVE_SUCCESS);
			checkMemberDissolve();
			return null;
		} finally {
			rwLock.writeLock().unlock();
		}
	}

	private void checkMemberDissolve() {
		int agCont = 0;
		int diagCount = 0;
		for (Seat st : this.seats) {
			if (st.getMemberDisType() == MemberDisType.agree) {
				agCont++;
			} else if (st.getMemberDisType() == MemberDisType.disagree) {
				diagCount++;
			}
		}
		float halfNum = this.getSeatLength() / 2.0f;
		if (agCont > halfNum) {
			this.dissolveRoom(DissolveRoomType.MEMBER_DISSOLVE_ALL_AGREE);
		} else if (diagCount >= halfNum) {
			this.broadCast(MsgId.MemberDissolveRoomCast,
					this.memberDissolveRoomCast.setIsOk(2).build()
							.toByteArray());
			this.resetMember();
		} else {
			this.broadCast(
					MsgId.MemberDissolveRoomCast,
					this.memberDissolveRoomCast
							.setIsOk(0)
							.setMemberDisInMillis(
									TimeConfig
											.getMemberDissolveRoomTimeInMillis()
											- (System.currentTimeMillis() - this.memberDissolveTimeInMillis))
							.build().toByteArray());
		}
	}

	public RoomStateCache getRoomState() {
		return this.roomState;
	}

	public void setRoomState(RoomStateCache roomState) {
		this.roomState = roomState;
	}

	public boolean isReload() {
		return reload;
	}

	public void setReload(boolean reload) {
		this.reload = reload;
	}

	@Override
	public String toString() {
		return String.format("房间ID:%s", this.idStr);
	}

}
