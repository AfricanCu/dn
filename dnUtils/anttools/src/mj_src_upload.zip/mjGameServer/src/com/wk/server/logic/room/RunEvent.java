package com.wk.server.logic.room;

public class RunEvent {

	/**
	 * 这个事件持续多久
	 */
	// final timeInSecond;
}
