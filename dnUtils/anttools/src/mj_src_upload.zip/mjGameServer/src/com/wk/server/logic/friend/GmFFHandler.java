package com.wk.server.logic.friend;

import java.sql.SQLException;

import msg.InnerMessage.GmBusToGsbk;

import org.json.JSONObject;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.FriendBean;
import com.wk.bean.NTxtAbs;
import com.wk.engine.inner.BusConnect;
import com.wk.engine.net.InnerMsgId;
import com.wk.enun.GmType;
import com.wk.logic.config.NTxt;
import com.wk.server.ibatis.select.User;
import com.wk.server.logic.item.ItemTemplate;
import com.wk.server.logic.login.LoginModule;
import com.wk.user.bean.UserBean;
import com.wk.user.enm.ExpiresInType;

public class GmFFHandler extends FindUserHandlerI {
	private final JSONObject json;
	private final GmType gmType;
	private final String reqId;

	public GmFFHandler(long uid, GmType gmType, JSONObject json, String reqId) {
		super(null, uid, 0, false, false);
		this.gmType = gmType;
		this.json = json;
		this.reqId = reqId;
		handle();
	}

	@Override
	public int currentServerUnloadProcess(UserBean userBean) {
		BusConnect.getInstance().sendMessage(
				InnerMsgId.GmBusToGsbk,
				GmBusToGsbk.newBuilder().setCode(NTxt.UN_LOAD_USER)
						.setReqId(this.reqId));
		return NTxt.SUCCESS;
	}

	@Override
	public int currentServerProcess(User friendUserI) {
		switch (gmType) {
		case addDiamond:
			addDiamond(friendUserI);
			return NTxt.SUCCESS;
		case fenghao:
			fenghao(friendUserI);
			return NTxt.SUCCESS;
		default:
			BusConnect.getInstance().sendMessage(
					InnerMsgId.GmBusToGsbk,
					GmBusToGsbk.newBuilder().setCode(NTxt.NOT_IMPLEMENT)
							.setReqId(this.reqId));
		}
		return NTxt.SUCCESS;
	}

	private void fenghao(User user) {
		boolean feng = json.optBoolean("feng");
		if (feng) {
			user.setExpires_in(ExpiresInType.feng.getType());
			if (user.isOnline()) {
				LoginModule.getInstance().kick(user.getUid());
			}
		} else {
			user.setExpires_in(ExpiresInType.nofeng.getType());
		}
		BusConnect.getInstance().sendMessage(
				InnerMsgId.GmBusToGsbk,
				GmBusToGsbk.newBuilder().setCode(NTxtAbs.SUCCESS)
						.setReqId(this.reqId));
	}

	private void addDiamond(User user) {
		int diamond = Integer.parseInt(json.optString("diamond"));
		String proxy = json.optString("uid");
		try {
			user.addItem(ItemTemplate.Diamond_ID, diamond, true,
					NTxt.GM_ADD_DIAMOND);
			user.save();
			BusConnect.getInstance().sendMessage(
					InnerMsgId.GmBusToGsbk,
					GmBusToGsbk.newBuilder().setCode(NTxtAbs.SUCCESS)
							.setReqId(this.reqId));
		} catch (SQLException e) {
			LoggerService.getChargeLog().error(
					String.format("代理给玩家加钻，代理id:%s,钻:%s,当前：%s,error:%s", proxy,
							diamond, e.getMessage()), e);
			BusConnect.getInstance().sendMessage(
					InnerMsgId.GmBusToGsbk,
					GmBusToGsbk.newBuilder().setCode(NTxtAbs.SQL_EXCEPTION)
							.setReqId(this.reqId));
		}
	}

	@Override
	public void handleCode(int code) {
		// TODO Auto-generated method stub
	}

}
