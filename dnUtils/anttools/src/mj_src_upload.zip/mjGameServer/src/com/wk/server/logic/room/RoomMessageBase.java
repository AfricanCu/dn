package com.wk.server.logic.room;

import java.util.concurrent.ScheduledFuture;

import msg.BackMessage.BattleBackSm;
import msg.BackMessage.InitPai;
import msg.LoginMessage.GameRecordSm;
import msg.LoginMessage.Round;
import msg.MjMessage.AnGangPaiCast;
import msg.MjMessage.AnGangPaiSm;
import msg.MjMessage.BaoTingSm;
import msg.MjMessage.ChiPaiCast;
import msg.MjMessage.ChiPaiSm;
import msg.MjMessage.DaPaiCast;
import msg.MjMessage.DaPaiSm;
import msg.MjMessage.FaPaiCast;
import msg.MjMessage.HaiDiZhuaPaiCast;
import msg.MjMessage.HuResult;
import msg.MjMessage.JieGangCast;
import msg.MjMessage.JieGangSm;
import msg.MjMessage.MingGangPaiCast;
import msg.MjMessage.MingGangPaiSm;
import msg.MjMessage.Niao;
import msg.MjMessage.PengPaiCast;
import msg.MjMessage.PengPaiSm;
import msg.MjMessage.RoundResult;
import msg.MjMessage.RoundResultCast;
import msg.MjMessage.SeetZhuaPaiCast;
import msg.MjMessage.ZhuaPaiCast;
import msg.RoomMessage.MemberDissolveRoomCast;
import msg.RoomMessage.ProxyRoom;

import com.wk.I.ByteBufferSerializable;
import com.wk.logic.config.NTxt;

public abstract class RoomMessageBase implements ByteBufferSerializable {
	// game
	/** 代理开房消息 **/
	protected transient ProxyRoom proxyRoom;
	/** 玩家同意解散房间推送 */
	protected transient final MemberDissolveRoomCast.Builder memberDissolveRoomCast = MemberDissolveRoomCast
			.newBuilder();
	/*** 游戏记录 **/
	protected transient final GameRecordSm.Builder gameRecordSm = GameRecordSm
			.newBuilder();
	/*** -- 局记录 */
	protected transient final Round.Builder roundBuilder = Round.newBuilder();
	// round
	/** 发牌广播 */
	protected transient final FaPaiCast.Builder faPaiCast = FaPaiCast
			.newBuilder();
	/** 局结算广播 */
	protected transient final RoundResultCast.Builder roundResultCast = RoundResultCast
			.newBuilder();
	/*** -- 鸟 */
	protected transient final Niao.Builder niao = Niao.newBuilder();
	/*** -- 胡牌结果 */
	protected transient final HuResult.Builder huResult = HuResult.newBuilder();
	/*** -- 局结果 */
	protected transient final RoundResult.Builder roundResult = RoundResult
			.newBuilder();
	/** 战斗回放 */
	protected transient final BattleBackSm.Builder battleBackSm = BattleBackSm
			.newBuilder();
	/** -- 初始牌 */
	protected transient final InitPai.Builder initPai = InitPai.newBuilder();
	// tmp
	/** 抓牌广播 */
	protected transient final ZhuaPaiCast.Builder zhuaPaiCast = ZhuaPaiCast
			.newBuilder();
	/** 海底自动操作广播 */
	protected transient final HaiDiZhuaPaiCast.Builder haiDiZhuaPaiCast = HaiDiZhuaPaiCast
			.newBuilder();
	/** 谁抓牌广播 **/
	protected transient final SeetZhuaPaiCast.Builder seetZhuaPaiCast = SeetZhuaPaiCast
			.newBuilder();
	/** 暗杠牌广播 */
	protected transient final AnGangPaiCast.Builder anGangPaiCast = AnGangPaiCast
			.newBuilder();
	/** 明杠牌广播 */
	protected transient final MingGangPaiCast.Builder mingGangPaiCast = MingGangPaiCast
			.newBuilder();
	/** 打牌广播 */
	protected transient final DaPaiCast.Builder daPaiCast = DaPaiCast
			.newBuilder();
	/** 接杠广播 */
	protected transient final JieGangCast.Builder jieGangCast = JieGangCast
			.newBuilder();
	/** 碰牌广播 */
	protected transient final PengPaiCast.Builder pengPaiCast = PengPaiCast
			.newBuilder();
	/** 吃牌广播 */
	protected transient final ChiPaiCast.Builder chiPaiCast = ChiPaiCast
			.newBuilder();
	protected transient final AnGangPaiSm.Builder anGangPaiSm = AnGangPaiSm
			.newBuilder();
	protected transient final MingGangPaiSm.Builder mingGangPaiSm = MingGangPaiSm
			.newBuilder();
	protected transient final JieGangSm.Builder jieGangSm = JieGangSm
			.newBuilder();
	protected transient final PengPaiSm.Builder pengPaiSm = PengPaiSm
			.newBuilder();
	protected transient final ChiPaiSm.Builder chiPaiSm = ChiPaiSm.newBuilder();
	protected transient final DaPaiSm.Builder daPaiSm = DaPaiSm.newBuilder();
	protected transient final BaoTingSm.Builder baoTingSm = BaoTingSm
			.newBuilder();

	/**
	 * 初始化
	 */
	public void init() {
		this.memberDissolveRoomCast.clear();
		this.gameRecordSm.clear().setCode(NTxt.SUCCESS);
		this.proxyRoom = null;
	}

	/**
	 * 下一局
	 */
	protected void nextRound() {
		this.faPaiCast.clear();
		this.roundResultCast.clear();
		this.battleBackSm.clear().setCode(NTxt.SUCCESS);
	}

	public ProxyRoom getProxyRoom() {
		return this.proxyRoom;
	}

	/** 检测空时效任务 **/
	public static void checkNullTask(ScheduledFuture<?> task) {
		if (task != null) {
			task.cancel(true);
			task = null;
		}
	}

}
