package com.wk.logic.area;

import com.wk.mj.enun.HuPaiType;
import com.wk.play.PlayTypeSet;

public class YING_TANG_JIA_ZHANG extends YING_TANG_FEI_BAO {

	private final static YING_TANG_JIA_ZHANG instance = new YING_TANG_JIA_ZHANG(
			"鹰潭夹张", 4);

	public static YING_TANG_JIA_ZHANG getInstance() {
		return instance;
	}

	public YING_TANG_JIA_ZHANG(String name, int type) {
		super(name, type);
	}

	@Override
	public int getTimes(HuPaiType huPaiType, PlayTypeSet playTypeSet) {
		switch (huPaiType) {
		case pingHu:
			return 0;
		case pengPengHu:
			return 1;
		case shiSanLan:
			return 1;
		case qiXingShiSanLan:
			return 2;
		case hunYiSe:
			return 1;
		case xiaoQiDui:
			return 2;
		case haoHuaXiaoQiDui:
			return 3;
		case doubleHaoHuaXiaoQiDui:
			return 4;
		case threeHaoHuaXiaoQiDui:
			return 5;
		case qingYiSe:
			return 2;
		case qiangGangHu:
			return 1;
		case gangBao:
			return 1;
		case danDiao:
			return 1;
		case jiaZhang:
			return 1;
		default:
			throw new UnsupportedOperationException(String.format(
					"这个地方不支持此胡法的2次幂计算！huPaiType:%s", huPaiType));
		}
	}

	@Override
	public boolean isPingHuJiePao() {
		return false;
	}

	@Override
	public boolean isFeiBao() {
		return false;
	}

	@Override
	public boolean isJiaZhang() {
		return true;
	}
}
