package com.wk.logic.area;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import msg.RoomMessage.PlayType;

import com.wk.mj.enun.HuPaiType;
import com.wk.play.PlayTypeSet;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

public class YUAN_JIANG extends AreaType {

	public final static List<TimesLimitType> timesList = Arrays.asList(
			TimesLimitType._24Times, TimesLimitType._noLimitTimes);
	private final static YUAN_JIANG instance = new YUAN_JIANG();

	public static YUAN_JIANG getInstance() {
		return instance;
	}

	/**  */
	private YUAN_JIANG() {
		super("沅江麻将", 1, timesList);
	}

	@Override
	public int getTimes(HuPaiType huPaiType, PlayTypeSet playTypeSet) {
		switch (huPaiType) {
		case pingHu:
			return 0;
		case mengQing:
			if (playTypeSet.isMengQing()) {
				return 1;
			}
			break;
		case tianHu:
			return 1;
		case baoTing:
			return 1;
		case jiangJiangHu:
			return 1;
		case qingYiSe:
			return 1;
		case yiTiaoLong:
			return 1;
		case pengPengHu:
			return 1;
		case xiaoQiDui:
			return 1;
		case haoHuaXiaoQiDui:
			return 2;
		case doubleHaoHuaXiaoQiDui:
			return 3;
		case threeHaoHuaXiaoQiDui:
			return 4;
		case haiDi:
			return 1;
		case qiangGangHu:
			return 1;
		case gangBao:
			return 1;
		case yiZiQiao:
			return 1;
		default:
			throw new UnsupportedOperationException(String.format(
					"这个地方不可能出现此胡法！huPaiType:%s", huPaiType));
		}
		throw new UnsupportedOperationException(String.format(
				"设置的玩法不包括此胡法！huPaiType:%s", huPaiType));
	}

	@Override
	public int calcFan(ArrayList<HuPaiType> arrayList, PlayTypeSet playTypeSet) {
		int sumDaHu = 0;
		for (HuPaiType type : arrayList) {
			int times = getTimes(type, playTypeSet);
			if (times > 0)
				sumDaHu += times;
		}
		if (sumDaHu > 1) {
			return 3 * (int) Math.pow(2, sumDaHu - 1);
		} else if (sumDaHu == 1) {
			return 3;
		} else {
			return 1;
		}
	}

	@Override
	public List<String> getPlayTypeDesc(PlayType playType) {
		List<String> list = new ArrayList<String>();
		list.add(this.getName());
		list.add(BankerMode.getEnum(playType.getBankerMode()).getName());
		if (playType.getBaoTing()) {
			list.add("报听");
		} else if (playType.getDiHu()) {
			list.add("地胡");
		}
		if (playType.getMenQing()) {
			list.add("门清");
			if (playType.getJiangJiangHu()) {
				list.add("门清将将胡可接炮");
			}
		}
		return list;
	}

	@Override
	public SeveralNiaoType getSeveralNiaoType(PlayType playType) {
		return SeveralNiaoType.one;
	}

	@Override
	public ZhaNiaoType getZhaNiaoType(PlayType playType) {
		return ZhaNiaoType.feiNiao;
	}

	@Override
	public boolean isBaoTing(PlayType playType) throws Exception {
		return true;
	}

	@Override
	public boolean isDiHu(PlayType playType) throws Exception {
		return false;
	}

	@Override
	public boolean isYiTiaoLong() {
		return true;
	}

	@Override
	public boolean isYiZiQiao() {
		return true;
	}

	@Override
	public boolean isJiangJianghu() {
		return true;
	}

	@Override
	public boolean isRightNowZhuaCanMingGang() {
		return true;
	}

	@Override
	public boolean isJiePaoJiangNiao() {
		return true;
	}

	@Override
	public boolean isPinghuBaoTingJiePao() {
		return true;
	}

	@Override
	public boolean isBaoTingOverJiePaoNextNot() {
		return true;
	}

	@Override
	public boolean isHaiDi() {
		return true;
	}

	@Override
	public HuPaiType getQuanQiuRenType() {
		return HuPaiType.yiZiQiao;
	}
}
