import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.net.URLEncoder;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import msg.BackMessage.BattleBackSm;
import msg.BackMessage.BattleBackSm.Builder;
import msg.BackMessage.SeetOpera;
import msg.MjMessage.Mj;
import msg.RoomMessage.JoinRoomCm;

import org.xml.sax.SAXException;

import com.ibatis.common.beans.ClassInfo;
import com.jery.ngsp.server.InterfaceFactoryManager;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.FriendBean;
import com.wk.bean.RoomBean;
import com.wk.db.IbatisDbServer;
import com.wk.db.dao.RoomDao;
import com.wk.engine.config.ServerConfig;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.OperaType;
import com.wk.server.logic.room.SerializeObj;
import com.wk.user.dao.UserDao;

public class testDb {
	public static void main(String[] args) throws Exception {
		ServerConfig.init();
		LoggerService.initDef();
		List<RoomBean> roomsByServerId = RoomDao.roomsByServerId(2);
		for (RoomBean bean : roomsByServerId) {
			if (bean.getId() == 8848) {
				ByteBuf in = Unpooled.buffer();
				in.writeBytes(bean.getBack());
				SerializeObj serializeObj = new SerializeObj(in);
				Builder mergeFrom = BattleBackSm.newBuilder().mergeFrom(
						serializeObj.getBattleBackSm_byteArray());
				for (SeetOpera op : mergeFrom.getOperaList()) {
					if (op.getSIndex() == 1) {
						OperaType opera = OperaType.getEnum(op.getOpera());
						Mj mj = op.getMj();
						ChiType chiType = ChiType.getEnum(op.getChi());
						LoggerService.getLogicLog().error("{} {} {}",
								new Object[] { opera, mj, chiType });
					}
				}

			}
		}
		System.err.println(roomsByServerId.size());
	}

	public static void main223(String[] args) {
		Class clazz = JoinRoomCm.newBuilder().getClass();
		Field[] allFields = clazz.getDeclaredFields();
		ClassInfo classInfo = ClassInfo.getInstance(clazz);
		for (Field f : allFields) {
			if (Modifier.isPrivate(f.getModifiers())
					&& !Modifier.isStatic(f.getModifiers())
					&& !Modifier.isFinal(f.getModifiers())
					&& !(f.getName().equals("bitField0_")
							|| f.getName().equals("memoizedIsInitialized") || f
							.getName().equals("memoizedSerializedSize"))) {
				System.err.println(f.getName() + f.getType());
				Method setter = classInfo.getSetter(f.getName().substring(0,
						f.getName().length() - 1));
				Class<?> parameterTypes = setter.getParameterTypes()[0];
				System.err.println(parameterTypes);
			}
		}
	}

	public static void main33(String[] args) throws FileNotFoundException,
			SAXException, IOException, Exception {
		ServerConfig.init();
		LoggerService.initDef();
	}

	public static void main3(String[] args) throws FileNotFoundException,
			SAXException, IOException, Exception {
		ServerConfig.init();
		LoggerService.initDef();
		String replaceSensitiveWord = InterfaceFactoryManager
				.getInterfaceFactory().getDirtyWordsManager()
				.replaceSensitiveWord("fasfsfasd##saf系统管理员asdfd", "**", true);
		System.err.println(replaceSensitiveWord);
		// LoggerService.initDef();
		int[] aa = new int[] { 1, 2, 3, 4, 5, 6 };
		IbatisDbServer.getGmSqlMapper().startTransaction();
		try {
			for (int id : aa) {
				try {
					int resetRoom = RoomDao.resetRoom(id);
					if (resetRoom != 1) {
						LoggerService.getLogicLog().error("没有重置房间成功！roomId:{}",
								id);
					}
					LoggerService.getLogicLog().error("{}", resetRoom);
				} catch (SQLException e) {
					LoggerService.getLogicLog().error(e.getMessage(), e);
					LoggerService.getLogicLog().error("没有重置房间成功！roomId:{}", id);
				}
			}
			IbatisDbServer.getGmSqlMapper().commitTransaction();
		} finally {
			IbatisDbServer.getGmSqlMapper().endTransaction();
		}
	}

	public static void main22(String[] args) throws FileNotFoundException,
			SAXException, IOException, Exception {
		// ServerConfig.init();
		LoggerService.initDef();
		String checkDirtyWord = InterfaceFactoryManager.getInterfaceFactory()
				.getDirtyWordsManager().checkDirtyWord("诱惑", true);
		System.out.println(checkDirtyWord);
		boolean checkUnseeChar = InterfaceFactoryManager.getInterfaceFactory()
				.getDirtyWordsManager().checkUnseeChar("adfsdfasdfadeeess狼的诱惑");
		System.out.println(checkUnseeChar);
		// int serverIdByRoomId = RoomDao.serverIdByRoomId(111111);
		// System.err.println(serverIdByRoomId);
		// UserBean queryUser = UserDao.queryUser("101");
		// UserBean queryUser2 = UserDao.queryUser("101");
		// UserBean queryUser3 = UserDao.queryUser("102");
		// UserBean queryUser4 = UserDao.queryUser("103");
		// UserBean queryUser5 = UserDao.queryUser("104");
		// UserBean queryUser6 = UserDao.queryUser("105");
		// UserBean queryUser7 = UserDao.queryUser("106");
		// queryUser.setCoin(1111);
		// queryUser.setDiamond(2222);
		// UserDao.insertUser(queryUser);
		String encode = URLEncoder.encode("狼的诱惑1.1外网包.apk", "utf8");
		System.err.println(encode);
	}

}
