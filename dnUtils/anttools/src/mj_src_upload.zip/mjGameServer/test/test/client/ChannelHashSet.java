package test.client;

import io.netty.channel.Channel;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class ChannelHashSet extends HashMap<String, Channel> {

	private static final long serialVersionUID = 1L;

	private void closeXx(Channel remove) {
		if (remove == null) {
			return;
		}
		remove.close();
		ClientFrame.clientFrame.channelCount.setText(this.size() + "");
		ClientFrame.clientFrame.channelComboBox.removeItem(MessageImpl
				.getChannel(remove, TestClient.item_index));
	}

	public Channel remove(Object key) {
		Channel remove = super.remove(key);
		closeXx(remove);
		return remove;
	};

	public Channel put(String key, Channel value) {
		if (key == null || value == null) {
			return null;
		}
		Channel add = super.put(key, value);
		ClientFrame.clientFrame.channelCount.setText(this.size() + "");
		ChannelItem item = (ChannelItem) MessageImpl.getChannel(value,
				TestClient.item_index);
		ClientFrame.clientFrame.channelComboBox.addItem(item);
		ClientFrame.clientFrame.selectMe(value);
		return add;
	}
}