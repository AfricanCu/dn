package test.client;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import msg.LoginMessage.LoginSm;
import msg.LoginMessage.SwLoginSm;
import msg.MjMessage.AnGangPaiSm;
import msg.MjMessage.BaoTingSm;
import msg.MjMessage.ChiPaiSm;
import msg.MjMessage.DaPaiSm;
import msg.MjMessage.JieGangSm;
import msg.MjMessage.MingGangPaiSm;
import msg.MjMessage.Mj;
import msg.MjMessage.MyRoundInfo;
import msg.MjMessage.OverSm;
import msg.MjMessage.PengPaiSm;
import msg.MjMessage.ReconnectSm;
import msg.MjMessage.TargetMj;
import msg.MjMessage.UserRoundInfo;
import msg.RoomMessage.CreateRoomBeforeSm;
import msg.RoomMessage.CreateRoomCm;
import msg.RoomMessage.CreateRoomSm;
import msg.RoomMessage.DissolveRoomSm;
import msg.RoomMessage.JoinRoomBeforeCm;
import msg.RoomMessage.JoinRoomBeforeSm;
import msg.RoomMessage.JoinRoomSm;
import msg.RoomMessage.JulebuRoom;
import msg.RoomMessage.LeaveRoomSm;
import msg.RoomMessage.NsCm;
import msg.RoomMessage.PlayType;
import msg.RoomMessage.PrepareRoomCm;
import msg.RoomMessage.PrepareRoomSm;
import msg.RoomMessage.ProxyCreateRoomBeforeSm;
import msg.RoomMessage.ProxyCreateRoomCm;
import msg.RoomMessage.ProxyCreateRoomSm;
import msg.RoomMessage.SwServer;
import msg.RoomMessage.UserInfo;
import test.client.util.ChannelCacheUtil;

import com.google.protobuf.MessageLite;
import com.google.protobuf.MessageLite.Builder;
import com.google.protobuf.MessageLiteOrBuilder;
import com.ibatis.common.beans.ClassInfo;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.NTxtAbs;
import com.wk.engine.net.IoMessage;
import com.wk.engine.net.MessageManager;
import com.wk.logic.config.NTxt;
import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MsgId;
import com.wk.mj.Pai;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.GpcType;
import com.wk.mj.enun.MjType;
import com.wk.util.TimeTaskUtil;

public enum MessageImpl {

	CreateJulebuBefore(MsgId.CreateJulebuBeforeCm) {
		@Override
		public Object getDefaultContent() {
			return create_Room_params;
		}
	},
	JulebuMemberList(MsgId.JulebuMemberListCm) {
	},
	InJulebuBefore(MsgId.InJulebuBeforeCm) {
	},
	InJulebu(MsgId.InJulebuCm) {
	},
	KickJulebuMember(MsgId.KickJulebuMemberCm) {
	},
	ApplyMemberList(MsgId.ApplyMemberListCm) {
	},
	ApplyJulebu(MsgId.ApplyJulebuCm) {
	},
	AgreeApply(MsgId.AgreeApplyCm) {
	},
	DisagreeApply(MsgId.DisagreeApplyCm) {
	},
	Ns(MsgId.NsCm) {
		@Override
		public Object getDefaultContent() {
			return ns_params;
		}
	},
	ProxyCreateRoomBefore(MsgId.ProxyCreateRoomBeforeCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			ProxyCreateRoomBeforeSm joinRoomBeforeSm = (ProxyCreateRoomBeforeSm) msg
					.genMessageLite();
			if (joinRoomBeforeSm.getCode() == NTxt.SUCCESS) {
				sendMessage(
						ctx,
						MsgId.ProxyCreateRoomCm,
						ProxyCreateRoomCm.newBuilder().setPlayType(
								joinRoomBeforeSm.getPlayType()));
			} else if (joinRoomBeforeSm.getCode() == NTxt.SERVER_NEED_SWITCH) {
				this.sw(ctx, joinRoomBeforeSm.getSw());
			} else {
				LoggerService.getLogicLog().warn("代理创建房间预处理失败！code:{}",
						joinRoomBeforeSm.getCode());
			}
		}

		@Override
		public Object getDefaultContent() {
			return create_Room_params;
		}
	},
	CreateRoomBefore(MsgId.CreateRoomBeforeCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			CreateRoomBeforeSm joinRoomBeforeSm = (CreateRoomBeforeSm) msg
					.genMessageLite();
			if (joinRoomBeforeSm.getCode() == NTxt.SUCCESS) {
				sendMessage(ctx, MsgId.CreateRoomCm, CreateRoomCm.newBuilder()
						.setPlayType(joinRoomBeforeSm.getPlayType()));
			} else if (joinRoomBeforeSm.getCode() == NTxt.SERVER_NEED_SWITCH) {
				this.sw(ctx, joinRoomBeforeSm.getSw());
			} else {
				LoggerService.getLogicLog().warn("创建房间预处理失败！code:{}",
						joinRoomBeforeSm.getCode());
			}
		}

		@Override
		public Object getDefaultContent() {
			return create_Room_params;
		}
	},
	JoinRoomBefore(MsgId.JoinRoomBeforeCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			JoinRoomBeforeSm joinRoomBeforeSm = (JoinRoomBeforeSm) msg
					.genMessageLite();
			if (joinRoomBeforeSm.getCode() == NTxt.SUCCESS) {
				MessageImpl.JoinRoom.sendMessage(ctx,
						joinRoomBeforeSm.getRoomId());
			} else if (joinRoomBeforeSm.getCode() == NTxt.SERVER_NEED_SWITCH) {
				this.sw(ctx, joinRoomBeforeSm.getSw());
			} else {
				LoggerService.getLogicLog().warn("加入房间预处理失败！！{}",
						joinRoomBeforeSm.getCode());
			}
		}
	},
	BattleBack(MsgId.BattleBackCm) {
	},
	QiangGang(MsgId.QiangGangCm) {
	},
	Reconnect(MsgId.ReconnectCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			ReconnectSm reconnectSm = (ReconnectSm) msg.genMessageLite();
			if (reconnectSm.getCode() == NTxt.SUCCESS) {
				for (UserInfo user : reconnectSm.getUsersList())
					if (user.getUid() == (long) getChannel(ctx,
							TestClient.uidIndex)) {
						GameState gameState = GameState.getEnum(user
								.getGstate());
						putChannel(ctx, TestClient.gameStateIndex, gameState);
						putChannel(ctx, TestClient.seatIndex,
								user.getSeetIndex());
						switch (gameState) {
						case noStart:
							sendMessage(ctx.channel(), MsgId.PrepareRoomCm,
									PrepareRoomCm.newBuilder(), 0);
							break;
						case ziMoAnGangMingGangGuo:
						case baoTing:
						case jiePaoJieGangPengChiGuo:
							ClientFrame.clientFrame.selectMe(ctx);
							break;
						default:
							break;
						}
					}
				for (UserRoundInfo userr : reconnectSm.getUsersRoundList()) {
					// StringBuilder builder = new StringBuilder();
					// for (Mj mj : userr.getMjList()) {
					// builder.append(Pai.getPai(mj)).append(",");
					// }
					// System.err.println((int) getChannel(ctx,
					// TestClient.seatIndex)
					// + ","
					// + userr.getSeetIndex()
					// + "," + builder);
					if (userr.getSeetIndex() != (int) getChannel(ctx,
							TestClient.seatIndex)) {
						continue;
					}
					for (TargetMj gpc : userr.getGpcList()) {
						GpcType type = GpcType.getEnum(gpc.getType());
						switch (type) {
						case AnGang:
							ChannelCacheUtil.addMjs(ctx,
									TestClient.haveAnGangIndex, gpc.getMj());
							break;
						case MingGang:
							ChannelCacheUtil.addMjs(ctx,
									TestClient.haveMingGangIndex, gpc.getMj());
							break;
						case JieGang:
							ChannelCacheUtil.addMjs(ctx,
									TestClient.haveJieGangIndex, gpc.getMj());
							break;
						case Peng:
							ChannelCacheUtil.addMjs(ctx,
									TestClient.havePengIndex, gpc.getMj());
							break;
						case Chi:
							ChiType chiType = ChiType.getEnum(gpc.getChi());
							Pai[] pais = ChiType.getPais(chiType,
									Pai.getPai(gpc.getMj()));
							ChannelCacheUtil.addMjs(ctx,
									TestClient.haveChiIndex, gpc.getMj(),
									pais[0].getMj(), pais[1].getMj());
							break;
						default:
							break;
						}
					}
				}
				MyRoundInfo my = reconnectSm.getMy();
				if (reconnectSm.getStart()) {
					putChannel(ctx, TestClient.baoTingIndex, my.getBaoTing());
					// LoggerService.getPlatformLog().error("puid:{},重连牌数:{}",
					// getChannel(ctx, TestClient.puidIndex),
					// my.getPaisList().size());
					ChannelCacheUtil.addMjs(ctx, my.getPaisList());
				}
			}
		}
	},
	BaoTing(MsgId.BaoTingCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			BaoTingSm baoTingSm = (BaoTingSm) msg.genMessageLite();
			if (baoTingSm.getCode() != NTxt.SUCCESS) {
				return;
			}
			putChannel(ctx, TestClient.isBaoTingIndex, baoTingSm.getBaoTing());
			putChannel(ctx, TestClient.baoTingIndex, false);
		}
	},
	CreateRoom(MsgId.CreateRoomCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			CreateRoomSm createRoomSm = (CreateRoomSm) msg.genMessageLite();
			if (createRoomSm.getCode() == NTxt.SUCCESS) {
				putChannel(ctx, TestClient.roomIdIndex,
						createRoomSm.getRoomId());
				putChannel(ctx, TestClient.seatIndex, createRoomSm.getInfo()
						.getSeetIndex());
				sendMessage(ctx.channel(), MsgId.PrepareRoomCm,
						PrepareRoomCm.newBuilder(), 500);
				sendMessage(ctx, MsgId.NsCm, NsCm.newBuilder());
				if (TestClient.isRobotMaster(ctx)) {
					List<Channel> members = TestClient.getMembers(ctx);
					if (members != null)
						for (Channel member : members) {
							sendMessage(
									member,
									MsgId.JoinRoomBeforeCm,
									JoinRoomBeforeCm.newBuilder().setRoomId(
											createRoomSm.getRoomId()), 2000);
						}
				}
			} else {
				LoggerService.getLogicLog().warn("创建房间失败！{}",
						createRoomSm.getCode());
			}
		}

		@Override
		public Object getDefaultContent() {
			return create_Room_params;
		}
	},
	ProxyCreateRoom(MsgId.ProxyCreateRoomCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			ProxyCreateRoomSm createRoomSm = (ProxyCreateRoomSm) msg
					.genMessageLite();
			if (createRoomSm.getCode() == NTxt.SUCCESS) {
				LoggerService.getLogicLog().warn("代房间成功！{}",
						createRoomSm.getRoomId());
			} else {
				LoggerService.getLogicLog().warn("创建房间失败！{}",
						createRoomSm.getCode());
			}
		}

		@Override
		public Object getDefaultContent() {
			return create_Room_params;
		}
	},
	GameRecord(MsgId.GameRecordCm) {
	},
	MemberDissolveRoom(MsgId.MemberDissolveRoomCm) {
	},
	Prepare(MsgId.PrepareRoomCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			PrepareRoomSm loginSm = (PrepareRoomSm) msg.genMessageLite();
			if (loginSm.getCode() == NTxt.SUCCESS) {
				putChannel(ctx, TestClient.gameStateIndex, GameState.prepared);
			}
		}
	},
	Login(MsgId.LoginCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			LoginSm loginSm = (LoginSm) msg.genMessageLite();
			if (loginSm.getCode() == NTxt.SUCCESS) {
				// System.err.println(loginSm.getHeadimg());
				putChannel(ctx, TestClient.nicknameIndex, loginSm.getNickname());
				putChannel(ctx, TestClient.roomIdIndex, loginSm.getRoomId());
				if (!loginSm.getRoomId().equals("")) {
					Reconnect.sendMessage(ctx, null);
					if (TestClient.isRobotMaster(ctx)) {
						List<Channel> members = TestClient.getMembers(ctx);
						if (members != null)
							for (Channel member : members) {
								sendMessage(member, MsgId.JoinRoomBeforeCm,
										JoinRoomBeforeCm.newBuilder()
												.setRoomId(loginSm.getRoomId()));
							}
					}
				} else {
					if (TestClient.isRobotMaster(ctx))// 机器人自动创房
						CreateRoomBefore.sendMessage(ctx, create_Room_params);
				}
			} else {
				LoggerService.getLogicLog().warn("登陆失败！{}", loginSm.getCode());
				ctx.channel().close();
			}
		}
	},
	SwLogin(MsgId.SwLoginCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			SwLoginSm swLoginSm = (SwLoginSm) msg.genMessageLite();
			if (swLoginSm.getCode() == NTxt.SUCCESS) {
				LoginSm loginSm = swLoginSm.getLoginSm();
				putChannel(ctx, TestClient.nicknameIndex, loginSm.getNickname());
				putChannel(ctx, TestClient.roomIdIndex, loginSm.getRoomId());
				if (!loginSm.getRoomId().equals("")) {
					Reconnect.sendMessage(ctx, null);
				} else {
					if (TestClient.isRobotMaster(ctx))
						CreateRoomBefore.sendMessage(ctx, create_Room_params);
				}
				LoggerService.getLogicLog().warn("切服登陆成功！{}",
						swLoginSm.getCode());
			} else {
				LoggerService.getLogicLog().warn("切服登陆失败！{}",
						swLoginSm.getCode());
				ctx.channel().close();
			}
		}
	},
	DissolveRoom(MsgId.DissolveRoomCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			DissolveRoomSm genMessageLite = (DissolveRoomSm) msg
					.genMessageLite();
			if (genMessageLite.getCode() == NTxtAbs.SUCCESS) {
				putChannel(ctx, TestClient.roomIdIndex, "");
			}
		}
	},
	LeaveRoom(MsgId.LeaveRoomCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			LeaveRoomSm genMessageLite = (LeaveRoomSm) msg.genMessageLite();
			if (genMessageLite.getCode() == NTxtAbs.SUCCESS) {
				putChannel(ctx, TestClient.roomIdIndex, "");
			}
		}
	},
	JoinRoom(MsgId.JoinRoomCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			JoinRoomSm joinRoomSm = (JoinRoomSm) msg.genMessageLite();
			if (joinRoomSm.getCode() == NTxt.SUCCESS) {
				LoggerService.getLogicLog().error("join room :{}",
						joinRoomSm.getRoomId());
				putChannel(ctx, TestClient.roomIdIndex, joinRoomSm.getRoomId());
				putChannel(ctx, TestClient.seatIndex, joinRoomSm.getSeatIndex());
				sendMessage(ctx, MsgId.PrepareRoomCm,
						PrepareRoomCm.newBuilder());
			} else {
				LoggerService.getLogicLog().warn("加入房间失败！{}",
						joinRoomSm.getCode());
			}
		}

		@Override
		public Object getDefaultContent() {
			return "0#0,0";
		}
	},
	AnGangPai(MsgId.AnGangPaiCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			AnGangPaiSm daPaiSm = (AnGangPaiSm) msg.genMessageLite();
			if (daPaiSm.getCode() == NTxt.SUCCESS) {
				Mj[] mjs = new Mj[4];
				Arrays.fill(mjs, daPaiSm.getMj());
				ChannelCacheUtil.removeMjs("暗杠", ctx, mjs);
				ChannelCacheUtil.addMjs(ctx, TestClient.haveAnGangIndex,
						daPaiSm.getMj());
				ChannelCacheUtil.resetList(ctx, TestClient.mingGangListIndex,
						new ArrayList<>());
			}
		}
	},
	MingGangPai(MsgId.MingGangPaiCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			MingGangPaiSm daPaiSm = (MingGangPaiSm) msg.genMessageLite();
			if (daPaiSm.getCode() == NTxt.SUCCESS) {
				ChannelCacheUtil.resetList(ctx, TestClient.mingGangListIndex,
						new ArrayList<>());
				ChannelCacheUtil.removeMjs("明杠", ctx, daPaiSm.getMj());
				ChannelCacheUtil.addMjs(ctx, TestClient.haveMingGangIndex,
						daPaiSm.getMj());
				ChannelCacheUtil.removeMjs(ctx, TestClient.havePengIndex,
						daPaiSm.getMj());
			}
		}
	},
	DaPai(MsgId.DaPaiCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			DaPaiSm daPaiSm = (DaPaiSm) msg.genMessageLite();
			if (daPaiSm.getCode() == NTxt.SUCCESS) {
				ChannelCacheUtil.removeMjs("打牌", ctx, daPaiSm.getMj());
			}
		}
	},
	ZiMoPai(MsgId.ZiMoPaiCm) {
	},
	JiePao(MsgId.JiePaoCm) {
	},
	JieGang(MsgId.JieGangCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			JieGangSm daPaiSm = (JieGangSm) msg.genMessageLite();
			if (daPaiSm.getCode() == NTxt.SUCCESS) {
				MessageImpl.putChannel(ctx, TestClient.jieGangIndex, null);
			}
		}
	},
	Peng(MsgId.PengPaiCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			PengPaiSm daPaiSm = (PengPaiSm) msg.genMessageLite();
			if (daPaiSm.getCode() == NTxt.SUCCESS) {
				MessageImpl.putChannel(ctx, TestClient.pengIndex, null);
			}
		}
	},
	Chi(MsgId.ChiPaiCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			ChiPaiSm daPaiSm = (ChiPaiSm) msg.genMessageLite();
			if (daPaiSm.getCode() == NTxt.SUCCESS) {
				MessageImpl.putChannel(ctx, TestClient.chiIndex, null);
			}
		}
	},
	Over(MsgId.OverCm) {
		@Override
		public void resp(ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			OverSm overSm = (OverSm) msg.genMessageLite();
			if (overSm.getCode() == NTxt.SUCCESS)
				TestClient.over(ctx);
		}
	},
	;
	/**
	 * <pre>
	 * 	optional float j = 1;//经度
	 * 	optional float w = 2;//纬度
	 * 	optional string ad = 3;//详细地址
	 * 	optional string country = 4;//国家
	 * 	optional string province = 5;//省份
	 * 	optional string city = 6;//城市
	 * 	optional string district = 7;//地区
	 * 	optional string street = 8;//街道
	 * 	optional string houseNumber = 9;//门牌号
	 * </pre>
	 */
	public static final String ns_params = "1.0,1.0,xxx,xx,x,dd,ff,ee,11";
	/** 创房参数 */
	public static final String create_Room_params = "1,1,true,true,true,true,true,true,1,1";
	public static final String REG = "#";
	// PlayType内容分割
	public static final String DOT = ",";
	private final MsgId msgId;
	private final ArrayList<Method> setterList = new ArrayList<>();
	private final ArrayList<Class<?>> paraClazzList = new ArrayList<>();
	private final String tips;

	private MessageImpl(MsgId msgId) {
		this.msgId = msgId;
		Class<? extends Builder> builderClazz = msgId.genMessageLiteBuilder()
				.getClass();
		tips = genTips(builderClazz, setterList, paraClazzList, REG)
				// playType
				.replace("PlayType:playType",
						genTips(PlayType.Builder.class, null, null, DOT))
				// mj
				.replace("Mj:mj", genTips(Mj.Builder.class, null, null, DOT))
				// julebuRoom
				.replace("JulebuRoom:julebuRoom",
						genTips(JulebuRoom.Builder.class, null, null, DOT));
	}

	public static String genTips(Class<?> builderClazz,
			ArrayList<Method> setterList, ArrayList<Class<?>> paraClazzList,
			String REG) {
		Field[] allFields = builderClazz.getDeclaredFields();
		ClassInfo classInfo = ClassInfo.getInstance(builderClazz);
		StringBuilder builder = new StringBuilder();
		for (Field f : allFields) {
			if (Modifier.isPrivate(f.getModifiers())
					&& !Modifier.isStatic(f.getModifiers())
					&& !Modifier.isFinal(f.getModifiers())
					&& !(f.getName().equals("bitField0_")
							|| f.getName().equals("memoizedIsInitialized") || f
							.getName().equals("memoizedSerializedSize"))) {
				String name2 = f.getName().substring(0,
						f.getName().length() - 1);
				if (name2.endsWith("Builder")) {
					LoggerService.getLogicLog().error(name2);
					continue;
				}
				if (name2.equals("sId")) {
					LoggerService.getLogicLog().error(name2);
					continue;
				}
				Method setter = classInfo.getSetter(name2);
				Class<?> paraClazz = setter.getParameterTypes()[0];
				builder.append(paraClazz.getSimpleName()).append(":")
						.append(name2).append(REG);
				if (setterList != null)
					setterList.add(setter);
				if (paraClazzList != null)
					paraClazzList.add(paraClazz);
			}
		}
		return builder.toString();
	}

	public MsgId getMsgId() {
		return msgId;
	}

	/***
	 * 
	 * @param ctx
	 * @param msg
	 * @throws Exception
	 */
	public void resp(ChannelHandlerContext ctx, IoMessage msg) throws Exception {
	}

	public MessageLiteOrBuilder sendMessage(ChannelHandlerContext ctx,
			String content) {
		return sendMessage(1, ctx.channel(), content);
	}

	/***/
	public MessageLiteOrBuilder sendMessageWithContent(String content) {
		return sendMessage(1, TestClient.getCurrentChannel(), content);
	}

	/***/
	public MessageLiteOrBuilder sendMessageWithMj(Mj mj) {
		return sendMessage(1, TestClient.getCurrentChannel(), mj == null ? null
				: (mj.getNum() + MessageImpl.DOT + mj.getType()));
	}

	/**
	 * 
	 * @param num
	 *            消息数目
	 * @param channel
	 * @param content
	 * @return
	 */
	public MessageLiteOrBuilder sendMessage(int num, Channel channel,
			String content) {
		MessageLiteOrBuilder message = getMessage(content);
		record(channel, message);
		MessageManager.sendMessage(num, channel, msgId, message);
		return message;
	}

	public void record(Channel channel, MessageLiteOrBuilder message) {
	}

	@Override
	public String toString() {
		return msgId.getName() + "  " + msgId.getType();
	}

	private final static Map<MsgId, MessageImpl> typeMap = new HashMap<>();
	static {
		MessageImpl[] missionStateArr = MessageImpl.values();
		for (int i = 0; i < missionStateArr.length; i++) {
			MessageImpl missionState = missionStateArr[i];
			typeMap.put(missionState.msgId, missionState);
			if (missionState.msgId.getResMsgId() != null)
				typeMap.put(missionState.msgId.getResMsgId(), missionState);
		}
	}

	/**
	 *
	 * @param type
	 * @return
	 */
	public static MessageImpl getEnum(MsgId type) {
		return typeMap.get(type);
	}

	public void sw(ChannelHandlerContext ctx, SwServer swServer) {
		ctx.channel().attr(TestClient.MAP_Attr).get()
				.put(TestClient.swRoomIdIndex, swServer);
		ctx.channel().close();
	}

	public MessageLiteOrBuilder getMessage(String content) {
		String[] split;
		if (content == null || content.equals("")) {
			split = new String[0];
		} else {
			split = content.split(REG);
		}
		if (split.length != this.paraClazzList.size()) {
			LoggerService.getLogicLog().error("消息格式填写错误！！！！！！！！！！！！！！！！{}",
					this.name());
			return null;
		}
		MessageLite.Builder retBuilder = msgId.genMessageLiteBuilder();
		for (int index = 0; index < this.paraClazzList.size(); index++) {
			Class<?> clazz = this.paraClazzList.get(index);
			Method method = this.setterList.get(index);
			String string = split[index];
			try {
				if (clazz == String.class) {
					method.invoke(retBuilder, string);
				} else if (clazz == int.class || clazz == Integer.class) {
					method.invoke(retBuilder, Integer.parseInt(string));
				} else if (clazz == boolean.class || clazz == Boolean.class) {
					method.invoke(retBuilder, Boolean.parseBoolean(string));
				} else if (clazz == long.class || clazz == Long.class) {
					method.invoke(retBuilder, Long.parseLong(string));
				} else if (clazz == PlayType.class) {
					String[] sps = string.split(DOT);
					method.invoke(retBuilder,
							ClientFrame.clientFrame.getPlayType());
				} else if (clazz == Mj.class) {
					String[] sps = string.split(DOT);
					Mj.Builder mjBuilder = Mj
							.newBuilder()
							.setNum(Integer.parseInt(sps[0]))
							.setType(
									MjType.getEnum(Integer.parseInt(sps[1]))
											.getType());
					method.invoke(retBuilder, mjBuilder.build());
				} else if (clazz == JulebuRoom.class) {
					String[] sps = string.split(DOT);
					JulebuRoom.Builder mjBuilder = JulebuRoom.newBuilder()
							.setId(Integer.parseInt(sps[0]))
							.setNum(Integer.parseInt(sps[1]));
					method.invoke(retBuilder, mjBuilder.build());
				} else {
					LoggerService.getLogicLog().error(clazz.getName() + "未实现！");
				}
			} catch (IllegalAccessException | IllegalArgumentException
					| InvocationTargetException e) {
				LoggerService.getLogicLog().error(e.getMessage(), e);
			}
		}
		return retBuilder;
	}

	public static void putChannel(ChannelHandlerContext ctx, String key,
			Object value) {
		putChannel(ctx.channel(), key, value);
	}

	public static void putChannel(Channel channel, String key, Object value) {
		try {
			channel.attr(TestClient.MAP_Attr).get().put(key, value);
			ClientFrame.clientFrame.refreshDisplay(channel, key, value);
		} catch (Exception e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
		}
	}

	/**
	 * 获取缓存
	 * 
	 * @param ctx
	 * @param key
	 * @return
	 */
	public static Object getChannel(ChannelHandlerContext ctx, String key) {
		return getChannel(ctx.channel(), key);
	}

	public Object getDefaultContent() {
		return this.getTips();
	}

	public String getTips() {
		return tips;
	}

	public static Object getChannel(Channel channel, String key) {
		HashMap<String, Object> hashMap = channel.attr(TestClient.MAP_Attr)
				.get();
		return hashMap.get(key);
	}

	/**
	 * 客户端发消息
	 * 
	 * @param channel
	 * @param msgId
	 * @param messageLiteOrBuilder
	 */
	public static void sendMessage(final Channel channel, final MsgId msgId,
			final MessageLiteOrBuilder messageLiteOrBuilder) {
		sendMessage(channel, msgId, messageLiteOrBuilder, 1000);
	}

	public static void sendMessage(final Channel channel, final MsgId msgId,
			final MessageLiteOrBuilder messageLiteOrBuilder, int MILLISECONDS) {
		if (TestClient.isAuto() && MILLISECONDS > 0) {
			TimeTaskUtil.getTaskmanager().submitOneTimeTask(new Runnable() {
				@Override
				public void run() {
					MessageManager.sendMessage(channel, msgId,
							messageLiteOrBuilder);
				}
			}, MILLISECONDS, TimeUnit.MILLISECONDS);
		} else {
			MessageManager.sendMessage(channel, msgId, messageLiteOrBuilder);
		}
	}

	public static void sendMessage(ChannelHandlerContext ctx, MsgId msgId,
			MessageLiteOrBuilder messageLiteOrBuilder) {
		sendMessage(ctx.channel(), msgId, messageLiteOrBuilder);
	}
}
