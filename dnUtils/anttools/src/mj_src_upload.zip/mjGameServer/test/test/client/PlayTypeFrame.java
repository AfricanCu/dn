package test.client;

import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.AbstractButton;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JRadioButton;

import msg.RoomMessage.PlayType;

import com.wk.logic.area.AreaType;
import com.wk.logic.area.YING_TANG_FEI_BAO;
import com.wk.logic.area.YING_TANG_JIA_ZHANG;
import com.wk.logic.area.YUAN_JIANG;
import com.wk.mj.ListMjAbs;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

public class PlayTypeFrame extends ApplicationFrame {

	private ListMjAbs listMjAbs = null;

	public PlayTypeFrame(String title) {
		super(title);
	}

	private static final long serialVersionUID = 1L;
	private final ButtonGroup roundbg = new ButtonGroup();
	private final ButtonGroup fanbg = new ButtonGroup();
	private final ButtonGroup zhaNiaobg = new ButtonGroup();
	public final JCheckBox yiTiaoLongCheck = new JCheckBox("一条龙");
	public final JCheckBox mengQingDaDaHuCheck = new JCheckBox("门清大大胡？");
	public final JCheckBox mengQingJiangJiangHuJiePaoCheck = new JCheckBox(
			"门清将将胡可接炮？");
	public final JRadioButton baoTingRadio = new JRadioButton("报听大胡?");
	public final JRadioButton diHuRadio = new JRadioButton("地胡大胡？");
	public final JCheckBox yiZiQiaoCheck = new JCheckBox("一字撬有喜？");
	private final ButtonGroup niaoBg = new ButtonGroup();
	private final ButtonGroup areaTypebg = new ButtonGroup();
	private ItemListener xx = new ItemListener() {

		@Override
		public void itemStateChanged(ItemEvent e) {
			if (e.getStateChange() == ItemEvent.DESELECTED) {
				return;
			}
			AreaType areaType = getAreaType();
			if (areaType == null) {
				return;
			}
			List<TimesLimitType> timesList;
			if (areaType == YING_TANG_FEI_BAO.getInstance()
					|| areaType == YING_TANG_JIA_ZHANG.getInstance()) {
				timesList = YING_TANG_FEI_BAO.timesList;
			} else {
				timesList = YUAN_JIANG.timesList;
			}
			for (Entry<TimesLimitType, JRadioButton> entry : timesMap
					.entrySet()) {
				if (!timesList.contains(entry.getKey()))
					entry.getValue().setEnabled(false);
				else {
					entry.getValue().setEnabled(true);
					entry.getValue().setSelected(true);
				}
			}
			if (listMjAbs != null) {
				listMjAbs.init(areaType.getPlayTypeSet(getPlayType()));
			}
		}
	};
	private HashMap<TimesLimitType, JRadioButton> timesMap = new HashMap<>();

	public ListMjAbs getListMjAbs() {
		return listMjAbs;
	}

	public void setListMjAbs(ListMjAbs listMjAbs) {
		this.listMjAbs = listMjAbs;
		this.listMjAbs.init(getAreaType().getPlayTypeSet(getPlayType()));
	}

	public void getcreateRoomBox(Box box) {
		Box createRoomBox = new Box(BoxLayout.X_AXIS);
		for (BankerMode area : BankerMode.values()) {
			JRadioButton jRadioButton = new JRadioButton(area.getName());
			roundbg.add(jRadioButton);
			createRoomBox.add(jRadioButton);
		}
		roundbg.getElements().nextElement().setSelected(true);
		for (TimesLimitType area : TimesLimitType.values()) {
			JRadioButton jRadioButton = new JRadioButton(area.getName());
			timesMap.put(area, jRadioButton);
			fanbg.add(jRadioButton);
			createRoomBox.add(jRadioButton);
		}
		fanbg.getElements().nextElement().setSelected(true);
		createRoomBox.add(yiTiaoLongCheck);
		createRoomBox.add(mengQingDaDaHuCheck);
		mengQingDaDaHuCheck.addItemListener(new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					PlayTypeFrame.this.mengQingJiangJiangHuJiePaoCheck
							.setEnabled(true);
				} else {
					PlayTypeFrame.this.mengQingJiangJiangHuJiePaoCheck
							.setSelected(false);
					PlayTypeFrame.this.mengQingJiangJiangHuJiePaoCheck
							.setEnabled(false);
				}
			}
		});
		createRoomBox.add(mengQingJiangJiangHuJiePaoCheck);
		ButtonGroup bg = new ButtonGroup();
		bg.add(baoTingRadio);
		bg.add(diHuRadio);
		createRoomBox.add(this.baoTingRadio);
		createRoomBox.add(this.diHuRadio);
		createRoomBox.add(yiZiQiaoCheck);
		for (ZhaNiaoType area : ZhaNiaoType.values()) {
			JRadioButton jRadioButton = new JRadioButton(area.getName());
			zhaNiaobg.add(jRadioButton);
			createRoomBox.add(jRadioButton);
		}
		zhaNiaobg.getElements().nextElement().setSelected(true);
		yiTiaoLongCheck.doClick();
		mengQingDaDaHuCheck.doClick();
		baoTingRadio.doClick();
		yiZiQiaoCheck.doClick();
		Box xxxx = new Box(BoxLayout.X_AXIS);
		xxxx.add(new JLabel("几个鸟"));
		for (SeveralNiaoType niao : SeveralNiaoType.values()) {
			JRadioButton Niao = new JRadioButton(niao.getName());
			niaoBg.add(Niao);
			xxxx.add(Niao);
		}
		niaoBg.getElements().nextElement().setSelected(true);
		for (AreaType area : AreaType.values()) {
			JRadioButton jRadioButton = new JRadioButton(area.getName());
			areaTypebg.add(jRadioButton);
			jRadioButton.addItemListener(this.xx);
			xxxx.add(jRadioButton);
		}
		areaTypebg.getElements().nextElement().setSelected(true);
		box.add(createRoomBox);
		box.add(Box.createVerticalStrut(0));
		box.add(xxxx);
	}

	public int getNiaoCount() {
		return ((SeveralNiaoType) getSelect(SeveralNiaoType.values(), niaoBg))
				.getType();
	}

	public int getZhaNiao() {
		return ((ZhaNiaoType) getSelect(ZhaNiaoType.values(), zhaNiaobg))
				.getType();
	}

	public int getTimesLimit() {
		return ((TimesLimitType) getSelect(TimesLimitType.values(), fanbg))
				.getType();
	}

	public int getBankerMode() {
		return ((BankerMode) getSelect(BankerMode.values(), roundbg)).getType();
	}

	public AreaType getAreaType() {
		int count = 0;
		for (Enumeration<AbstractButton> e = this.areaTypebg.getElements(); e
				.hasMoreElements(); count++) {
			AbstractButton nextElement = e.nextElement();
			if (nextElement.isSelected()) {
				break;
			}
		}
		if (count >= AreaType.values().size())
			return null;
		AreaType areaType = AreaType.values().get(count);
		System.err.println(areaType);
		return areaType;
	}

	public static Enum<?> getSelect(Enum<?>[] enums, ButtonGroup bg) {
		int count = 0;
		for (Enumeration<AbstractButton> e = bg.getElements(); e
				.hasMoreElements(); count++)
			if (e.nextElement().isSelected()) {
				break;
			}
		return enums[count];
	}

	public PlayType getPlayType() {
		return PlayType
				.newBuilder()
				.setBankerMode(this.getBankerMode())
				.setTimesLimit(this.getTimesLimit())
				.setYiTiaoLong(this.yiTiaoLongCheck.isSelected())
				.setMenQing(this.mengQingDaDaHuCheck.isSelected())
				.setJiangJiangHu(
						this.mengQingJiangJiangHuJiePaoCheck.isSelected())
				.setBaoTing(this.baoTingRadio.isSelected())
				.setDiHu(this.diHuRadio.isSelected())
				.setYiZiQiao(this.yiZiQiaoCheck.isSelected())
				.setZhaNiao(this.getZhaNiao())
				.setSeveralNiao(this.getNiaoCount())
				.setArea(this.getAreaType().getType()).build();
	}

}
