package test.client.util;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;

import test.client.ClientFrame;
import test.client.MessageImpl;

import com.wk.mj.Pai;
import com.wk.mj.enun.ChiType;

/** 吃，， **/
public class ChiOpera extends Opera implements ActionListener {
	private static final long serialVersionUID = 1L;
	protected final List<ChiCache> chiTypes = new ArrayList<>();
	public static final ChiCache empty = new ChiCache(null, new Pai[] {
			Pai.emptyMj, Pai.emptyMj, Pai.emptyMj });

	public ChiOpera(String arg0, MessageImpl type) {
		super(arg0, type);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (type != null) {
			if (!this.chiTypes.isEmpty()) {
				ChiCache cache = showDialog("选吃", this.chiTypes);
				if (cache != empty) {
					type.sendMessageWithContent(cache.type.getType() + "");
				}
			} else
				MessageImpl.Over.sendMessageWithContent(null);
		}
	}

	public static class ChiCache {
		private final ChiType type;
		private final Pai[] pais;

		public ChiCache(ChiType type, Pai[] pais) {
			super();
			this.type = type;
			this.pais = pais;
		}

		@Override
		public String toString() {
			return Arrays.toString(pais);
		}
	}

	public static ChiCache showDialog(String title, List<ChiCache> list) {
		if (!list.contains(empty))
			list.add(0, empty);
		final JDialog dialog = new JDialog(ClientFrame.clientFrame, title, true);// JOptionPane.getRootFrame()
		dialog.setLocationRelativeTo(ClientFrame.clientFrame);
		dialog.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		JLabel label = new JLabel(title);
		dialog.add(label);
		JComboBox<ChiCache> comboBox = new JComboBox<>(
				list.toArray(new ChiCache[list.size()]));
		comboBox.setSelectedIndex(0);
		dialog.add(comboBox);
		ItemListener aListener = new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					JComboBox<?> jc = ((JComboBox<?>) e.getSource());
					int index = jc.getSelectedIndex();
					if (index != 0) { // ==0表示选中的是第一个空项
						dialog.setVisible(false);
					}
				}
			}
		};
		comboBox.addItemListener(aListener);
		dialog.pack();
		dialog.setVisible(true);
		dialog.dispose();
		return (ChiCache) comboBox.getSelectedItem();
	}

	public void setMj(List<Integer> list, Pai pai) {
		this.chiTypes.clear();
		for (int t : list) {
			ChiType type = ChiType.getEnum(t);
			Pai[] pais = ChiType.getPais(type, pai);
			this.chiTypes.add(new ChiCache(type, new Pai[] { pai, pais[0],
					pais[1] }));
		}
	}
};