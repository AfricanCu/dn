package test.client;

public enum ChannelType {
	Normal, Game, ;
}
