package test.client.util;

import javax.swing.JComboBox;

import test.client.ChannelItem;

public class JComboBoxEx extends JComboBox<ChannelItem> {
	private static final long serialVersionUID = 1L;

	@Override
	public synchronized void addItem(ChannelItem item) {
		super.addItem(item);
	}

	@Override
	public synchronized void removeItem(Object anObject) {
		super.removeItem(anObject);
	}
};