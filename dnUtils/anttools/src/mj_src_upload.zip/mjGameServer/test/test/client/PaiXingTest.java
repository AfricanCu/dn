package test.client;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import test.client.util.PxChiOpera;
import test.client.util.PxMaJiang;
import test.client.util.PxOpera;
import test.client.util.RadioType;
import test.client.util.RefineryUtilities;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.SystemConstantsAbs;
import com.wk.engine.config.ServerConfig;
import com.wk.logic.area.AreaType;
import com.wk.logic.config.StaticDataManager;
import com.wk.mj.GpcCache;
import com.wk.mj.ListMjAbs;
import com.wk.mj.MjTools;
import com.wk.mj.MjUtils;
import com.wk.mj.Pai;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.MjType;
import com.wk.mj.lai.LaiTools;
import com.wk.server.logic.room.RoomRecord;
import com.wk.util.FileProcessor;
import com.wk.util.NRandom;

public class PaiXingTest extends PlayTypeFrame implements ItemListener,
		ActionListener, KeyListener {
	static {
		try {
			ServerConfig.init();
			int n = JOptionPane.showConfirmDialog(null, "初始癞子数据吗?", "标题",
					JOptionPane.YES_NO_OPTION);
			if (n == JOptionPane.YES_OPTION) {
				LaiTools.init(true);
			} else {
				LaiTools.init(false);
			}
			StaticDataManager.loadData();
		} catch (Exception e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
		}
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | IllegalAccessException
				| InstantiationException | UnsupportedLookAndFeelException e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
		}
	}

	public static void main(String[] args) {
		try {
			PaiXingTest.paiXingTest.pack();
			RefineryUtilities.centerFrameOnScreen(PaiXingTest.paiXingTest);
			PaiXingTest.paiXingTest.setVisible(true);
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public static final PaiXingTest paiXingTest = new PaiXingTest();
	private static final long serialVersionUID = 1L;
	private PxGameState stat = PxGameState.zhuaPai;

	private void turnOnOrOff(Pai pai, boolean xx, PxOpera btn) {
		turnOnOrOff(Arrays.asList(pai), xx, btn);
	}

	private void turnOnOrOff(List<Pai> pais, boolean xx, PxOpera btn) {
		if (xx) {
			enableBtns(btn);
			btn.setMj(pais);
		} else {
			disableBtns(btn);
		}
	}

	private void turnOnOrOffChi(Pai pai, boolean xx, List<ChiType> list) {
		if (xx) {
			enableBtns(this.chiIndex);
			PxChiOpera chi = (PxChiOpera) this.chiIndex;
			chi.setMj(list, pai);
		} else {
			disableBtns(this.chiIndex);
		}
	}

	private void enableBtns(PxOpera... btns) {
		for (PxOpera btn : btns) {
			btn.setEnabled(true);
		}
	}

	private void disableBtns(PxOpera... btns) {
		for (PxOpera btn : btns) {
			btn.setEnabled(false);
		}
	}

	private class ListMjAbsImpl extends ListMjAbs {
		public ListMjAbsImpl(int id) {
			super(id);
		}

		@Override
		public void nextRound() {
			super.nextRound();
			PaiXingTest.this.laiziLabel.setText("癞子数：" + this.getCountLai());
		}

		@Override
		public void faPai(List<Pai> list) {
			super.faPai(list);
			PaiXingTest.this.refreshPais();
		}

		@Override
		public void addCountLai() {
			super.addCountLai();
			PaiXingTest.this.laiziLabel.setText("癞子数：" + this.getCountLai());
		}

		public boolean zhuaPai(Pai pai, boolean isBu, boolean isHaiDi) {
			if (PaiXingTest.this.getSta() != PxGameState.zhuaPai
					&& PaiXingTest.this.getSta() != PxGameState.buPai) {
				return false;
			}
			boolean zhuaPai = super.zhuaPai(pai, isBu, isHaiDi);
			if (zhuaPai) {
				PaiXingTest.this.refreshPais();
				PaiXingTest.this.turnOnOrOff(pai, this.isCanZiMo(), ziMoIndex);
				PaiXingTest.this.turnOnOrOff(this.getAnGangCacheArr(), !this
						.getAnGangCacheArr().isEmpty(), anGangIndex);
				PaiXingTest.this.turnOnOrOff(this.getMingGangCacheArr(), !this
						.getMingGangCacheArr().isEmpty(), mingGangIndex);
				PaiXingTest.this.turnOnOrOff(Pai.emptyMj, this.isCanZiMo()
						|| !this.getAnGangCacheArr().isEmpty()
						|| !this.getMingGangCacheArr().isEmpty(), guoIndex);
				if (this.isCanZiMo() || !this.getAnGangCacheArr().isEmpty()
						|| !this.getMingGangCacheArr().isEmpty()) {
					PaiXingTest.this.setSta(PxGameState.ziMoAnGangMingGangGuo);
				} else {
					PaiXingTest.this.setSta(PxGameState.daPai);
				}
			}
			return zhuaPai;
		}

		public boolean daPai(Pai pai) {
			if (PaiXingTest.this.getSta() != PxGameState.daPai
					&& PaiXingTest.this.getSta() != PxGameState.ziMoAnGangMingGangGuo) {
				return false;
			}
			boolean daPai = super.daPai(pai);
			if (daPai) {
				PaiXingTest.this.refreshPais();
				PaiXingTest.this.refreshSta();
			}
			return daPai;
		};

		@Override
		public boolean anGang(Pai pai) {
			boolean anGang = super.anGang(pai);
			if (anGang) {
				PaiXingTest.this.refreshPais();
			}
			return anGang;
		}

		@Override
		public boolean mingGangPrev(Pai pai) {
			boolean mingGang = super.mingGangPrev(pai);
			if (mingGang) {
				PaiXingTest.this.refreshPais();
			}
			return mingGang;
		}

		@Override
		public void jiePao() {
			super.jiePao();
			PaiXingTest.this.reset();
		}

		@Override
		public boolean jieGang(Pai haveDaPai, int seetInex) {
			boolean jieGang = super.jieGang(haveDaPai, seetInex);
			if (jieGang) {
				PaiXingTest.this.refreshPais();
			}
			return jieGang;
		}

		@Override
		public boolean peng(Pai haveDaPai, int seetInex) {
			boolean peng = super.peng(haveDaPai, seetInex);
			if (peng) {
				PaiXingTest.this.refreshPais();
			}
			return peng;
		}

		@Override
		public boolean chi(ChiType chi, Pai haveDaPai, int seetIndex) {
			boolean xx = super.chi(chi, haveDaPai, seetIndex);
			if (xx) {
				PaiXingTest.this.refreshPais();
			}
			return xx;
		}

		@Override
		public boolean isLai(Pai pai) {
			return laiRadio.isSelected()
					&& pai == PaiXingTest.this.laiComboBox.getSelectedItem();
		}

		@Override
		public boolean isCanDiHu() {
			// TODO Auto-generated method stub
			return false;
		}

		@Override
		public boolean isBao(Pai pai) {
			return this.getPlayTypeSet().isFeiBao()
					&& pai == PaiXingTest.this.laiComboBox.getSelectedItem();
		}

		@Override
		public boolean isBanker() {
			// TODO Auto-generated method stub
			return false;
		}
	}

	private final ListMjAbsImpl listMjAbs = new ListMjAbsImpl(1);
	private final JCheckBox noFengRadio = new JCheckBox("无风子");
	private final JCheckBox laiRadio = new JCheckBox("打赖子");
	private final JComboBox<Pai> laiComboBox = new JComboBox<>(MjUtils
			.getSortHasFengPais().toArray(
					new Pai[MjUtils.getSortHasFengPais().size()]));
	private final JLabel laiziLabel = new JLabel("");
	private final JCheckBox mingGangRadio = new JCheckBox("明杠");
	private RadioType radioType;
	/** 手上的牌 */
	private final List<PxMaJiang> paiBtns = new ArrayList<>(
			MjTools.getNumbermax());
	/** 可选的牌 */
	private final HashMap<Integer, PxMaJiang> allPaiBtns = new HashMap<>();
	private final HashMap<Integer, Integer> allPaiNumCache = new HashMap<>();
	private final PxOpera ziMoIndex = new PxOpera("自摸") {
		private static final long serialVersionUID = 1L;

		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.ziMoAnGangMingGangGuo) {
				if (PaiXingTest.this.listMjAbs.isCanZiMo()) {
					PaiXingTest.this.listMjAbs.ziMo();
					PaiXingTest.this.reset();
				}
			}
		}
	};
	private final PxOpera anGangIndex = new PxOpera("暗杠") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.ziMoAnGangMingGangGuo) {
				if (!this.mjs.isEmpty()) {
					Pai pai = TestClient.showDialog("选牌", this.mjs);
					if (pai != Pai.emptyMj) {
						if (PaiXingTest.this.listMjAbs.anGang(pai)) {
							PaiXingTest.this.disableBtns(selectBtns
									.toArray(new PxOpera[selectBtns.size()]));
							PaiXingTest.this.setSta(PxGameState.buPai);
						}
					}
				}
			}
		};
	};
	private final PxOpera mingGangIndex = new PxOpera("明杠") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.ziMoAnGangMingGangGuo) {
				if (!this.mjs.isEmpty()) {
					Pai pai = TestClient.showDialog("选牌", this.mjs);
					if (pai != Pai.emptyMj) {
						if (PaiXingTest.this.listMjAbs.mingGangPrev(pai)) {
							PaiXingTest.this.listMjAbs.mingGangSuccess(pai,
									PaiXingTest.this.listMjAbs.getPlayTypeSet()
											.isMingGangSuanJieGang());
							PaiXingTest.this.disableBtns(selectBtns
									.toArray(new PxOpera[selectBtns.size()]));
							PaiXingTest.this.setSta(PxGameState.buPai);
						}
					}
				}
			}
		};
	};
	private final PxOpera jiePaoIndex = new PxOpera("接炮") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.jiePaoJieGangPengGuo) {
				if (PaiXingTest.this.listMjAbs.isCanJiePao()) {
					PaiXingTest.this.listMjAbs.jiePao();
					PaiXingTest.this.reset();
				}
			}
		}
	};
	private final PxOpera jieGangIndex = new PxOpera("接杠") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.jiePaoJieGangPengGuo) {
				if (!this.mjs.isEmpty()) {
					Pai pai = TestClient.showDialog("选牌", this.mjs);
					if (pai != Pai.emptyMj) {
						if (PaiXingTest.this.listMjAbs.jieGang(pai, 1)) {
							PaiXingTest.this.disableBtns(selectBtns
									.toArray(new PxOpera[selectBtns.size()]));
							PaiXingTest.this.setSta(PxGameState.buPai);
						}
					}
				}
			}
		};
	};
	private final PxOpera pengIndex = new PxOpera("碰") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.jiePaoJieGangPengGuo) {
				if (!this.mjs.isEmpty()) {
					Pai pai = TestClient.showDialog("选牌", this.mjs);
					if (pai != Pai.emptyMj) {
						if (PaiXingTest.this.listMjAbs.peng(pai, 1)) {
							PaiXingTest.this.disableBtns(selectBtns
									.toArray(new PxOpera[selectBtns.size()]));
							PaiXingTest.this.setSta(PxGameState.daPai);
						}
					}
				}
			}
		};
	};
	private final PxOpera chiIndex = new PxChiOpera("吃") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.jiePaoJieGangPengGuo) {
				if (!this.chiTypes.isEmpty()) {
					ChiCache chiCache = showDialog("选牌", this.chiTypes);
					if (chiCache != empty) {
						if (PaiXingTest.this.listMjAbs.chi(chiCache.getType(),
								haveDaPai, 1)) {
							PaiXingTest.this.disableBtns(selectBtns
									.toArray(new PxOpera[selectBtns.size()]));
							PaiXingTest.this.setSta(PxGameState.daPai);
						}
					}
				}
			}
		};
	};
	private final PxOpera qiangGangIndex = new PxOpera("抢杠") {
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.qiangGangGuo) {
				if (PaiXingTest.this.listMjAbs.isCanQiangGangHu()) {
					PaiXingTest.this.listMjAbs.qiangGang();
					PaiXingTest.this.reset();
				}
			}
		};
	};
	private final PxOpera tingPaiIndex = new PxOpera("听牌");
	private final PxOpera zhuaPaiIndex = new PxOpera("抓牌");
	private final PxOpera guoIndex = new PxOpera("过") {
		@Override
		public void actionPerformed(ActionEvent e) {
			if (PaiXingTest.this.getSta() == PxGameState.ziMoAnGangMingGangGuo) {
				PaiXingTest.this.setSta(PxGameState.daPai);
			} else if (PaiXingTest.this.getSta() == PxGameState.jiePaoJieGangPengGuo) {
				PaiXingTest.this.setSta(PxGameState.waitOther);
			}
			PaiXingTest.this.disableBtns(selectBtns
					.toArray(new PxOpera[selectBtns.size()]));
		}
	};
	private final PxOpera haiDiIndex = new PxOpera("海底");
	private final List<PxOpera> selectBtns = Arrays.asList(ziMoIndex,
			anGangIndex, mingGangIndex, jiePaoIndex, jieGangIndex, pengIndex,
			chiIndex, qiangGangIndex, guoIndex);

	private final JButton resetBtn = new JButton("重置");
	private final JCheckBox exportCheck = new JCheckBox("导出牌型");
	/** 已经摆好的牌队列 **/
	private final List<Pai> cacheList = new ArrayList<>();
	private final List<Integer> cacheNumList = new ArrayList<>();

	public void refreshPais() {
		for (PxMaJiang xx : this.allPaiBtns.values()) {
			if (this.exportCheck.isSelected()) {
				Integer integer = allPaiNumCache.get(xx.getMj().getId());
				if (integer != null)
					xx.setNum(integer);
				else
					xx.setNum(4);
			} else
				xx.setNum(4);
			if (xx.getMj().isFeng()) {
				if (!this.listMjAbs.getPlayTypeSet().isFeng()) {
					xx.setNum(0);
				} else {
					xx.setNum(4);
				}
			}
		}
		ArrayList<Pai> ziList = this.listMjAbs.getZiList();
		int count = 0;
		for (int index = 0; index < ziList.size(); index++) {
			Pai pai = ziList.get(index);
			if (pai == Pai.emptyMj) {
				continue;
			}
			Integer integer = this.listMjAbs.getArrayList().get(index);
			if (integer == 0) {
				LoggerService.getPlatformLog().error("严重错误，，没有移除干净！");
				continue;
			}
			this.allPaiBtns.get(pai.getId()).minusNum(integer);
			for (int cc = 0; cc < integer; cc++) {
				this.paiBtns.get(count++).setMj(pai);
			}
		}
		for (; count < this.paiBtns.size(); count++) {
			this.paiBtns.get(count).setMj(Pai.emptyMj);
		}
		for (GpcCache gpc : this.listMjAbs.getGpcList()) {
			switch (gpc.getType()) {
			case MingGang:
			case JieGang:
			case AnGang:
				this.allPaiBtns.get(gpc.getPai().getId()).minusNum(4);
				break;
			case Chi:
				Pai[] pais = ChiType.getPais(gpc.getChi(), gpc.getPai());
				for (Pai pai : pais)
					this.allPaiBtns.get(pai.getId()).minusNum(1);
				this.allPaiBtns.get(gpc.getPai().getId()).minusNum(1);
				break;
			case Peng:
				this.allPaiBtns.get(gpc.getPai().getId()).minusNum(3);
				break;
			default:
				break;
			}
		}
	}

	public void refreshSta() {
		this.setSta(PaiXingTest.this.radioType == RadioType.self ? PxGameState.zhuaPai
				: PxGameState.waitOther);
	}

	protected void setSta(PxGameState sta) {
		this.stat = sta;
	}

	public PxGameState getSta() {
		return stat;
	}

	public PaiXingTest() {
		super("牌型测试");
		initComponet();
		this.setListMjAbs(this.listMjAbs);
		reset();
	}

	private void reset() {
		List<Pai> genPais = genPais();
		this.listMjAbs.nextRound();
		this.listMjAbs.faPai(new ArrayList<>(genPais.subList(0,
				MjTools.getNumbermaxMinus())));
		this.disableBtns(this.selectBtns.toArray(new PxOpera[this.selectBtns
				.size()]));
		this.refreshSta();
	}

	private List<Pai> genPais() {
		if (this.exportCheck.isSelected()) {
			this.cacheList.addAll(this.listMjAbs.getZiList());
			this.cacheNumList.addAll(this.listMjAbs.getArrayList());
			this.allPaiNumCache.clear();
			int sumNum = 0;
			for (PxMaJiang xx : this.allPaiBtns.values()) {
				this.allPaiNumCache.put(xx.getMj().getId(), xx.getNum());
				sumNum += xx.getNum();
			}
			if (sumNum < MjTools.getNumbermaxMinus()) {
				ArrayList<Pai> pais = new ArrayList<>();
				for (int i = 0; i < this.cacheList.size(); i++) {
					if (this.cacheList.get(i) != Pai.emptyMj) {
						for (int j = 0; j < this.cacheNumList.get(i); j++)
							pais.add(this.cacheList.get(i));
					}
				}
				for (PxMaJiang xx : this.allPaiBtns.values()) {
					for (int i = 0; i < xx.getNum(); i++)
						pais.add(xx.getMj());
				}
				StringBuilder builder = new StringBuilder();
				for (int i = 0; i < pais.size(); i++) {
					Pai pai = pais.get(i);
					builder.append(pai.toString())
							.append(SystemConstantsAbs.dot_SEP).append(i + 1)
							.append(SystemConstantsAbs.Double_SHARP_SEP);
				}
				File file = new File(RoomRecord.paisPath);
				if (!file.exists())
					try {
						file.createNewFile();
					} catch (IOException e) {
						e.printStackTrace();
					}
				FileProcessor.rewriteString(
						FileSystems.getDefault().getPath(file.getPath()),
						builder.toString());
				System.err.println(pais.size());
				this.exportCheck.doClick();
			}
		} else {
			for (PxMaJiang xx : this.allPaiBtns.values()) {
				if (!this.listMjAbs.getPlayTypeSet().isFeng()
						&& xx.getMj().isFeng()) {
					xx.setNum(0);
				} else
					xx.setNum(4);
			}
		}
		ArrayList<Pai> paiList = new ArrayList<>();
		for (PxMaJiang xx : this.allPaiBtns.values()) {
			for (int i = 0; i < xx.getNum(); i++)
				paiList.add(xx.getMj());
		}
		return NRandom.genArrayListSequence(paiList);
	}

	private void initComponet() {
		Box box = new Box(BoxLayout.Y_AXIS);
		box.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
		Box selectBox = new Box(BoxLayout.X_AXIS);
		addJComponent(selectBox, laiRadio, 100, 96);
		addJComponent(selectBox, laiComboBox, 100, 40);
		addJComponent(selectBox, laiziLabel, 100, 96);
		addJComponent(selectBox, mingGangRadio, 100, 96);
		final JRadioButton selfRadio = new JRadioButton("自摸自打");
		final JRadioButton otherRadio = new JRadioButton("别人打牌");
		ButtonGroup bg = new ButtonGroup();
		bg.add(selfRadio);
		bg.add(otherRadio);
		selfRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (PaiXingTest.this.radioType == RadioType.self) {
					return;
				}
				if (PaiXingTest.this.getSta() == PxGameState.zhuaPai
						|| PaiXingTest.this.getSta() == PxGameState.buPai
						|| PaiXingTest.this.getSta() == PxGameState.waitOther) {
					PaiXingTest.this.radioType = RadioType.self;
					PaiXingTest.this.refreshSta();
				} else {
					otherRadio.setSelected(true);
				}
			}
		});
		otherRadio.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (PaiXingTest.this.radioType == RadioType.other) {
					return;
				}
				if (PaiXingTest.this.getSta() == PxGameState.zhuaPai
						|| PaiXingTest.this.getSta() == PxGameState.buPai
						|| PaiXingTest.this.getSta() == PxGameState.waitOther) {
					PaiXingTest.this.radioType = RadioType.other;
					PaiXingTest.this.refreshSta();
				} else {
					selfRadio.setSelected(true);
				}
			}
		});
		selfRadio.doClick();
		addJComponent(selectBox, selfRadio, 100, 96);
		addJComponent(selectBox, otherRadio, 100, 96);
		for (PxOpera op : selectBtns) {
			addJComponent(selectBox, op, 75, 40);
			op.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
				}
			});
		}
		addJComponent(selectBox, resetBtn, 75, 40);
		resetBtn.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PaiXingTest.paiXingTest.reset();
			}
		});
		addJComponent(selectBox, exportCheck, 100, 96);
		exportCheck.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				PaiXingTest.this.cacheList.clear();
				PaiXingTest.this.cacheNumList.clear();
				PaiXingTest.this.allPaiNumCache.clear();
				for (PxMaJiang xx : PaiXingTest.this.allPaiBtns.values()) {
					if (!PaiXingTest.this.listMjAbs.getPlayTypeSet().isFeng()
							&& xx.getMj().isFeng()) {
						xx.setNum(0);
					} else
						xx.setNum(4);
				}
				PaiXingTest.this.refreshPais();
			}
		});
		box.add(Box.createVerticalStrut(5));
		box.add(selectBox);
		box.add(Box.createVerticalStrut(5));
		getcreateRoomBox(box);
		Box paisBox = new Box(BoxLayout.X_AXIS);
		for (int i = 0; i < MjTools.getNumbermax(); i++) {
			final PxMaJiang createMaJiang = PxMaJiang.createMaJiang(false);
			createMaJiang.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					if (createMaJiang.getMj() == Pai.emptyMj) {
						return;
					}
					PaiXingTest.this.listMjAbs.daPai(createMaJiang.getMj());
				}
			});
			paiBtns.add(createMaJiang);
		}
		for (PxMaJiang paiBtn : this.paiBtns) {
			addJComponent(paisBox, paiBtn, 75, 96);
		}
		box.add(Box.createVerticalStrut(5));
		box.add(paisBox);
		for (MjType mjType : MjType.values()) {
			Box allPaisBox = new Box(BoxLayout.X_AXIS);
			for (int i = 0; i < mjType.getMjList().size(); i++) {
				final Pai pai = mjType.getMjList().get(i);
				final PxMaJiang createMaJiang = PxMaJiang.createMaJiang(true);
				createMaJiang.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						if (PaiXingTest.this.getSta() == PxGameState.waitOther) {
							if (PaiXingTest.this.mingGangRadio.isSelected()) {
								PaiXingTest.this.listMjAbs
										.cacheQiangGangHu(pai);
								boolean canQiangGangHu = PaiXingTest.this.listMjAbs
										.isCanQiangGangHu();
								PaiXingTest.this.turnOnOrOff(pai,
										canQiangGangHu, qiangGangIndex);
								if (canQiangGangHu) {
									PaiXingTest.this
											.setSta(PxGameState.qiangGangGuo);
								} else {
									PaiXingTest.this
											.setSta(PxGameState.waitOther);
								}
							} else {
								PaiXingTest.this.listMjAbs.cacheJiePao(pai);
								boolean isCanJiePao = PaiXingTest.this.listMjAbs
										.isCanJiePao();
								boolean isCanJieGang = PaiXingTest.this.listMjAbs
										.isCanJieGang(pai);
								boolean canPeng = PaiXingTest.this.listMjAbs
										.isCanPeng(pai);
								List<ChiType> list = new ArrayList<>();
								if (PaiXingTest.this.listMjAbs.getPlayTypeSet()
										.isChi()) {
									for (ChiType type : ChiType.values())
										if (PaiXingTest.this.listMjAbs
												.isCanChi(type, pai) != null)
											list.add(type);
								}
								boolean canChi = list.size() > 0;
								PaiXingTest.this.turnOnOrOff(pai, isCanJiePao,
										jiePaoIndex);
								PaiXingTest.this.turnOnOrOff(pai, isCanJieGang,
										jieGangIndex);
								PaiXingTest.this.turnOnOrOff(pai, canPeng,
										pengIndex);
								PaiXingTest.this.turnOnOrOffChi(pai, canChi,
										list);
								PaiXingTest.this.turnOnOrOff(Pai.emptyMj,
										isCanJiePao || isCanJieGang || canPeng
												|| canChi, guoIndex);
								if (isCanJiePao || isCanJieGang || canPeng
										|| canChi) {
									PaiXingTest.this
											.setSta(PxGameState.jiePaoJieGangPengGuo);
								} else {
									PaiXingTest.this
											.setSta(PxGameState.waitOther);
								}
							}
						} else {
							PaiXingTest.this.listMjAbs.zhuaPai(
									pai,
									PaiXingTest.this.getSta() == PxGameState.buPai,
									false);
						}
					}
				});
				createMaJiang.setMj(pai);
				this.allPaiBtns.put(createMaJiang.getMj().getId(),
						createMaJiang);
				addJComponent(allPaisBox, createMaJiang, 75, 96);
			}
			box.add(Box.createVerticalStrut(5));
			box.add(allPaisBox);
		}

		JPanel jPanel = new JPanel();
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

		jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));
		jPanel.add(box);
		setContentPane(jPanel);
	}

	public static void addJComponent(Container container, JComponent button,
			int width, int height) {
		button.setFont(new Font("宋体", Font.PLAIN, 15));
		Dimension dimension = new Dimension(width, height);
		button.setMinimumSize(dimension);
		button.setMaximumSize(dimension);
		button.setPreferredSize(dimension);
		button.setAlignmentX(CENTER_ALIGNMENT);
		container.add(button);
	}

	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyPressed(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		// TODO Auto-generated method stub
	}

}
