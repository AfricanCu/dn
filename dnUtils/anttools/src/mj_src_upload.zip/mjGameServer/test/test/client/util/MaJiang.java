package test.client.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import msg.MjMessage.Mj;
import test.client.ClientFrame;
import test.client.MessageImpl;

import com.wk.mj.Pai;

public class MaJiang extends JButton implements ActionListener {
	private static final long serialVersionUID = 1L;

	public static MaJiang createMaJiang() {
		return new MaJiang(new ImageIcon(Pai.emptyMj.getImages()));
	}

	private Mj mj;

	public MaJiang(String arg0) {
		super(arg0);
		this.addActionListener(this);
	}

	public MaJiang(Icon arg0) {
		super(arg0);
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (mj != null)
			MessageImpl.DaPai.sendMessageWithMj(mj);
	}

	public Mj getMj() {
		return mj;
	}

	public void setMj(Pai mj2) {
		if (mj2 != null)
			this.mj = mj2.getMj();
		else
			this.mj = null;
		if (this.mj != null) {
			this.setIcon(new ImageIcon(ClientFrame.class.getClassLoader()
					.getResource(Pai.getPai(mj).getImages())));
		} else {
			this.setIcon(new ImageIcon(ClientFrame.class.getClassLoader()
					.getResource(Pai.emptyMj.getImages())));
		}
	}

	public void displayMj() {

	}
};