package test.client.util;

public enum RadioType {
	/** 自摸自打 */
	self,
	/** 别人打 */
	other

}
