package test.client.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;

import com.wk.mj.Pai;

public class PxOpera extends JButton implements ActionListener {
	private static final long serialVersionUID = 1L;
	protected final List<Pai> mjs = new ArrayList<>();

	public PxOpera(String arg0) {
		super(arg0);
		this.addActionListener(this);
	}

	public void setMj(List<Pai> list) {
		this.mjs.clear();
		for (Pai mj : list) {
			this.mjs.add(mj);
		}
	}

	public void setMj(Pai mj) {
		this.mjs.clear();
		this.mjs.add(mj);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		// TODO Auto-generated method stub

	}
}
