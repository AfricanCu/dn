package test.client;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import msg.MjMessage.Mj;
import msg.MjMessage.Ting;
import msg.MjMessage.TingHuPai;
import test.client.util.ChiOpera;
import test.client.util.JComboBoxEx;
import test.client.util.MaJiang;
import test.client.util.Opera;
import test.client.util.RobotClient;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.logic.area.AreaType;
import com.wk.logic.enm.GameState;
import com.wk.mj.MjTools;
import com.wk.mj.Pai;
import com.wk.mj.enun.HuPaiType;
import com.wk.play.enun.BankerMode;
import com.wk.play.enun.SeveralNiaoType;
import com.wk.play.enun.TimesLimitType;
import com.wk.play.enun.ZhaNiaoType;

/**
 *
 * @author Administrator
 */
public class ClientFrame extends PlayTypeFrame implements ItemListener,
		ActionListener, KeyListener {
	private static final long serialVersionUID = 1L;
	private static final List<MessageImpl> list = Arrays.asList(MessageImpl
			.values());
	static {
		Collections.sort(list, new Comparator<MessageImpl>() {
			public int compare(MessageImpl o1, MessageImpl o2) {
				return o1.getMsgId().getType() > o2.getMsgId().getType() ? 1
						: -1;
			}
		});
	}
	public static final ClientFrame clientFrame = new ClientFrame("good");
	/** 登录服url **/
	private final JComboBox<Object> urlComboBox = new JComboBox<Object>(
			TestClient.getURLs().toArray());
	private final JCheckBox closeDisplayCheck = new JCheckBox("关闭显示");
	public final JCheckBox autoCheck = new JCheckBox("自动打牌");
	public final JComboBoxEx channelComboBox = new JComboBoxEx();
	public final JButton autoDaPaiRobotBtn = new JButton("自动打牌机器人");
	private final JTextField logincode = new JTextField("");
	private final Opera ziMoBtn = new Opera("自摸", MessageImpl.ZiMoPai);
	private final Opera anGangBtn = new Opera("暗杠", MessageImpl.AnGangPai);
	private final Opera mingGangBtn = new Opera("明杠", MessageImpl.MingGangPai);
	private final Opera jiePaoBtn = new Opera("接炮", MessageImpl.JiePao);
	private final Opera jieGangBtn = new Opera("接杠", MessageImpl.JieGang);
	private final Opera pengBtn = new Opera("碰", MessageImpl.Peng);
	private final Opera chiBtn = new ChiOpera("吃", MessageImpl.Chi);
	private final Opera baoTingBtn = new Opera("报听", MessageImpl.BaoTing) {
		private static final long serialVersionUID = 1L;

		public void actionPerformed(ActionEvent e) {
			int n = JOptionPane.showConfirmDialog(null, "你报听吗?", "标题",
					JOptionPane.YES_NO_OPTION);
			if (n == JOptionPane.YES_OPTION) {
				type.sendMessageWithContent("true");
			} else {
				type.sendMessageWithContent("false");
			}
		};
	};
	private final Opera tingBtn = new Opera("听牌", null);
	private final Opera zhuaBtn = new Opera("抓牌", null);
	private final Opera guoBtn = new Opera("过", MessageImpl.Over);
	private final Opera haiDiBtn = new Opera("海底", null);
	private final Opera qiangGangBtn = new Opera("抢杠胡", MessageImpl.QiangGang);
	private final List<Opera> selectBtns = Arrays.asList(ziMoBtn, anGangBtn,
			mingGangBtn, jiePaoBtn, jieGangBtn, pengBtn, chiBtn, baoTingBtn,
			tingBtn, zhuaBtn, guoBtn, haiDiBtn, qiangGangBtn);
	private final List<MaJiang> paiBtns = new ArrayList<>(14);
	private final MaJiang zhuaPai = MaJiang.createMaJiang();
	private final MaJiang haveDaPai = MaJiang.createMaJiang();

	private final ArrayList<MaJiang> anGangBtns = new ArrayList<>(4);
	private final ArrayList<MaJiang> mingGangBtns = new ArrayList<>(4);
	private final ArrayList<MaJiang> jieGangBtns = new ArrayList<>(4);
	private final ArrayList<MaJiang> pengBtns = new ArrayList<>(4);
	private final ArrayList<MaJiang> chiBtns = new ArrayList<>(12);

	private final JTextArea tings = new JTextArea("没听牌");
	private final JTextArea roundEnd = new JTextArea("局结算");
	/** 登陆code备份 */
	private String logincodeBak;
	private final JComboBox<MessageImpl> msgIdComboBox = new JComboBox<>(
			list.toArray(new MessageImpl[list.size()]));
	private final List<MessageImpl> moduleList = Arrays.asList(
			MessageImpl.CreateRoomBefore, MessageImpl.CreateJulebuBefore,
			MessageImpl.Login, MessageImpl.JoinRoomBefore);
	private final int moduleListIndex = 1;
	private final JComboBox<MessageImpl> msgIdMoudleComboBox = new JComboBox<>(
			moduleList.toArray(new MessageImpl[moduleList.size()]));

	/** 5 */
	private final JTextField content = new JTextField();
	public final JLabel tips = new JLabel("?");
	private final JFormattedTextField sameTimeSendNum = new JFormattedTextField(
			new java.text.DecimalFormat("#0"));
	private final JButton sendBtn = new JButton("发送");
	/** sessionCode登录 */
	public final JCheckBox sessionCodeCheck = new JCheckBox("会话登录");
	/** 每次关闭之前老客户端 */
	private final JCheckBox closeClientCheck = new JCheckBox("关闭客户端");
	public final JCheckBox ranAreaCheck = new JCheckBox("随机一个区");
	private final Integer[] areas = new Integer[] { 0, 1, 2, 3, 4, 5 };
	public final JComboBox<Integer> areaComboBox = new JComboBox<>(areas);
	/** 机器人计数 第几号 */
	public final JFormattedTextField count = new JFormattedTextField(
			new java.text.DecimalFormat("#0"));
	/** 机器人计数 第几号 */
	public final JFormattedTextField autoCount = new JFormattedTextField(
			new java.text.DecimalFormat("#0"));
	/** 一次初始多少机器人房间 */
	public final JFormattedTextField roomNumCount = new JFormattedTextField(
			new java.text.DecimalFormat("#0"));
	public final JLabel channelCount = new JLabel("连接数");
	public final JLabel roomIdLb = new JLabel("房间号");
	public final JLabel seatLb = new JLabel("座位号");
	public final JLabel gameStateLb = new JLabel("游戏状态");
	public final JLabel isBaoTingLb = new JLabel("是否报听");
	public final JLabel myjulebuLb = new JLabel("我的俱乐部");
	public final JLabel joinjulebuLb = new JLabel("加入俱乐部");
	private final JButton closeSelectBtn = new JButton("关闭选中");
	private final JButton allCloseBtn = new JButton("全部关闭");
	private final JButton randomBtn = new JButton("随机客户端");
	private String ran = null;

	private ClientFrame(String title) {
		super(title);
		initComponents();
		urlComboBox.addItemListener(this);
		channelComboBox.addItemListener(this);
		msgIdComboBox.addItemListener(this);
		msgIdMoudleComboBox.addItemListener(this);
		areaComboBox.addItemListener(this);

		sessionCodeCheck.addItemListener(this);
		closeClientCheck.addItemListener(this);
		ranAreaCheck.addItemListener(this);
		sessionCodeCheck.setSelected(false);
		closeClientCheck.setSelected(false);

		closeSelectBtn.addActionListener(this);
		sendBtn.addActionListener(this);
		randomBtn.addActionListener(this);
		allCloseBtn.addActionListener(this);
		autoDaPaiRobotBtn.addActionListener(this);

		sameTimeSendNum.addKeyListener(this);
		count.addKeyListener(this);
		autoCount.addKeyListener(this);
		roomNumCount.addKeyListener(this);
		areaComboBox.setSelectedIndex(1);
		sameTimeSendNum.setText("1");
		count.setText("1");
		autoCount.setText("0");
		roomNumCount.setText("1");
		msgIdMoudleComboBox.setSelectedIndex(moduleListIndex);
	}

	private void initComponents() {
		JPanel jPanel = new JPanel();
		setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
		Box urlComboBoxBox = new Box(BoxLayout.X_AXIS);
		urlComboBoxBox.add(urlComboBox);
		urlComboBoxBox.add(closeDisplayCheck);
		urlComboBoxBox.add(autoCheck);
		urlComboBoxBox.add(autoDaPaiRobotBtn);
		Box userNameBox = new Box(BoxLayout.X_AXIS);
		userNameBox.add(new JLabel("登陆code："));
		addJComponent(userNameBox, logincode, 100, 20);
		for (JButton paiBtn : this.selectBtns) {
			addJComponent(userNameBox, paiBtn, 80, 20);
			paiBtn.setEnabled(false);
		}
		addJComponent(userNameBox, zhuaPai, 75, 96);
		addJComponent(userNameBox, haveDaPai, 75, 96);
		Box paisBox = new Box(BoxLayout.X_AXIS);
		for (int i = 0; i < MjTools.getNumbermax(); i++) {
			paiBtns.add(MaJiang.createMaJiang());
		}
		for (MaJiang paiBtn : this.paiBtns) {
			addJComponent(paisBox, paiBtn, 75, 96);
		}
		Box tmpBox = new Box(BoxLayout.X_AXIS);
		List<ArrayList<MaJiang>> asList = Arrays.asList(this.anGangBtns,
				this.mingGangBtns, this.jieGangBtns, this.pengBtns);
		List<String> labels = Arrays.asList("暗", "明", "接", "碰");
		for (int index = 0; index < asList.size(); index++) {
			String label = labels.get(index);
			addJComponent(tmpBox, new JLabel(label), 24, 24);
			ArrayList<MaJiang> list = asList.get(index);
			for (int i = 0; i < 4; i++) {
				list.add(MaJiang.createMaJiang());
			}
			for (MaJiang paiBtn : list) {
				addJComponent(tmpBox, paiBtn, 75, 96);
			}
		}
		for (int i = 0; i < 12; i++) {
			chiBtns.add(MaJiang.createMaJiang());
		}
		Box chiBox = new Box(BoxLayout.X_AXIS);
		for (MaJiang paiBtn : chiBtns) {
			addJComponent(chiBox, paiBtn, 75, 96);
		}
		Box texBox = new Box(BoxLayout.X_AXIS);
		JScrollPane tingsScroll = new JScrollPane(tings);
		tingsScroll
				.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		tingsScroll
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		// tingsScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		// tingsScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		// tingsScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		// tingsScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
		addJComponent(texBox, tingsScroll, 600, 80);
		JScrollPane roundEndScroll = new JScrollPane(roundEnd);
		roundEndScroll
				.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		roundEndScroll
				.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		// tingsScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
		// tingsScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		// tingsScroll.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		// tingsScroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_NEVER);
		addJComponent(texBox, roundEndScroll, 600, 80);

		Box msgIdBox = new Box(BoxLayout.X_AXIS);
		msgIdBox.add(new JLabel("协议id："));
		msgIdBox.add(msgIdComboBox);
		msgIdBox.add(new JLabel("模块："));
		msgIdBox.add(msgIdMoudleComboBox);

		Box contentBox = new Box(BoxLayout.X_AXIS);
		contentBox.add(new JLabel("内容："));
		contentBox.add(content);
		contentBox.add(tips);
		contentBox.add(Box.createHorizontalStrut(10));
		contentBox.add(new JLabel("发送msg数："));
		contentBox.add(sameTimeSendNum);

		Box box_choose = new Box(BoxLayout.X_AXIS);
		addJComponent(box_choose, sendBtn);

		Box checkBox = new Box(BoxLayout.X_AXIS);
		checkBox.add(sessionCodeCheck);
		checkBox.add(closeClientCheck);
		checkBox.add(ranAreaCheck);
		checkBox.add(new JLabel("选区："));
		checkBox.add(areaComboBox);

		checkBox.add(new JLabel("robot："));
		checkBox.add(count);
		checkBox.add(autoCount);
		checkBox.add(roomNumCount);

		Box btnBoxs = new Box(BoxLayout.X_AXIS);
		addJComponent(btnBoxs, channelCount);
		addJComponent(btnBoxs, closeSelectBtn);
		addJComponent(btnBoxs, randomBtn);
		addJComponent(btnBoxs, allCloseBtn);

		Box displayBox = new Box(BoxLayout.X_AXIS);
		addJComponent(displayBox, roomIdLb, 80, 20);
		addJComponent(displayBox, seatLb, 50, 20);
		addJComponent(displayBox, gameStateLb, 150, 20);
		addJComponent(displayBox, isBaoTingLb, 100, 20);
		addJComponent(displayBox, myjulebuLb, 200, 20);
		addJComponent(displayBox, joinjulebuLb, 200, 20);

		Box box = new Box(BoxLayout.Y_AXIS);
		box.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
		box.add(Box.createVerticalStrut(5));
		box.add(urlComboBoxBox);
		box.add(Box.createVerticalStrut(5));
		box.add(channelComboBox);
		box.add(Box.createVerticalStrut(5));
		box.add(userNameBox);
		box.add(Box.createVerticalStrut(5));
		box.add(paisBox);
		box.add(Box.createVerticalStrut(5));
		box.add(tmpBox);
		box.add(Box.createVerticalStrut(5));
		box.add(chiBox);
		box.add(Box.createVerticalStrut(5));
		box.add(texBox);
		box.add(Box.createVerticalStrut(5));
		box.add(msgIdBox);
		box.add(Box.createVerticalStrut(5));
		getcreateRoomBox(box);
		box.add(Box.createVerticalStrut(5));
		box.add(contentBox);
		box.add(Box.createVerticalStrut(5));
		box.add(box_choose);
		box.add(Box.createVerticalStrut(5));
		box.add(checkBox);
		box.add(Box.createVerticalStrut(5));
		box.add(btnBoxs);
		box.add(Box.createVerticalStrut(5));
		box.add(displayBox);
		new RobotClient(box);
		jPanel.setLayout(new BoxLayout(jPanel, BoxLayout.Y_AXIS));
		jPanel.add(box);
		setContentPane(jPanel);
	}

	/**
	 * 是否不刷新显示
	 * 
	 * @return
	 */
	public boolean isHidden() {
		return this.closeDisplayCheck.isSelected();
	}

	public static void addJComponent(Container container, JComponent button) {
		addJComponent(container, button, 150, 20);
	}

	public static void addJComponent(Container container, JComponent button,
			int width, int height) {
		button.setFont(new Font("宋体", Font.PLAIN, 15));
		Dimension dimension = new Dimension(width, height);
		button.setMinimumSize(dimension);
		button.setMaximumSize(dimension);
		button.setPreferredSize(dimension);
		button.setAlignmentX(CENTER_ALIGNMENT);
		container.add(button);
	}

	public String getLogincode() {
		return logincode.getText().trim();
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		Object source = e.getItemSelectable();
		if (source == channelComboBox) {
			if (e.getStateChange() == ItemEvent.SELECTED) {
				ChannelItem item = ((ChannelItem) channelComboBox
						.getSelectedItem());
				if (item != null) {
					TestClient.setCurrentChannel(item.getChannel());
					refreshDisplay(item.getChannel());
				}
			} else {
				TestClient.setCurrentChannel(null);
			}
		} else if (source == areaComboBox) {
			if (e.getStateChange() == ItemEvent.SELECTED) {
				Integer item = (Integer) areaComboBox.getSelectedItem();
				LoggerService.getLogicLog().error("选择{}", item);
			}
		} else if (source == msgIdComboBox) {
			if (e.getStateChange() == ItemEvent.SELECTED) {
				MessageImpl item = (MessageImpl) msgIdComboBox
						.getSelectedItem();
				LoggerService.getLogicLog().error("选择{}", item);
				this.tips.setText("?" + item.getTips());
				this.content.setText(item.getDefaultContent().toString());
			}
		} else if (source == msgIdMoudleComboBox) {
			if (e.getStateChange() == ItemEvent.SELECTED) {
				MessageImpl item = (MessageImpl) msgIdMoudleComboBox
						.getSelectedItem();
				msgIdComboBox.setSelectedItem(item);
			}
		}
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		Object source = e.getSource();
		if (source == this.closeSelectBtn) {
			if (!TestClient.channelList.isEmpty()) {
				ChannelItem selectedItem = (ChannelItem) channelComboBox
						.getSelectedItem();
				selectedItem.getChannel().close();
			}
		} else if (source == this.allCloseBtn) {
			if (!TestClient.channelList.isEmpty()) {
				for (String key : new ArrayList<String>(
						TestClient.channelList.keySet())) {
					TestClient.channelList.remove(key);
				}
			}
		} else if (source == this.sendBtn) {
			send();
		} else if (source == this.randomBtn) {
			if (ran == null || !this.logincode.getText().contains("ranUser")) {
				ran = this.logincode.getText() + "ranUser";
			}
			int parseInt = Integer.parseInt(count.getText());
			this.logincode.setText(ran + parseInt);
			count.setText(Integer.toString(++parseInt));
			send();
		} else if (source == this.autoDaPaiRobotBtn) {
			int parseInt = Integer.parseInt(autoCount.getText());
			int roomNum = Integer.parseInt(roomNumCount.getText());
			for (int j = 0; j < roomNum; j++) {
				for (int i = 3; i >= 0; i--) {
					TestClient.connect(this.getSelectURL(),
							TestClient.robotName + (parseInt * 10 + i),
							ChannelType.Normal);
				}
				autoCount.setText(Integer.toString(++parseInt));
			}
		}
	}

	private void send() {
		synchronized (this) {
			MessageImpl msgId = (MessageImpl) this.msgIdComboBox
					.getSelectedItem();
			String content = this.content.getText().trim();
			if (msgId != null) {
				boolean isNewComer = TestClient.getCurrentChannel() == null
						|| logincodeBak == null
						|| !logincodeBak.equals(this.getLogincode());
				if (this.closeClientCheck.isSelected()
						&& TestClient.getCurrentChannel() != null) {
					TestClient.channelList.remove(MessageImpl.getChannel(
							TestClient.getCurrentChannel(),
							TestClient.puidIndex));
				}
				if (isNewComer) {
					TestClient.setCurrentChannel(TestClient.connect(
							this.getSelectURL(), this.getLogincode(),
							ChannelType.Normal));
				}
				msgId.sendMessage(
						Integer.parseInt(this.sameTimeSendNum.getText()),
						TestClient.getCurrentChannel(), content);
			}
		}
	}

	public String getSelectURL() {
		return (String) urlComboBox.getSelectedItem();
	}

	@Override
	public void keyTyped(KeyEvent e) {

	}

	@Override
	public void keyPressed(KeyEvent e) {
	}

	@Override
	public void keyReleased(KeyEvent e) {
		Object source = e.getSource();
		if (source == sameTimeSendNum || source == count || source == autoCount
				|| source == roomNumCount) {
			JFormattedTextField target = (JFormattedTextField) source;
			String old = target.getText();
			JFormattedTextField.AbstractFormatter formatter = target
					.getFormatter();
			if (!old.equals("")) {
				if (formatter != null) {
					String str = target.getText();
					try {
						long page = (Long) formatter.stringToValue(str);
						target.setText(page + "");
					} catch (ParseException pe) {
						target.setText("1");// 解析异常直接将文本框中值设置为1
					}
				}
			}
		}
	}

	private Opera ziMoBtn() {
		return ziMoBtn;
	}

	private Opera anGangBtn() {
		return anGangBtn;
	}

	private Opera mingGangBtn() {
		return mingGangBtn;
	}

	private Opera jiePaoBtn() {
		return jiePaoBtn;
	}

	private Opera jieGangBtn() {
		return jieGangBtn;
	}

	private Opera pengBtn() {
		return pengBtn;
	}

	private Opera chiBtn() {
		return chiBtn;
	}

	private Opera baoTingBtn() {
		return baoTingBtn;
	}

	private Opera tingBtn() {
		return tingBtn;
	}

	private Opera zhuaBtn() {
		return zhuaBtn;
	}

	private Opera guoBtn() {
		return guoBtn;
	}

	private Opera haiDiBtn() {
		return haiDiBtn;
	}

	private Opera qiangGangBtn() {
		return qiangGangBtn;
	}

	private void enableBtns(Opera... btns) {
		for (Opera btn : btns) {
			btn.setEnabled(true);
		}
	}

	private void disableBtns(Opera... btns) {
		for (Opera btn : btns) {
			btn.setEnabled(false);
		}
	}

	public boolean hiddenOrNotCurrentChannel(Channel channel) {
		return this.isHidden() || !TestClient.isCurrentChannel(channel);
	}

	public void disableBtns(ChannelHandlerContext ctx) {
		if (hiddenOrNotCurrentChannel(ctx.channel())) {
			return;
		}
		for (Opera btn : this.selectBtns) {
			btn.setEnabled(false);
		}
	}

	public void refreshDisplay(Channel channel) {
		if (hiddenOrNotCurrentChannel(channel)) {
			return;
		}
		HashMap<String, Object> hashMap = channel.attr(TestClient.MAP_Attr)
				.get();
		for (Entry<String, Object> entry : hashMap.entrySet()) {
			String key = entry.getKey();
			Object value = entry.getValue();
			refreshDisplay(channel, key, value);
		}
	}

	public void refreshDisplay(Channel channel, String key, Object value) {
		if (hiddenOrNotCurrentChannel(channel)) {
			return;
		}
		switch (key) {
		case TestClient.resultIndex:
			this.roundEnd.setText(value.toString());
			break;
		case TestClient.roomIdIndex:
			this.roomIdLb.setText(value == null ? "" : value.toString());
			break;
		case TestClient.seatIndex:
			this.seatLb.setText(value.toString());
			break;
		case TestClient.myjulebuIndex:
			this.myjulebuLb.setText(value.toString());
			break;
		case TestClient.joinjulebuIndex:
			this.joinjulebuLb.setText(value.toString());
			break;
		case TestClient.gameStateIndex:
			this.gameStateLb.setText(value.toString());
			GameState gameState = (GameState) value;
			switch (gameState) {
			case ziMoAnGangMingGangGuo:
			case daPai:
				this.msgIdComboBox.setSelectedItem(MessageImpl.DaPai);
				break;
			default:
				break;
			}
			break;
		case TestClient.puidIndex:
			logincode.setText(value.toString());
			logincodeBak = value.toString();
			break;
		case TestClient.isBaoTingIndex:
			this.isBaoTingLb.setText(value.toString());
			break;
		case TestClient.paisListIndex:
			ArrayList<Pai> paisList = (ArrayList<Pai>) value;
			for (int i = 0; i < paisList.size(); i++) {
				Pai mj = paisList.get(i);
				this.paiBtns.get(i).setMj(mj);
			}
			for (int i = paisList.size(); i < MjTools.getNumbermax(); i++) {
				this.paiBtns.get(i).setMj(null);
			}
			break;
		case TestClient.zhuaPaiIndex:
			Pai zhuaPai = (Pai) value;
			this.zhuaPai.setMj(zhuaPai);
			break;
		case TestClient.haveDaPaiIndex:
			Pai haveDaPai = (Pai) value;
			this.haveDaPai.setMj(haveDaPai);
			break;
		case TestClient.jiePaoIndex:
			Mj jiePao = (Mj) value;
			if (jiePao != null) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.JiePao);
				this.enableBtns(this.jiePaoBtn(), this.guoBtn());
			} else {
				this.disableBtns(this.jiePaoBtn());
			}
			break;
		case TestClient.jieGangIndex:
			Mj jieGang = (Mj) value;
			if (jieGang != null) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.JieGang);
				this.enableBtns(this.jieGangBtn(), this.guoBtn());
			} else {
				this.disableBtns(this.jieGangBtn());
			}
			break;
		case TestClient.pengIndex:
			Mj peng = (Mj) value;
			if (peng != null) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.Peng);
				this.enableBtns(this.pengBtn(), this.guoBtn());
			} else {
				this.disableBtns(this.pengBtn());
			}
			break;
		case TestClient.chiIndex:
			@SuppressWarnings("unchecked")
			List<Integer> chiList = (List<Integer>) value;
			if (chiList != null) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.Chi);
				this.chiBtn().setMj(
						chiList,
						(Pai) MessageImpl.getChannel(channel,
								TestClient.haveDaPaiIndex));
				this.enableBtns(this.chiBtn(), this.guoBtn());
			} else {
				this.disableBtns(this.chiBtn());
			}
			break;
		case TestClient.baoTingIndex:
			boolean baoTing = (boolean) value;
			if (baoTing) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.BaoTing);
				this.enableBtns(this.baoTingBtn());
			} else {
				this.disableBtns(this.baoTingBtn());
			}
			break;
		case TestClient.ziMoIndex:
			boolean ziMo = (boolean) value;
			if (ziMo) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.ZiMoPai);
				this.enableBtns(this.ziMoBtn());
			} else {
				this.disableBtns(this.ziMoBtn());
			}
			break;
		case TestClient.qiangGangIndex:
			boolean qiangGang = (boolean) value;
			if (qiangGang) {
				this.selectMe(channel);
				this.msgIdComboBox.setSelectedItem(MessageImpl.QiangGang);
				this.enableBtns(this.qiangGangBtn(), this.guoBtn());
			} else {
				this.disableBtns(this.qiangGangBtn());
			}
			break;
		case TestClient.anGangListIndex:
			ArrayList<Mj> anGangList = (ArrayList<Mj>) value;
			if (!anGangList.isEmpty()) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.AnGangPai);
				this.anGangBtn().setMj(anGangList);
				this.enableBtns(this.anGangBtn());
			} else {
				this.disableBtns(this.anGangBtn());
			}
			break;
		case TestClient.mingGangListIndex:
			ArrayList<Mj> mingGangList = (ArrayList<Mj>) value;
			if (!mingGangList.isEmpty()) {
				this.msgIdComboBox.setSelectedItem(MessageImpl.MingGangPai);
				this.mingGangBtn().setMj(mingGangList);
				this.enableBtns(this.mingGangBtn());
			} else {
				this.disableBtns(this.mingGangBtn());
			}
			break;
		case TestClient.tingListIndex:
			ArrayList<Ting> tingList = (ArrayList<Ting>) value;
			if (!tingList.isEmpty()) {
				this.enableBtns(this.tingBtn());
				StringBuilder builder = new StringBuilder();
				for (Ting ting : tingList) {
					builder.append("打").append(Pai.getPai(ting.getMj()))
							.append(",");
					for (TingHuPai tinghuPai : ting.getTingHuPaiList()) {
						builder.append("听")
								.append(Pai.getPai(tinghuPai.getTing()))
								.append("，胡");
						for (int type : tinghuPai.getHuPaiTypeList()) {
							builder.append(HuPaiType.getEnum(type)).append("、");
						}
						builder.append("，番：").append(tinghuPai.getFanShu());
						builder.append(" ");
					}
					builder.append("\n");
				}
				this.tings.setText(builder.toString());
			} else {
				this.tings.setText(tingList.toString());
				this.disableBtns(this.tingBtn());
			}
			break;
		case TestClient.haveAnGangIndex:
			this.cache(this.anGangBtns, value);
			break;
		case TestClient.haveMingGangIndex:
			this.cache(this.mingGangBtns, value);
			break;
		case TestClient.haveJieGangIndex:
			this.cache(this.jieGangBtns, value);
			break;
		case TestClient.havePengIndex:
			this.cache(this.pengBtns, value);
			break;
		case TestClient.haveChiIndex:
			this.cache(this.chiBtns, value);
			break;
		default:
			break;
		}
	}

	private void cache(List<MaJiang> btns, Object value) {
		ArrayList<Pai> tmpList = (ArrayList<Pai>) value;
		int index = 0;
		for (Pai mj2 : tmpList) {
			btns.get(index++).setMj(mj2);
		}
		for (; index < btns.size(); index++) {
			btns.get(index).setMj(null);
		}
	}

	public void refreshDisplay(ChannelHandlerContext ctx, String key,
			Object value) {
		refreshDisplay(ctx.channel(), key, value);
	}

	public void disableOverBtn(ChannelHandlerContext ctx) {
		if (hiddenOrNotCurrentChannel(ctx.channel())) {
			return;
		}
		this.disableBtns(this.guoBtn());
	}

	public void enableHaiDiBtn(ChannelHandlerContext ctx) {
		this.enableBtns(this.haiDiBtn());
	}

	public void selectMe(ChannelHandlerContext ctx) {
		selectMe(ctx.channel());
	}

	public void selectMe(Channel channel) {
		if (isHidden()) {
			return;
		}
		channelComboBox.setSelectedItem((ChannelItem) MessageImpl.getChannel(
				channel, TestClient.item_index));
	}
}
