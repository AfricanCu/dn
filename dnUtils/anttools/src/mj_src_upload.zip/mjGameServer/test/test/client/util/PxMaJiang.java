package test.client.util;

import java.awt.Graphics;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import test.client.ClientFrame;

import com.wk.mj.Pai;

public class PxMaJiang extends JButton {
	private static final long serialVersionUID = 1L;

	public static PxMaJiang createMaJiang(boolean draw) {
		return new PxMaJiang(new ImageIcon(Pai.emptyMj.getImages()), draw);
	}

	private Pai mj;
	private int num;
	private final boolean draw;

	private PxMaJiang(Icon arg0, boolean draw) {
		super(arg0);
		this.draw = draw;
		this.num = 1;
	}

	public Pai getMj() {
		return mj;
	}

	public void setMj(Pai mj) {
		this.mj = mj;
		this.setIcon(new ImageIcon(ClientFrame.class.getClassLoader()
				.getResource(mj.getImages())));
	}

	public int getNum() {
		return num;
	}

	public void setNum(int num) {
		this.num = num;
		this.repaint();
	}

	public void minusNum(int num) {
		this.num = this.num - num;
		this.num = this.num < 0 ? 0 : this.num;
		this.repaint();
	}

	@Override
	public void paint(Graphics g) {
		if (this.num <= 0) {
			this.setEnabled(false);
		} else if (!this.isEnabled()) {
			this.setEnabled(true);
		}
		super.paint(g);
		if (draw) {
			g.drawString(this.num + "", 10, 10);
		}
	}

};