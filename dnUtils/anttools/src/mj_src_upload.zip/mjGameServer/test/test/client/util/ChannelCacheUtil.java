package test.client.util;

import io.netty.channel.ChannelHandlerContext;
import io.netty.util.internal.ThreadLocalRandom;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import msg.MjMessage.Mj;
import test.client.ClientFrame;
import test.client.MessageImpl;
import test.client.TestClient;

import com.jery.ngsp.server.log.LoggerService;
import com.wk.engine.config.ServerConfig;
import com.wk.mj.Pai;

public class ChannelCacheUtil {

	// /////////////////////////////
	public static <T> void addList(ChannelHandlerContext ctx, String key,
			T... values) {
		addList(ctx, key, Arrays.asList(values));
	}

	public static <T> void addList(ChannelHandlerContext ctx, String key,
			List<T> valueList) {
		ArrayList<T> pais = (ArrayList<T>) MessageImpl.getChannel(ctx, key);
		pais.addAll(valueList);
		ClientFrame.clientFrame.refreshDisplay(ctx, key, pais);
	}

	// /////////重置/////////////
	public static <T> void resetList(ChannelHandlerContext ctx, String key,
			T... values) {
		resetList(ctx, key, Arrays.asList(values));
	}

	public static <T> void resetList(ChannelHandlerContext ctx, String key,
			List<T> valueList) {
		ArrayList<T> pais = (ArrayList<T>) MessageImpl.getChannel(ctx, key);
		pais.clear();
		if (valueList != null && !valueList.isEmpty())
			pais.addAll(valueList);
		ClientFrame.clientFrame.refreshDisplay(ctx, key, pais);
	}

	// /////////////移除手上的牌///////////////////
	public static void removeMjs(String desc, ChannelHandlerContext ctx,
			Mj... mjs) {
		ArrayList<Pai> pais = (ArrayList<Pai>) MessageImpl.getChannel(ctx,
				TestClient.paisListIndex);
		for (Mj mj : mjs) {
			if (!pais.remove(Pai.getPai(mj)))
				LoggerService.getLogicLog().error(
						"desc:{},找不到牌！:{},puid:{}",
						new Object[] {
								desc,
								Pai.getPai(mj),
								MessageImpl.getChannel(ctx,
										TestClient.puidIndex) });
		}
		ClientFrame.clientFrame.refreshDisplay(ctx, TestClient.paisListIndex,
				pais);
	}

	public static Pai ranGetMjs(ChannelHandlerContext ctx) {
		ArrayList<Pai> pais = (ArrayList<Pai>) MessageImpl.getChannel(ctx,
				TestClient.paisListIndex);
		Pai get = pais.get(ThreadLocalRandom.current().nextInt(pais.size()));
		if (ServerConfig.isMonitorMessage())
			LoggerService.getLogicLog().error("随机打牌！{}", get);
		ClientFrame.clientFrame.refreshDisplay(ctx, TestClient.paisListIndex,
				pais);
		return get;
	}

	public static void addMjs(ChannelHandlerContext ctx, Mj mj) {
		addMjs(ctx, TestClient.paisListIndex, mj);
	}

	public static void addMjs(ChannelHandlerContext ctx, List<Mj> mjList) {
		addMjs(ctx, TestClient.paisListIndex, mjList);
	}

	// ////////////////////////////

	public static void addMjs(ChannelHandlerContext ctx, String key,
			List<Mj> mjList) {
		Mj[] array = mjList.toArray(new Mj[mjList.size()]);
		addMjs(ctx, key, array);
	}

	public static void addMjs(ChannelHandlerContext ctx, String key, Mj... mjs) {
		ArrayList<Pai> pais = (ArrayList<Pai>) MessageImpl.getChannel(ctx, key);
		for (Mj mj : mjs) {
			TestClient.mjInsert.insert(pais, Pai.getPai(mj));
		}
		ClientFrame.clientFrame.refreshDisplay(ctx, key, pais);
	}

	public static void removeMjs(ChannelHandlerContext ctx, String key,
			Mj... mjs) {
		ArrayList<Pai> pais = (ArrayList<Pai>) MessageImpl.getChannel(ctx, key);
		for (Mj mj : mjs) {
			pais.remove(Pai.getPai(mj));
		}
		ClientFrame.clientFrame.refreshDisplay(ctx, key, pais);
	}

	// /////////////////////////////////////////
}
