package test.client;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.util.AttributeKey;

import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import msg.LoginMessage.LoginCm;
import msg.LoginMessage.SwLoginCm;
import msg.MjMessage.AnGangPaiCast;
import msg.MjMessage.AnGangPaiCm;
import msg.MjMessage.BaoTingCm;
import msg.MjMessage.BaoTingZhuaDaPaiCast;
import msg.MjMessage.ChiPaiCast;
import msg.MjMessage.ChiPaiCm;
import msg.MjMessage.DaPaiCast;
import msg.MjMessage.DaPaiCm;
import msg.MjMessage.FaPaiCast;
import msg.MjMessage.HaiDiZhuaPaiCast;
import msg.MjMessage.HuResult;
import msg.MjMessage.JieGangCast;
import msg.MjMessage.JieGangCm;
import msg.MjMessage.JiePaoCm;
import msg.MjMessage.MingGangPaiCast;
import msg.MjMessage.MingGangPaiCm;
import msg.MjMessage.Mj;
import msg.MjMessage.PengPaiCast;
import msg.MjMessage.PengPaiCm;
import msg.MjMessage.QiangGangCm;
import msg.MjMessage.RoundResult;
import msg.MjMessage.RoundResultCast;
import msg.MjMessage.Ting;
import msg.MjMessage.ZhuaPaiCast;
import msg.MjMessage.ZiMoPaiCm;
import msg.RoomMessage.PrepareRoomCm;
import msg.RoomMessage.SwServer;

import org.json.JSONObject;

import test.client.util.ChannelCacheUtil;
import test.client.util.NoticeTextTemplate;
import test.client.util.RefineryUtilities;

import com.google.protobuf.Message;
import com.google.protobuf.MessageLite;
import com.googlecode.protobuf.format.JsonFormat;
import com.jery.ngsp.server.log.LoggerService;
import com.wk.bean.NTxtAbs;
import com.wk.engine.config.ServerConfig;
import com.wk.engine.config.SystemConstants;
import com.wk.engine.net.InnerIoMessage;
import com.wk.engine.net.InnerMsgId;
import com.wk.engine.net.IoMessage;
import com.wk.engine.net.I.ChannelAttachmentAbs;
import com.wk.engine.net.util.ChannelAttachment;
import com.wk.enun.PlatformType;
import com.wk.logic.config.StaticDataManager;
import com.wk.logic.enm.GameState;
import com.wk.logic.enm.MsgId;
import com.wk.logic.enm.SwType;
import com.wk.mj.MjTools;
import com.wk.mj.Pai;
import com.wk.mj.enun.ChiType;
import com.wk.mj.enun.HuPaiType;
import com.wk.util.HttpCommonTools;
import com.wk.util.InsertSort;
import com.wk.util.NettyClient;
import com.wk.util.TimeTaskUtil;

/**
 *
 * @author Administrator
 */
public class TestClient {
	static {
		URL configURL = LoggerService.class.getClassLoader().getResource(
				"test/client/gameServerLog4j.properties");
		LoggerService.init(configURL);
		LoggerService.getLogicLog().error(ServerConfig.ADDR);
		TimeTaskUtil.getTaskmanager().start("robot", 25, true);
		try {
			StaticDataManager.loadData();
		} catch (Exception e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
		}
		try {
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (ClassNotFoundException | IllegalAccessException
				| InstantiationException | UnsupportedLookAndFeelException e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
		}
	}
	public static final InsertSort<Pai> mjInsert = new InsertSort<Pai>();
	public static final Properties properties = new Properties();
	public static final String robotName = "robot";
	/** nickname */
	public static final String nicknameIndex = "nicknameIndex";
	/** 座位号 */
	public static final String seatIndex = "seatIndex";
	/** 俱乐部 */
	public static final String myjulebuIndex = "myjulebuIndex";
	/** 俱乐部 */
	public static final String joinjulebuIndex = "joinjulebuIndex";
	/** 玩家名 **/
	public static final String uidIndex = "nameIndex";
	/** 这是第几个连接下标 */
	public static final String item_index = "itemIndex";
	/** 切服缓存 **/
	public static final String swRoomIdIndex = "swRoomIdIndex";
	/** 客户端类型 */
	public static final String channelType = "channelType";
	/** puid **/
	public static final String puidIndex = "puid";
	/** roomId **/
	public static final String roomIdIndex = "roomId";
	/****/
	public static final String gameStateIndex = "gameStateIndex";
	/** channel缓存 */
	public static final AttributeKey<HashMap<String, Object>> MAP_Attr = new AttributeKey<HashMap<String, Object>>(
			HashMap.class.getName());
	/** 连接队列 **/
	public static final Map<String, Channel> channelList = Collections
			.synchronizedMap(new ChannelHashSet());
	/** 手上的牌 */
	public static final String paisListIndex = "paisListIndex";
	/** 已经吃的牌 */
	protected static final String haveChiIndex = "haveChiIndex";
	/** 已经碰的牌 **/
	protected static final String havePengIndex = "havePengIndex";
	/** 已经明杠的牌 */
	public static final String haveMingGangIndex = "haveMingGangIndex";
	/** 已经暗杠的牌 */
	public static final String haveAnGangIndex = "haveAnGangIndex";
	/** 已经接杠的牌 */
	public static final String haveJieGangIndex = "haveJieGangIndex";
	/** 可以听杠的牌 **/
	public static final String tingListIndex = "tingListIndex";
	/** 可以暗杠的牌 **/
	public static final String anGangListIndex = "anGangListIndex";
	/** 可以明杠的牌 **/
	public static final String mingGangListIndex = "mingGangListIndex";
	/** 能否报听 */
	public static final String baoTingIndex = "baoTingIndex";
	/** 是否报听 */
	public static final String isBaoTingIndex = "isBaoTingIndex";
	public static final String ziMoIndex = "ziMoIndex";
	public static final String jiePaoIndex = "jiePaoIndex";
	public static final String jieGangIndex = "jieGangIndex";
	public static final String pengIndex = "pengIndex";
	public static final String chiIndex = "chiIndex";
	public static final String haveDaPaiIndex = "haveDaPaiIndex";
	public static final String qiangGangIndex = "qiangGangIndex";
	public static final String zhuaPaiIndex = "zhuaPaiIndex";

	public static final String resultIndex = "resultIndex";
	/** 当前选中的客户端 */
	private static Channel currentChannel;

	public static void clearMap(ChannelHandlerContext ctx) {
		HashMap<String, Object> hashMap2 = ctx.channel().attr(MAP_Attr).get();
		((ArrayList<Pai>) hashMap2.get(paisListIndex)).clear();
		((ArrayList<Pai>) hashMap2.get(haveChiIndex)).clear();
		((ArrayList<Pai>) hashMap2.get(havePengIndex)).clear();
		((ArrayList<Pai>) hashMap2.get(haveAnGangIndex)).clear();
		((ArrayList<Pai>) hashMap2.get(haveMingGangIndex)).clear();
		((ArrayList<Pai>) hashMap2.get(haveJieGangIndex)).clear();

		((ArrayList<Ting>) hashMap2.get(tingListIndex)).clear();

		((ArrayList<Mj>) hashMap2.get(anGangListIndex)).clear();
		((ArrayList<Mj>) hashMap2.get(mingGangListIndex)).clear();
		hashMap2.put(baoTingIndex, false);
		hashMap2.put(isBaoTingIndex, false);
		hashMap2.put(ziMoIndex, false);
		hashMap2.put(jiePaoIndex, null);
		hashMap2.put(jieGangIndex, null);
		hashMap2.put(pengIndex, null);
		hashMap2.put(chiIndex, null);
		hashMap2.put(haveDaPaiIndex, null);
		hashMap2.put(qiangGangIndex, false);
		hashMap2.put(zhuaPaiIndex, null);
	}

	public static void over(ChannelHandlerContext ctx) {
		HashMap<String, Object> hashMap2 = ctx.channel().attr(MAP_Attr).get();
		hashMap2.put(ziMoIndex, false);
		((ArrayList<Mj>) hashMap2.get(anGangListIndex)).clear();
		((ArrayList<Mj>) hashMap2.get(mingGangListIndex)).clear();
		hashMap2.put(jiePaoIndex, null);
		hashMap2.put(jieGangIndex, null);
		hashMap2.put(pengIndex, null);
		hashMap2.put(chiIndex, null);
		hashMap2.put(baoTingIndex, false);
		((ArrayList<Ting>) hashMap2.get(tingListIndex)).clear();
		hashMap2.put(zhuaPaiIndex, null);
		ClientFrame.clientFrame.disableOverBtn(ctx);
		hashMap2.put(qiangGangIndex, false);
		ClientFrame.clientFrame.refreshDisplay(ctx.channel());
	}

	public static void main(String[] args) {
		try {
			URL resource = TestClient.class.getClassLoader().getResource(
					"test.properties");
			properties.load(resource.openStream());
			ClientFrame.clientFrame.pack();
			RefineryUtilities.centerFrameOnScreen(ClientFrame.clientFrame);
			ClientFrame.clientFrame.setVisible(true);
		} catch (Throwable e) {
			e.printStackTrace();
			System.exit(1);
		}
	}

	public static Channel connect(String url, String puid, ChannelType chType) {
		try {
			JSONObject loginJson = TestClient.login(puid, url);
			if (loginJson != null) {
				int code = loginJson.optInt("code");
				if (code == NTxtAbs.SUCCESS) {
					long uid = loginJson.optLong("uid");
					JSONObject targetJSON = loginJson.optJSONObject("target");
					String host = targetJSON.optString("serverIp");
					int port = targetJSON.optInt("port");
					LoginCm.Builder loginCm = LoginCm.newBuilder();
					loginCm.setUid(uid);
					loginCm.setSessionCode(targetJSON.optString("sessionCode"));
					loginCm.setLoginTime(targetJSON.optString("loginTime"));
					Channel channel = NettyClient.createOuterSocketClientSync(
							host, port, new MessageInboundHandler(uid, puid,
									chType));
					MessageImpl.sendMessage(channel, MsgId.LoginCm, loginCm,
							500);
					return channel;
				} else {
					LoggerService.getLogicLog().error(
							NoticeTextTemplate.getNoticeText(code));
					return null;
				}
			} else {
				return null;
			}
		} catch (Exception e) {
			LoggerService.getLogicLog().error(e.getMessage(), e);
			return null;
		}
	}

	private static final String sessionloginParams = "type=%s&sessionCode=%s&platformId=%s&deviceId=%s";
	private static final String loginParams = "type=%s&code=%s&platformId=%s&deviceId=%s";

	public static JSONObject login(String puid, String url) {// {"s":2,"sLSC":"{\"uid\":1318,\"accessTime\":1496588995000,\"refreshTime\":1496588995000}"}
		try {
			String sendHttp = null;
			if (ClientFrame.clientFrame.sessionCodeCheck.isSelected()) {
				sendHttp = HttpCommonTools.sendHttp(url,
						String.format(sessionloginParams, "login", URLEncoder
								.encode(new JSONObject(puid).getString("sLSC"),
										"utf-8"), PlatformType.pc.getType(),
								"xx"));
			} else {
				sendHttp = HttpCommonTools.sendHttp(url, String.format(
						loginParams, "login", URLEncoder.encode(puid, "utf-8"),
						PlatformType.pc.getType(), "xx"));
			}
			JSONObject jsonObject = null;
			try {
				jsonObject = new JSONObject(sendHttp);
			} catch (Exception e) {
				e.printStackTrace();
			}
			LoggerService.getLogicLog().error(jsonObject.toString());
			int code = jsonObject.optInt("code");
			if (code != NTxtAbs.SUCCESS) {
				LoggerService.getLogicLog().error("登录失败！！！{}", code);
			}
			return jsonObject;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public static Pai showDialog(String title, List<Pai> list) {
		if (!list.contains(Pai.emptyMj))
			list.add(0, Pai.emptyMj);
		final JDialog dialog = new JDialog(ClientFrame.clientFrame, title, true);// JOptionPane.getRootFrame()
		dialog.setLocationRelativeTo(ClientFrame.clientFrame);
		dialog.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
		JLabel label = new JLabel(title);
		dialog.add(label);
		JComboBox<Pai> comboBox = new JComboBox<>(list.toArray(new Pai[list
				.size()]));
		comboBox.setSelectedIndex(0);
		dialog.add(comboBox);
		ItemListener aListener = new ItemListener() {
			@Override
			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					JComboBox<?> jc = ((JComboBox<?>) e.getSource());
					int index = jc.getSelectedIndex();
					if (index != 0) { // ==0表示选中的是第一个空项
						dialog.setVisible(false);
					}
				}
			}
		};
		comboBox.addItemListener(aListener);
		dialog.pack();
		dialog.setVisible(true);
		dialog.dispose();
		return (Pai) comboBox.getSelectedItem();
	}

	public static class MessageInboundHandler extends
			SimpleChannelInboundHandler<IoMessage> {
		private boolean threadBreak = false;
		private long uName;
		private final ChannelType chType;
		private final String puid;

		public MessageInboundHandler(long uName, String puid, ChannelType chType) {
			this.uName = uName;
			this.chType = chType;
			this.puid = puid;
		}

		@Override
		public void channelInactive(ChannelHandlerContext ctx) throws Exception {
			channelList.remove(puid);
			this.threadBreak = true;
			HashMap<String, Object> map = ctx.channel().attr(MAP_Attr).get();
			LoggerService.getLogicLog().error("断线!uid:{},nickname:{}",
					map.get(uidIndex), map.get(nicknameIndex));
			SwServer sw = (SwServer) map.get(swRoomIdIndex);
			if (sw != null) {
				long userName = (long) map.get(uidIndex);
				SwLoginCm.Builder swLoginCm = SwLoginCm.newBuilder();
				swLoginCm.setUid(userName);
				swLoginCm.setSwCode(sw.getMyCode());
				swLoginCm.setSId(sw.getSId());
				swLoginCm.setType(SwType.joinRoom.getType());
				try {
					Channel channel = NettyClient.createOuterSocketClientSync(
							sw.getHost(), sw.getPort(),
							new MessageInboundHandler(userName, puid, chType));
					MessageImpl.sendMessage(channel, MsgId.SwLoginCm,
							swLoginCm, 500);
				} catch (Exception e) {
					LoggerService.getLogicLog().error(e.getMessage(), e);
				}
			}
			super.channelInactive(ctx);
		}

		@Override
		public void channelActive(final ChannelHandlerContext ctx)
				throws Exception {
			HashMap<String, Object> hashMap = ctx.channel().attr(MAP_Attr)
					.get();
			if (hashMap == null) {
				HashMap<String, Object> hashMap2 = new HashMap<String, Object>();
				hashMap2.put(item_index, new ChannelItem(ctx.channel()));
				hashMap2.put(uidIndex, uName);
				hashMap2.put(puidIndex, puid);
				hashMap2.put(channelType, chType);
				hashMap2.put(resultIndex, new ArrayList<String>());

				hashMap2.put(paisListIndex, new ArrayList<Pai>());
				hashMap2.put(haveAnGangIndex, new ArrayList<Pai>());
				hashMap2.put(haveMingGangIndex, new ArrayList<Pai>());
				hashMap2.put(haveJieGangIndex, new ArrayList<Pai>());
				hashMap2.put(havePengIndex, new ArrayList<Pai>());
				hashMap2.put(haveChiIndex, new ArrayList<Pai>());

				hashMap2.put(tingListIndex, new ArrayList<Ting>());

				hashMap2.put(anGangListIndex, new ArrayList<Mj>());
				hashMap2.put(mingGangListIndex, new ArrayList<Mj>());

				ctx.channel().attr(MAP_Attr).set(hashMap2);
				clearMap(ctx);
			}
			ChannelAttachmentAbs channelAttachment = ctx.channel()
					.attr(SystemConstants.CHANNEL_ATTR_KEY).get();
			if (channelAttachment == null) {
				channelAttachment = new ChannelAttachment(ctx.channel());
				ctx.channel().attr(SystemConstants.CHANNEL_ATTR_KEY)
						.set(channelAttachment);
				if (ServerConfig.isHeartBeat())
					new Thread(new Runnable() {
						@Override
						public void run() {
							while (true) {
								if (threadBreak) {
									break;
								}
								try {
									Thread.sleep(5000);
								} catch (InterruptedException e) {
									e.printStackTrace();
								}
								try {
									ctx.channel().writeAndFlush(
											new InnerIoMessage(
													InnerMsgId.HeartBeat,
													new byte[] {}));
								} catch (Exception e) {
									e.printStackTrace();
								}
							}

						}
					}).start();
			}
			channelList.put(puid, ctx.channel());
			super.channelActive(ctx);
		}

		private void setState(ChannelHandlerContext ctx, boolean isCanDaPai) {
			if (isCanDaPai)
				MessageImpl.putChannel(ctx, gameStateIndex, GameState.daPai);
			else
				MessageImpl.putChannel(ctx, gameStateIndex,
						GameState.ziMoAnGangMingGangGuo);
		}

		@Override
		public void channelRead0(final ChannelHandlerContext ctx, IoMessage msg)
				throws Exception {
			MessageLite genMessageLite = msg.genMessageLite();
			MessageImpl getEnum;
			boolean cc = false;
			if (msg.getMsgId().name().endsWith("Cast")) {
				switch (msg.getMsgId()) {
				case FaPaiCast:
					TestClient.clearMap(ctx);
					ClientFrame.clientFrame.refreshDisplay(ctx.channel());
					FaPaiCast faPaiCast = (FaPaiCast) genMessageLite;
					ClientFrame.clientFrame.disableBtns(ctx);
					ChannelCacheUtil.addMjs(ctx, faPaiCast.getPaisList());
					MessageImpl.putChannel(ctx, baoTingIndex,
							faPaiCast.getBaoTing());
					if (faPaiCast.getBaoTing()) {
						MessageImpl.putChannel(ctx, gameStateIndex,
								GameState.baoTing);
					} else {
						MessageImpl.putChannel(ctx, gameStateIndex,
								GameState.waitOtherOperation);
					}
					if (!isAuto())
						break;
					cc = baoTing(ctx, faPaiCast.getBaoTing());
					break;
				case ZhuaPaiCast:
					ClientFrame.clientFrame.disableBtns(ctx);
					ClientFrame.clientFrame.selectMe(ctx);
					ZhuaPaiCast zhuaPaiCast = (ZhuaPaiCast) genMessageLite;
					ChannelCacheUtil.addMjs(ctx, zhuaPaiCast.getMj());
					MessageImpl.putChannel(ctx, zhuaPaiIndex,
							Pai.getPai(zhuaPaiCast.getMj()));
					MessageImpl.putChannel(ctx, ziMoIndex,
							zhuaPaiCast.getZiMo());
					ChannelCacheUtil.resetList(ctx, anGangListIndex,
							zhuaPaiCast.getAnGangList());
					ChannelCacheUtil.resetList(ctx, mingGangListIndex,
							zhuaPaiCast.getMingGangList());
					ChannelCacheUtil.resetList(ctx, tingListIndex,
							zhuaPaiCast.getTingList());
					setState(ctx, !zhuaPaiCast.getZiMo()
							&& zhuaPaiCast.getAnGangList().isEmpty()
							&& zhuaPaiCast.getMingGangList().isEmpty());
					if (!isAuto())
						break;
					cc = ziMo(ctx, zhuaPaiCast.getZiMo())
							|| anGang(ctx, zhuaPaiCast.getAnGangList())
							|| mingGang(ctx, zhuaPaiCast.getMingGangList())
							|| daPai(ctx, zhuaPaiCast.getMj());

					break;
				case HaiDiZhuaPaiCast:
					ClientFrame.clientFrame.disableBtns(ctx);
					ClientFrame.clientFrame.enableHaiDiBtn(ctx);
					ClientFrame.clientFrame.selectMe(ctx);
					HaiDiZhuaPaiCast haiDiZhuaPaiCast = (HaiDiZhuaPaiCast) genMessageLite;
					ChannelCacheUtil.addMjs(ctx, haiDiZhuaPaiCast.getMj());
					MessageImpl.putChannel(ctx, zhuaPaiIndex,
							Pai.getPai(haiDiZhuaPaiCast.getMj()));
					MessageImpl.putChannel(ctx, gameStateIndex,
							GameState.ziMoAnGangMingGangGuo);
					MessageImpl.putChannel(ctx, ziMoIndex,
							haiDiZhuaPaiCast.getZiMo());
					ChannelCacheUtil.resetList(ctx, anGangListIndex,
							haiDiZhuaPaiCast.getAnGangList());
					ChannelCacheUtil.resetList(ctx, mingGangListIndex,
							haiDiZhuaPaiCast.getMingGangList());
					if (!isAuto())
						return;
					cc = ziMo(ctx, haiDiZhuaPaiCast.getZiMo())
							|| anGang(ctx, haiDiZhuaPaiCast.getAnGangList())
							|| mingGang(ctx, haiDiZhuaPaiCast.getMingGangList());
					break;
				case SeetZhuaPaiCast:
					MessageImpl.putChannel(ctx, gameStateIndex,
							GameState.waitOtherOperation);
					break;
				case AnGangPaiCast:
					break;
				case DaPaiCast:
					ClientFrame.clientFrame.disableBtns(ctx);
					DaPaiCast daPaiCast = (DaPaiCast) genMessageLite;
					MessageImpl.putChannel(ctx, haveDaPaiIndex,
							Pai.getPai(daPaiCast.getMj()));
					MessageImpl.putChannel(ctx, jiePaoIndex,
							daPaiCast.getJiePao() ? daPaiCast.getMj() : null);
					MessageImpl.putChannel(ctx, jieGangIndex,
							daPaiCast.getJieGang() ? daPaiCast.getMj() : null);
					MessageImpl.putChannel(ctx, pengIndex,
							daPaiCast.getPeng() ? daPaiCast.getMj() : null);
					MessageImpl.putChannel(ctx, chiIndex, daPaiCast
							.getChiCount() > 0 ? daPaiCast.getChiList() : null);
					if (daPaiCast.getJiePao() || daPaiCast.getJieGang()
							|| daPaiCast.getPeng()
							|| daPaiCast.getChiCount() > 0)
						ClientFrame.clientFrame.selectMe(ctx);
					if (!isAuto())
						break;
					cc = jiePao(ctx, daPaiCast.getJiePao())
							|| jieGang(ctx, daPaiCast.getJieGang())
							|| peng(ctx, daPaiCast.getPeng())
							|| chi(ctx, daPaiCast.getChiList());
					break;
				case BaoTingZhuaDaPaiCast:
					ClientFrame.clientFrame.disableBtns(ctx);
					BaoTingZhuaDaPaiCast bTzpCast = (BaoTingZhuaDaPaiCast) genMessageLite;
					MessageImpl.putChannel(ctx, haveDaPaiIndex,
							Pai.getPai(bTzpCast.getMj()));
					MessageImpl.putChannel(ctx, jiePaoIndex,
							bTzpCast.getJiePao() ? bTzpCast.getMj() : null);
					MessageImpl.putChannel(ctx, jieGangIndex,
							bTzpCast.getJieGang() ? bTzpCast.getMj() : null);
					MessageImpl.putChannel(ctx, pengIndex,
							bTzpCast.getPeng() ? bTzpCast.getMj() : null);
					MessageImpl.putChannel(ctx, chiIndex, bTzpCast
							.getChiCount() > 0 ? bTzpCast.getChiList() : null);
					if (bTzpCast.getJiePao() || bTzpCast.getJieGang()
							|| bTzpCast.getPeng() || bTzpCast.getChiCount() > 0)
						ClientFrame.clientFrame.selectMe(ctx);
					if (!isAuto())
						break;
					cc = jiePao(ctx, bTzpCast.getJiePao())
							|| jieGang(ctx, bTzpCast.getJieGang())
							|| peng(ctx, bTzpCast.getPeng())
							|| chi(ctx, bTzpCast.getChiList());
					break;
				case JieGangCast:
					JieGangCast jieGangCast = (JieGangCast) genMessageLite;
					if (jieGangCast.getSeetIndex() != (int) MessageImpl
							.getChannel(ctx, seatIndex))
						break;
					ChannelCacheUtil.addMjs(ctx, TestClient.haveJieGangIndex,
							jieGangCast.getMj());
					Mj[] jieGangMjs = new Mj[3];
					Arrays.fill(jieGangMjs, jieGangCast.getMj());
					ChannelCacheUtil.removeMjs("接杠", ctx, jieGangMjs);
					break;
				case MingGangPaiCast:
					MingGangPaiCast mingGangPaiCast = (MingGangPaiCast) genMessageLite;
					MessageImpl.putChannel(ctx, qiangGangIndex,
							mingGangPaiCast.getQiangGang());
					if (mingGangPaiCast.getSeetIndex() == (int) MessageImpl
							.getChannel(ctx, seatIndex)) {
					} else {
						if (!isAuto() || !mingGangPaiCast.getQiangGang())
							break;
						qiangGang(ctx);
					}
					break;
				case PengPaiCast:
					ClientFrame.clientFrame.disableBtns(ctx);
					PengPaiCast pengPaiCast = (PengPaiCast) genMessageLite;
					if (pengPaiCast.getSeetIndex() != (int) MessageImpl
							.getChannel(ctx, seatIndex))
						break;
					ChannelCacheUtil.addMjs(ctx, TestClient.havePengIndex,
							pengPaiCast.getMj());
					Mj[] pengMjs = new Mj[2];
					Arrays.fill(pengMjs, pengPaiCast.getMj());
					ChannelCacheUtil.removeMjs("碰", ctx, pengMjs);
					ChannelCacheUtil.resetList(ctx, anGangListIndex,
							pengPaiCast.getAnGangList());
					ChannelCacheUtil.resetList(ctx, mingGangListIndex,
							pengPaiCast.getMingGangList());
					ChannelCacheUtil.resetList(ctx, tingListIndex,
							pengPaiCast.getTingList());
					if (!isAuto())
						break;
					cc = anGang(ctx, pengPaiCast.getAnGangList())
							|| mingGang(ctx, pengPaiCast.getMingGangList())
							|| daPai(ctx, ChannelCacheUtil.ranGetMjs(ctx)
									.getMj());
					break;
				case ChiPaiCast:
					ClientFrame.clientFrame.disableBtns(ctx);
					ChiPaiCast chiPaiCast = (ChiPaiCast) genMessageLite;
					if (chiPaiCast.getSeetIndex() != (int) MessageImpl
							.getChannel(ctx, seatIndex))
						break;
					ChiType chiType = ChiType.getEnum(chiPaiCast.getChi());
					Pai[] pais = ChiType.getPais(chiType,
							Pai.getPai(chiPaiCast.getMj()));
					ChannelCacheUtil.addMjs(ctx, TestClient.haveChiIndex,
							chiPaiCast.getMj(), pais[0].getMj(),
							pais[1].getMj());
					ChannelCacheUtil.removeMjs("吃", ctx, pais[0].getMj(),
							pais[1].getMj());
					ChannelCacheUtil.resetList(ctx, anGangListIndex,
							chiPaiCast.getAnGangList());
					ChannelCacheUtil.resetList(ctx, mingGangListIndex,
							chiPaiCast.getMingGangList());
					ChannelCacheUtil.resetList(ctx, tingListIndex,
							chiPaiCast.getTingList());
					if (!isAuto())
						break;
					cc = anGang(ctx, chiPaiCast.getAnGangList())
							|| mingGang(ctx, chiPaiCast.getMingGangList())
							|| daPai(ctx, ChannelCacheUtil.ranGetMjs(ctx)
									.getMj());
					break;
				case RoundResultCast:
					RoundResultCast roundResultCast = (RoundResultCast) genMessageLite;
					int seetId = (int) MessageImpl.getChannel(ctx, seatIndex);
					for (HuResult huResult : roundResultCast.getHuList()) {
						if (huResult.getSeetIndex() == seetId) {
							ArrayList<HuPaiType> hupaiList = new ArrayList<>();
							for (int type : huResult.getHuPaiTypeList())
								hupaiList.add(HuPaiType.getEnum(type));
							String format = String.format("%s", hupaiList);
							ChannelCacheUtil.addList(ctx, resultIndex, format);
						}
					}
					for (RoundResult roundResult : roundResultCast.getRsList()) {
						if (roundResult.getSeetIndex() != seetId)
							continue;
						String format = String
								.format("积分:%s,中鸟:%s,暗杠:%s,明杠:%s,接杠:%s,放炮:%s,放杠:%s,放抢杠:%s,一字撬:%s\n",
										roundResult.getRs(),
										roundResult.getNiaoNumber(),
										roundResult.getAnGang(),
										roundResult.getMingGang(),
										roundResult.getJieGang(),
										roundResult.getFangPao(),
										roundResult.getFangGang(),
										roundResult.getFangQiangGang(),
										roundResult.getYiZiQiaoYouXi());
						ChannelCacheUtil.addList(ctx, resultIndex, format);
					}
					MessageImpl.putChannel(ctx, gameStateIndex,
							GameState.noStart);
					if (!isAuto())
						break;
					prepareRoom(ctx);
					// LoggerService.getLogicLog().warn("局结算！puidIndex:{}",
					// MessageImpl.getChannel(ctx, puidIndex));
					break;
				case GameOverCast:
					LoggerService.getLogicLog().warn("游戏结算！puidIndex:{},{}",
							MessageImpl.getChannel(ctx, puidIndex),
							JsonFormat.printToString((Message) genMessageLite));
					if (!isAuto())
						break;
					if (isRobotMaster(ctx)) {
						TimeTaskUtil.getTaskmanager().submitOneTimeTask(
								new Runnable() {
									@Override
									public void run() {
										MessageImpl.CreateRoomBefore.sendMessage(
												ctx,
												MessageImpl.create_Room_params);
									}
								}, 3000, TimeUnit.MILLISECONDS);
					}
					break;
				default:
					break;
				}
			} else {
				getEnum = MessageImpl.getEnum(msg.getMsgId());
				if (getEnum != null)
					getEnum.resp(ctx, msg);
				int code = (int) genMessageLite.getClass()
						.getMethod("getCode", null)
						.invoke(genMessageLite, null);
				if (code != NTxtAbs.SUCCESS) {
					System.err.println(String.format("%s - %s,%s,%s",
							new Exception().getStackTrace()[0],
							MessageImpl.getChannel(ctx, puidIndex), code,
							NoticeTextTemplate.getNoticeText(code)));
				}
			}
			if (ServerConfig.isMonitorMessage())
				LoggerService
						.getLogicLog()
						.warn("{}：{}",
								new Object[] {
										msg.getMsgId().name(),
										new JSONObject(
												JsonFormat
														.printToString((Message) genMessageLite))
												.toString(1) });
		}

		private void qiangGang(ChannelHandlerContext ctx) {
			MessageImpl.sendMessage(ctx, MsgId.QiangGangCm,
					QiangGangCm.newBuilder());
		}

		private void prepareRoom(ChannelHandlerContext ctx) {
			MessageImpl.sendMessage(ctx, MsgId.PrepareRoomCm,
					PrepareRoomCm.newBuilder());
		}

		private boolean baoTing(ChannelHandlerContext ctx, boolean baoTing) {
			if (!baoTing)
				return false;
			MessageImpl.sendMessage(ctx, MsgId.BaoTingCm, BaoTingCm
					.newBuilder().setBaoTing(true));
			return true;
		}

		private boolean daPai(ChannelHandlerContext ctx, Mj mj) {
			MessageImpl.sendMessage(ctx, MsgId.DaPaiCm, DaPaiCm.newBuilder()
					.setMj(mj));
			return true;
		}

		private boolean chi(ChannelHandlerContext ctx, List<Integer> chiList) {
			if (chiList.isEmpty())
				return false;
			MessageImpl.sendMessage(ctx, MsgId.ChiPaiCm, ChiPaiCm.newBuilder()
					.setChi(chiList.get(0)));
			return true;
		}

		private boolean peng(ChannelHandlerContext ctx, boolean peng) {
			if (!peng)
				return false;
			MessageImpl.sendMessage(ctx, MsgId.PengPaiCm,
					PengPaiCm.newBuilder());
			return true;
		}

		private boolean jieGang(ChannelHandlerContext ctx, boolean jieGang) {
			if (!jieGang)
				return false;
			MessageImpl.sendMessage(ctx, MsgId.JieGangCm,
					JieGangCm.newBuilder());
			return true;
		}

		private boolean jiePao(ChannelHandlerContext ctx, boolean jiePao) {
			if (!jiePao)
				return false;
			MessageImpl.sendMessage(ctx, MsgId.JiePaoCm, JiePaoCm.newBuilder());
			return true;
		}

		private boolean ziMo(ChannelHandlerContext ctx, boolean b) {
			if (!b)
				return false;
			MessageImpl.sendMessage(ctx, MsgId.ZiMoPaiCm,
					ZiMoPaiCm.newBuilder());
			return true;
		}

		private boolean anGang(ChannelHandlerContext ctx, List<Mj> anGangList) {
			if (anGangList.isEmpty()) {
				return false;
			}
			MessageImpl.sendMessage(ctx, MsgId.AnGangPaiCm, AnGangPaiCm
					.newBuilder().setMj(anGangList.get(0)));
			return true;
		}

		private boolean mingGang(ChannelHandlerContext ctx,
				List<Mj> mingGangList) {
			if (mingGangList.isEmpty()) {
				return false;
			}
			MessageImpl.sendMessage(ctx, MsgId.MingGangPaiCm, MingGangPaiCm
					.newBuilder().setMj(mingGangList.get(0)));
			return true;
		}
	}

	public static boolean isDebug() {
		return true;
	}

	public static List<String> getURLs() {
		ArrayList<String> arrayList = new ArrayList<String>();
		for (int i = 0; i < 100; i++) {
			String property = properties.getProperty("login" + i);
			if (property != null)
				arrayList.add(property);
		}
		return arrayList;
	}

	public static boolean isCurrentChannel(Channel channel) {
		return channel != null && currentChannel == channel;
	}

	public static void setCurrentChannel(Channel currentChannel) {
		TestClient.currentChannel = currentChannel;
	}

	public static Channel getCurrentChannel() {
		return currentChannel;
	}

	/**
	 * 是否自动操作
	 * 
	 * @return
	 */
	public static boolean isAuto() {
		return ClientFrame.clientFrame.autoCheck.isSelected();
	}

	/**
	 * 是否是机器人房主
	 * 
	 * @param ctx
	 * @return
	 */
	public static boolean isRobotMaster(ChannelHandlerContext ctx) {
		String puid = (String) MessageImpl.getChannel(ctx, puidIndex);
		return puid.startsWith(robotName)
				&& Integer.parseInt(puid.substring(robotName.length())) % 10 == 0;
	}

	public static List<Channel> getMembers(ChannelHandlerContext ctx) {
		String puid = (String) MessageImpl.getChannel(ctx, puidIndex);
		if (!puid.startsWith(robotName)) {
			return null;
		}
		int robotId = Integer.parseInt(puid.substring(robotName.length()));
		if (robotId % 10 != 0) {
			return null;
		}
		List<Channel> list = new ArrayList<Channel>();
		for (int i = 1; i < 4; i++) {
			String id = robotName + (robotId + i);
			Channel channel = channelList.get(id);
			if (channel == null) {
				channel = TestClient.connect(
						ClientFrame.clientFrame.getSelectURL(), id,
						ChannelType.Normal);
			}
			list.add(channel);
		}
		return list;
	}

}
