package test.client;

public enum PxGameState {
	zhuaPai, daPai, buPai, ziMoAnGangMingGangGuo, waitOther, jiePaoJieGangPengGuo, qiangGangGuo
}
