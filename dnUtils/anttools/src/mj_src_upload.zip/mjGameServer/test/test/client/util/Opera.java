package test.client.util;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JButton;

import msg.MjMessage.Mj;
import test.client.MessageImpl;
import test.client.TestClient;

import com.wk.mj.Pai;

/** 碰杠听，， **/
public class Opera extends JButton implements ActionListener {
	private static final long serialVersionUID = 1L;
	private final List<Pai> mjs = new ArrayList<>();
	protected final MessageImpl type;

	public Opera(String arg0, MessageImpl type) {
		super(arg0);
		this.type = type;
		this.addActionListener(this);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if (type != null) {
			if (!this.mjs.isEmpty()) {
				Pai pai = TestClient.showDialog("选牌", this.mjs);
				if (pai != Pai.emptyMj) {
					type.sendMessageWithMj(pai.getMj());
				}
			} else
				type.sendMessageWithMj(null);
		}
	}

	public void setMj(ArrayList<Mj> list) {
		this.mjs.clear();
		for (Mj mj : list) {
			this.mjs.add(Pai.getPai(mj));
		}
	}

	public void setMj(Mj mj) {
		this.mjs.clear();
		this.mjs.add(Pai.getPai(mj));
	}

	public void setMj(List<Integer> list, Pai pai) {
	}
};