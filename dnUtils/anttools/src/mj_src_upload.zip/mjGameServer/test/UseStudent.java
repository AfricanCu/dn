import java.io.IOException;

import com.wk.mj.lai.LaiTools;

public class UseStudent {
	public static void main(String[] args) throws IOException {
		LaiTools.saveLaiData();
	}
}