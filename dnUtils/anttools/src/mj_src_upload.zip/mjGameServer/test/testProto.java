
public class testProto {
	public static void main(String[] args) {
	}
}
